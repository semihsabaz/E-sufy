import { useEffect, useRef, useState } from 'react';
import { MessageCircle, Send, X, RotateCcw, Trash2 } from 'lucide-react';
import { useReligiousChat } from '@workspace/api-client-react';

type Msg = { role: 'user' | 'assistant'; content: string; refused?: boolean };

export function ReligiousChat() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [text, setText] = useState('');
  const [failed, setFailed] = useState<string | null>(null);
  const chat = useReligiousChat();
  const pending = chat.isPending;
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  useEffect(() => { endRef.current?.scrollIntoView({ block: 'end' }); }, [messages, pending, failed]);
  useEffect(() => {
    if (!open) return;
    inputRef.current?.focus();
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open]);

  const ask = async (question: string, base: Msg[]) => {
    setFailed(null);
    const history = base.filter((m) => !m.refused).slice(-10).map(({ role, content }) => ({ role, content: content.slice(0, 4000) }));
    try {
      const res = await chat.mutateAsync({ data: { question, history } });
      setMessages([...base, { role: 'assistant', content: res.answer, refused: !res.allowed }]);
    } catch { setFailed(question); }
  };
  const submit = () => {
    const q = text.trim();
    if (!q || pending) return;
    const base = [...messages, { role: 'user' as const, content: q }];
    setMessages(base); setText(''); void ask(q, base.slice(0, -1));
  };
  const retry = () => { if (failed && !pending) void ask(failed, messages.slice(0, -1)); };
  const clear = () => { if (pending) return; setMessages([]); setFailed(null); setText(''); };

  return <>
    {!open && <button onClick={() => setOpen(true)} aria-label="Dini soru asistanını aç" data-testid="button-chat-open"
      className="fixed bottom-[calc(88px+env(safe-area-inset-bottom))] right-4 z-30 flex h-14 w-14 items-center justify-center rounded-full bg-[#d4af37] text-[#2e3b2b] shadow-2xl shadow-black/40 transition hover:scale-105 md:bottom-6 md:right-6"><MessageCircle size={24} /></button>}
    {open && <div role="dialog" aria-modal="false" aria-label="Dini soru asistanı" data-testid="panel-chat"
      className="fixed inset-x-3 bottom-[calc(80px+env(safe-area-inset-bottom))] z-50 flex max-h-[min(640px,calc(100dvh-110px))] flex-col overflow-hidden rounded-3xl border border-[#d4af37]/25 bg-[#1b2719] shadow-2xl shadow-black/50 md:inset-x-auto md:bottom-6 md:right-6 md:w-[400px]">
      <div className="flex items-center justify-between gap-2 border-b border-[#d4af37]/15 px-4 py-3">
        <div><p className="text-sm font-bold text-[#f5f1df]">Dini Soru Asistanı</p><p className="text-[10px] tracking-[.15em] text-[#c7b780]">E-SUFY</p></div>
        <div className="flex gap-1">
          <button onClick={clear} disabled={pending || messages.length === 0} aria-label="Sohbeti temizle" data-testid="button-chat-clear" className="grid h-9 w-9 place-items-center rounded-xl text-[#d4af37] disabled:opacity-40"><Trash2 size={16} /></button>
          <button onClick={() => setOpen(false)} aria-label="Sohbeti kapat" data-testid="button-chat-close" className="grid h-9 w-9 place-items-center rounded-xl text-[#d4af37]"><X size={18} /></button>
        </div>
      </div>
      <div className="space-y-1 bg-[#d4af37]/[.07] px-4 py-2 text-[11px] leading-relaxed text-[#c7c3ae]">
        <p>Yalnızca İslam ve dini konulardaki sorulara yanıt verir.</p>
        <p>Yanıtlar eğitim amaçlıdır, fetva değildir; kesin hüküm için yetkili bir din görevlisine danışın.</p>
      </div>
      <div className="min-h-[160px] flex-1 space-y-3 overflow-y-auto px-4 py-3" aria-live="polite">
        {messages.length === 0 && !pending && <p className="py-6 text-center text-sm text-[#a7a893]">Örneğin: “Teravih namazı kaç rekâttır?”</p>}
        {messages.map((m, i) => <div key={i} className={m.role === 'user' ? 'flex justify-end' : 'flex justify-start'}>
          <p data-testid={`text-chat-${i}`} className={`max-w-[88%] whitespace-pre-wrap break-words rounded-2xl px-3 py-2 text-sm leading-relaxed ${m.role === 'user' ? 'bg-[#d4af37] text-[#2e3b2b]' : m.refused ? 'border border-[#b65d48]/50 bg-[#b65d48]/15 text-[#f0b3a3]' : 'bg-[#243223] text-[#f5f1df]'}`}>
            {m.refused && <strong className="mb-1 block text-[10px] uppercase tracking-[.15em]">Kapsam dışı</strong>}{m.content}</p>
        </div>)}
        {pending && <p className="text-xs text-[#a7a893]" data-testid="status-chat-pending">Yanıt hazırlanıyor...</p>}
        {failed && !pending && <div role="alert" className="rounded-2xl border border-[#b65d48]/40 bg-[#b65d48]/10 p-3 text-xs text-[#f0b3a3]">
          Yanıt alınamadı. Bağlantınızı kontrol edip tekrar deneyin.
          <button onClick={retry} data-testid="button-chat-retry" className="ml-2 inline-flex items-center gap-1 font-bold underline"><RotateCcw size={12} />Tekrar dene</button></div>}
        <div ref={endRef} />
      </div>
      <form onSubmit={(e) => { e.preventDefault(); submit(); }} className="flex items-end gap-2 border-t border-[#d4af37]/15 p-3">
        <textarea ref={inputRef} value={text} maxLength={2000} rows={2} onChange={(e) => setText(e.target.value)} aria-label="Sorunuz" placeholder="Dini bir soru sorun"
          onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit(); } }} data-testid="input-chat"
          className="min-w-0 flex-1 resize-none rounded-xl border border-[#d4af37]/20 bg-[#243223] px-3 py-2 text-sm text-[#f5f1df] outline-none placeholder:text-[#8a8d7a] focus:border-[#d4af37]/60" />
        <button type="submit" disabled={pending || !text.trim()} aria-label="Gönder" data-testid="button-chat-send" className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[#d4af37] text-[#2e3b2b] disabled:opacity-40"><Send size={16} /></button>
      </form>
    </div>}
  </>;
}
