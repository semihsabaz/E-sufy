import { useEffect, useRef, useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { buildPrayerEvents, duePrayerEvents, eventMessage, fetchPrayerCalendar, turkeyDate, type PrayerEvent } from '@workspace/prayer-alerts';
import { getPrayerSettings, isPrayerAudioActivated, isPrayerSoundPlaying, previewPrayerSound, reportPrayerAlertStatus, requestPrayerPermissions, savePrayerSettings, stopPrayerSound } from '../lib/prayer-settings';

export function PrayerAlertsButton() {
  const [settings, setSettings] = useState(getPrayerSettings);
  const [city, setCity] = useState(() => localStorage.getItem('prayer-city') || 'Kayseri');
  const [day, setDay] = useState(turkeyDate);
  const [playing, setPlaying] = useState(false);
  const [activated, setActivated] = useState(isPrayerAudioActivated);
  const events = useRef<PrayerEvent[]>([]);
  const delivered = useRef(new Set<string>());
  useEffect(() => {
    try { delivered.current = new Set(JSON.parse(localStorage.getItem('prayer-delivered-events') ?? '[]')); } catch { /* Corrupt historical IDs never provide prayer times. */ }
    const sync = () => { setSettings(getPrayerSettings()); setCity(localStorage.getItem('prayer-city') || 'Kayseri'); };
    const audioSync = () => { setPlaying(isPrayerSoundPlaying()); setActivated(isPrayerAudioActivated()); };
    ['prayer-settings-change', 'prayer-city-change', 'storage'].forEach((name) => window.addEventListener(name, sync));
    window.addEventListener('prayer-audio-change', audioSync);
    const dateTimer = setInterval(() => setDay(turkeyDate()), 30000);
    return () => {
      ['prayer-settings-change', 'prayer-city-change', 'storage'].forEach((name) => window.removeEventListener(name, sync));
      window.removeEventListener('prayer-audio-change', audioSync); clearInterval(dateTimer); stopPrayerSound();
    };
  }, []);
  useEffect(() => {
    let cancelled = false;
    events.current = [];
    stopPrayerSound();
    reportPrayerAlertStatus({ city, error: null, scheduledUntil: null });
    if (!settings.enabled) return;
    void fetchPrayerCalendar(city, 2).then((days) => {
      if (cancelled) return;
      events.current = buildPrayerEvents(city, days, settings);
      reportPrayerAlertStatus({ city, error: null, scheduledUntil: days.at(-1)!.date });
    }).catch(() => {
      if (!cancelled) reportPrayerAlertStatus({ city, error: 'Namaz vakitleri alınamadı. Yanlış saatlerde uyarı vermemek için planlama durduruldu; bağlantınızı kontrol edin.', scheduledUntil: null });
    });
    return () => { cancelled = true; events.current = []; };
  }, [city, day, settings.enabled, settings.preAlert, settings.atPrayer, settings.reminderTone, settings.prayerTone]);
  useEffect(() => {
    const tick = () => {
      for (const event of duePrayerEvents(events.current, Date.now(), delivered.current)) {
        // Cross-tab deduplication: the first open tab records the event before playing.
        try {
          const persisted: string[] = JSON.parse(localStorage.getItem('prayer-delivered-events') ?? '[]');
          if (persisted.includes(event.id)) { delivered.current.add(event.id); continue; }
        } catch { /* Only historical IDs are discarded, never timetable errors. */ }
        delivered.current.add(event.id);
        localStorage.setItem('prayer-delivered-events', JSON.stringify([...delivered.current].slice(-120)));
        void previewPrayerSound(event.tone).catch(() => reportPrayerAlertStatus({
          city: event.city, scheduledUntil: null, error: 'Tarayıcı sesi engelledi. Ses düğmesine basın veya Ayarlar’dan bir melodiyi deneyerek sesi etkinleştirin.',
        }));
        if ('Notification' in window && Notification.permission === 'granted') {
          try { new Notification('E-Sufy · Namaz bildirimi', { body: eventMessage(event), tag: event.id, silent: true }); } catch { /* Foreground sound remains available if browser alerts are unavailable. */ }
        }
      }
    };
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, []);
  const toggle = async () => {
    if (settings.enabled && activated) { savePrayerSettings({ ...settings, enabled: false }); stopPrayerSound(); return; }
    try {
      await requestPrayerPermissions();
      savePrayerSettings({ ...settings, enabled: true });
    } catch {
      reportPrayerAlertStatus({ city, scheduledUntil: null, error: 'Ses etkinleştirilemedi. Tarayıcı ses izinlerini kontrol edip yeniden deneyin.' });
    }
  };
  return <div className="flex items-center gap-2">
    <button onClick={() => void toggle()} aria-pressed={settings.enabled && activated} aria-label={settings.enabled && activated ? 'Namaz sesini kapat' : 'Namaz sesini etkinleştir'}
      title={`${city}: 10 dakika önce ve vakitte ses. Sayfa açık olmalıdır.`} data-testid="button-adhan-alert"
      className={`flex h-9 items-center gap-2 rounded-xl px-3 text-[11px] font-bold ${settings.enabled && activated ? 'bg-[#d4af37] text-[#2e3b2b]' : 'bg-[#d4af37]/10 text-[#d4af37]'}`}>
      <Volume2 size={15}/><span className="hidden lg:inline">{settings.enabled && activated ? 'Bildirim açık' : 'Sesi etkinleştir'}</span>
    </button>
    {playing && <button onClick={stopPrayerSound} aria-label="Çalan sesi durdur" data-testid="button-stop-adhan" className="grid h-9 w-9 place-items-center rounded-xl bg-[#b65d48] text-white"><VolumeX size={16}/></button>}
  </div>;
}
