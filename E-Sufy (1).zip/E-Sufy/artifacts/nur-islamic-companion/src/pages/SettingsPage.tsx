import { useEffect, useRef, useState } from 'react';
import { Bell, Play, Square } from 'lucide-react';
import {
  PRAYER_SOUNDS, getPrayerAlertStatus, getPrayerSettings, previewPrayerSound, requestPrayerPermissions,
  savePrayerSettings, stopPrayerSound, type PrayerSettings, type SoundId,
} from '@/lib/prayer-settings';

function Toggle({ on, onChange, label, hint, id, disabled }: { on: boolean; onChange: (v: boolean) => void; label: string; hint: string; id: string; disabled?: boolean }) {
  return <div className="flex items-center justify-between gap-4 rounded-2xl border border-[#d4af37]/15 bg-[#243223]/70 p-4">
    <div className="min-w-0"><p className="text-sm font-bold text-[#f5f1df]">{label}</p><p className="mt-1 text-xs leading-relaxed text-[#a7a893]">{hint}</p></div>
    <button type="button" role="switch" aria-checked={on} aria-label={label} disabled={disabled} onClick={() => onChange(!on)} data-testid={id}
      className={`relative h-7 w-12 shrink-0 rounded-full transition disabled:opacity-50 ${on ? 'bg-[#d4af37]' : 'bg-[#f5f1df]/15'}`}>
      <span className={`absolute top-1 h-5 w-5 rounded-full bg-[#2e3b2b] transition-transform ${on ? 'translate-x-6' : 'translate-x-1'}`} />
    </button>
  </div>;
}

function SoundPicker({ title, value, onChange, kind }: { title: string; value: SoundId; onChange: (v: SoundId) => void; kind: string }) {
  const [playing, setPlaying] = useState<SoundId | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);
  const toggle = async (id: SoundId) => {
    setErr(null);
    if (timer.current) clearTimeout(timer.current);
    if (playing === id) { stopPrayerSound(); setPlaying(null); return; }
    try {
      setPlaying(id); await previewPrayerSound(id);
      timer.current = setTimeout(() => setPlaying(null), id === 'adhan' ? 15000 : 3000);
    } catch { setPlaying(null); setErr('Ses çalınamadı. Tarayıcı sesine izin verildiğinden emin olun.'); }
  };
  return <fieldset className="rounded-2xl border border-[#d4af37]/15 bg-[#243223]/70 p-4">
    <legend className="px-2 text-[11px] font-bold uppercase tracking-[.18em] text-[#d4af37]">{title}</legend>
    <div className="space-y-2" role="radiogroup" aria-label={title}>
      {PRAYER_SOUNDS.map((s) => <div key={s.id} className={`flex flex-wrap items-center gap-3 rounded-xl border p-3 ${value === s.id ? 'border-[#d4af37]/60 bg-[#d4af37]/10' : 'border-transparent bg-[#172218]/50'}`}>
        <button type="button" role="radio" aria-checked={value === s.id} onClick={() => onChange(s.id)} data-testid={`radio-${kind}-${s.id}`} className="flex min-w-0 flex-1 items-center gap-3 text-left">
          <span className={`grid h-4 w-4 shrink-0 place-items-center rounded-full border ${value === s.id ? 'border-[#d4af37]' : 'border-[#939985]'}`}>{value === s.id && <span className="h-2 w-2 rounded-full bg-[#d4af37]" />}</span>
          <span className="text-sm font-semibold text-[#f5f1df]">{s.label}</span>
        </button>
        <button type="button" onClick={() => toggle(s.id)} aria-label={`${s.label} melodisini ${playing === s.id ? 'durdur' : 'dinle'}`} data-testid={`button-preview-${kind}-${s.id}`}
          className="flex h-9 items-center gap-2 rounded-xl bg-[#d4af37]/10 px-3 text-xs font-bold text-[#d4af37]">
          {playing === s.id ? <Square size={13} /> : <Play size={13} />}{playing === s.id ? 'Durdur' : 'Dinle'}
        </button>
      </div>)}
    </div>
    {err && <p role="alert" className="mt-3 text-xs text-[#e08b76]">{err}</p>}
  </fieldset>;
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<PrayerSettings>(() => getPrayerSettings());
  const [status, setStatus] = useState(() => getPrayerAlertStatus());
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    const a = () => setSettings(getPrayerSettings());
    const b = () => setStatus({ ...getPrayerAlertStatus() });
    window.addEventListener('prayer-settings-change', a);
    window.addEventListener('prayer-alert-status', b);
    return () => { window.removeEventListener('prayer-settings-change', a); window.removeEventListener('prayer-alert-status', b); stopPrayerSound(); };
  }, []);
  const update = (patch: Partial<PrayerSettings>) => { const next = { ...getPrayerSettings(), ...patch }; setSettings(next); savePrayerSettings(next); };
  const setEnabled = async (on: boolean) => {
    setError(null);
    if (!on) { update({ enabled: false }); return; }
    setBusy(true);
    try {
      await requestPrayerPermissions();
      if ('Notification' in window && Notification.permission === 'denied') setError('Bildirim izni reddedildi; sesli hatırlatma açık sayfada yine de çalışır. Tarayıcı ayarlarından izni açabilirsiniz.');
      update({ enabled: true });
    } catch (e) {
      update({ enabled: false });
      setError(e instanceof Error && e.message ? `Hatırlatmalar açılamadı: ${e.message}` : 'Hatırlatmalar açılamadı. Ses veya bildirim izni verilmedi; ayar kapalı kaldı.');
    } finally { setBusy(false); }
  };
  return <div className="mx-auto max-w-3xl space-y-5">
    <div><p className="mb-2 text-[10px] font-bold uppercase tracking-[.22em] text-[#d4af37]">Ayarlar</p>
      <h1 className="font-[Manrope] text-3xl font-bold tracking-[-.04em] text-[#f5f1df]">Namaz hatırlatmaları</h1></div>
    <Toggle id="switch-prayer-enabled" on={settings.enabled} onChange={setEnabled} disabled={busy} label="Sesli hatırlatmalar" hint={busy ? 'İzinler isteniyor...' : 'Açtığınızda ses ve bildirim izni istenir.'} />
    {error && <p role="alert" data-testid="text-prayer-error" className="rounded-2xl border border-[#b65d48]/40 bg-[#b65d48]/10 p-4 text-sm text-[#f0b3a3]">{error}</p>}
    <div className="grid gap-3 sm:grid-cols-2">
      <Toggle id="switch-pre-alert" on={settings.preAlert} onChange={(v) => update({ preAlert: v })} label="Vakitten 10 dakika önce" hint="Vakit girmeden önce kısa bir hatırlatma." />
      <Toggle id="switch-at-prayer" on={settings.atPrayer} onChange={(v) => update({ atPrayer: v })} label="Vakit girdiğinde" hint="Namaz vakti girdiği anda uyarı." />
    </div>
    <div className="grid gap-3 md:grid-cols-2">
      <SoundPicker kind="reminder" title="10 dakika önce melodisi" value={settings.reminderTone} onChange={(v) => update({ reminderTone: v })} />
      <SoundPicker kind="prayer" title="Vakit girince melodisi" value={settings.prayerTone} onChange={(v) => update({ prayerTone: v })} />
    </div>
    <div className="rounded-2xl border border-[#d4af37]/15 bg-[#d4af37]/[.06] p-4 text-xs leading-relaxed text-[#c7c3ae]" data-testid="text-prayer-status">
      <p className="mb-2 flex items-center gap-2 font-bold text-[#d4af37]"><Bell size={14} />Web hakkında</p>
      <p>Web sürümünde hatırlatmalar yalnızca E-Sufy sayfası açıkken ve bir kullanıcı dokunuşuyla ses izni verildikten sonra çalışır. Tarayıcı kapalıyken veya sekme uykudayken güvenilir bildirim gönderilemez.</p>
      <p className="mt-2">Şehir: {status.city}{status.scheduledUntil ? ` · Planlanan: ${status.scheduledUntil}` : ''}</p>
      {status.error && <p role="alert" className="mt-2 text-[#f0b3a3]">{status.error}</p>}
    </div>
  </div>;
}
