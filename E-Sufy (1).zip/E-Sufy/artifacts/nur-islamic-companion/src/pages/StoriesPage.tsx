import { useEffect, useRef, useState } from 'react';
import { useLocation, useSearch } from 'wouter';
import { useListStories, getListStoriesQueryKey, type PublishedStory } from '@workspace/api-client-react';
import { ArrowLeft, ChevronLeft, ChevronRight, RotateCcw, Scroll, Sparkles } from 'lucide-react';

function pageWindow(current: number, total: number): (number | 'gap-a' | 'gap-b')[] {
  const set = new Set([1, total, current - 1, current, current + 1]);
  const nums = [...set].filter((n) => n >= 1 && n <= total).sort((a, b) => a - b);
  const out: (number | 'gap-a' | 'gap-b')[] = [];
  nums.forEach((n, i) => {
    if (i > 0 && n - nums[i - 1] > 1) out.push(i === 1 ? 'gap-a' : 'gap-b');
    out.push(n);
  });
  return out;
}

function fmtDate(iso: string, tz?: string) {
  try {
    return new Intl.DateTimeFormat('tr-TR', { day: 'numeric', month: 'long', year: 'numeric', timeZone: tz || 'Europe/Istanbul' }).format(new Date(iso));
  } catch { return iso; }
}

function Note() {
  return (
    <p className="flex items-start gap-2 rounded-xl border border-[#d4af37]/15 bg-[#d4af37]/5 p-3 text-xs leading-relaxed text-[#b9ac80]" data-testid="text-ai-note">
      <Sparkles size={14} className="mt-0.5 shrink-0 text-[#d4af37]" />
      <span>Günlük kıssalar, belirtilen kaynaklara dayanılarak yapay zekâ ile yeniden ifade edilmiştir. Metin, Kur’an ayetlerinin birebir çevirisi değildir; ayet ve hadis için kaynağa başvurun.</span>
    </p>
  );
}

export default function StoriesPage() {
  const search = useSearch();
  const [, navigate] = useLocation();
  const raw = parseInt(new URLSearchParams(search).get('page') ?? '1', 10);
  const page = Number.isFinite(raw) && raw >= 1 ? Math.min(raw, 100000) : 1;
  const [selected, setSelected] = useState<PublishedStory | null>(null);

  const q = useListStories({ page }, { query: { queryKey: getListStoriesQueryKey({ page }), refetchInterval: 60000, refetchOnWindowFocus: true } });
  const { data, isLoading, isError, refetch } = q;
  const refetchRef = useRef(refetch);
  refetchRef.current = refetch;

  useEffect(() => { setSelected(null); }, [page]);

  const nextAt = data?.nextPublicationAt;
  useEffect(() => {
    if (!nextAt) return;
    const ms = new Date(nextAt).getTime() - Date.now() + 1500;
    if (ms <= 0 || ms > 2147483000) return;
    const t = setTimeout(() => { refetchRef.current(); }, ms);
    return () => clearTimeout(t);
  }, [nextAt]);

  const go = (p: number) => { navigate(p <= 1 ? '/stories' : `/stories?page=${p}`); window.scrollTo?.({ top: 0 }); };
  const tz = data?.publicationTimezone;

  if (selected) {
    return (
      <div className="space-y-6">
        <button onClick={() => setSelected(null)} className="flex h-10 items-center gap-2 rounded-xl bg-[#d4af37]/10 px-4 text-sm font-semibold text-[#d4af37] transition hover:bg-[#d4af37]/20" data-testid="button-back-stories"><ArrowLeft size={16} /> Geri</button>
        <article className="min-w-0 rounded-[2rem] border border-[#d4af37]/20 bg-[#243223]/60 p-6 md:p-12">
          <div className="flex flex-wrap items-center gap-2 text-[11px] font-bold uppercase tracking-[.2em] text-[#d4af37]">
            <span>{selected.theme}</span><span className="text-[#766f53]">·</span><span data-testid="text-story-edition">{selected.editionLabel}</span>
          </div>
          <h1 className="mt-3 break-words font-[Manrope] text-3xl font-extrabold text-[#f5f1df] md:text-4xl" data-testid="text-story-title">{selected.title}</h1>
          <p className="mt-2 text-xs text-[#9fa28c]">Yayın tarihi: {fmtDate(selected.publicationDate, tz)}</p>
          <div className="mt-6"><Note /></div>
          <div className="mt-8 space-y-6 break-words text-base leading-[1.8] text-[#dacda9]">
            {selected.content.split(/\n{2,}/).map((p, i) => <p key={i}>{p}</p>)}
          </div>
          <div className="mt-8 rounded-2xl border border-[#d4af37]/20 bg-[#d4af37]/8 p-5">
            <p className="text-[10px] font-bold uppercase tracking-[.2em] text-[#d4af37]">Hayat dersi</p>
            <p className="mt-2 break-words text-sm leading-relaxed text-[#f5f1df]">{selected.lesson}</p>
          </div>
          <p className="mt-6 break-words text-xs leading-relaxed text-[#9fa28c]" data-testid="text-story-source"><span className="font-bold text-[#b9ac80]">Kaynak:</span> {selected.source}</p>
        </article>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div>
        <p className="mb-1 text-[10px] font-bold uppercase tracking-[.22em] text-[#d4af37]">Her gün 00:00 (İstanbul)</p>
        <h2 className="font-[Manrope] text-3xl font-extrabold text-[#f5f1df]">Günlük Kıssalar</h2>
        <p className="mt-2 text-sm text-[#aaa890]">{page > 1 ? `Arşiv, sayfa ${page}` : 'En yeni yayınlar önce gelir.'}</p>
      </div>
      <Note />

      {isLoading && (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3" data-testid="state-loading">
          {Array.from({ length: 9 }).map((_, i) => <div key={i} className="pulse-soft h-52 rounded-[1.7rem] border border-[#d4af37]/10 bg-[#243223]/50" />)}
        </div>
      )}

      {isError && !isLoading && (
        <div className="rounded-[1.7rem] border border-[#d4af37]/20 bg-[#243223]/60 p-8 text-center" data-testid="state-error">
          <p className="font-bold text-[#f5f1df]">Kıssalar yüklenemedi</p>
          <p className="mt-2 text-sm text-[#aaa890]">Bağlantınızı kontrol edip tekrar deneyin.</p>
          <button onClick={() => refetch()} className="mt-5 inline-flex items-center gap-2 rounded-xl bg-[#d4af37] px-5 py-3 text-xs font-bold text-[#2e3b2b]" data-testid="button-retry-stories"><RotateCcw size={14} /> Tekrar dene</button>
        </div>
      )}

      {data && data.items.length === 0 && (
        <div className="rounded-[1.7rem] border border-[#d4af37]/15 bg-[#243223]/50 p-8 text-center" data-testid="state-empty">
          <Scroll className="mx-auto text-[#8e8a69]" size={26} />
          <p className="mt-3 font-bold text-[#f5f1df]">{page > 1 ? 'Bu sayfada kıssa yok' : 'Henüz kıssa yayınlanmadı'}</p>
          {page > 1 && <button onClick={() => go(1)} className="mt-4 text-xs font-bold text-[#d4af37]" data-testid="button-empty-first">İlk sayfaya dön</button>}
        </div>
      )}

      {data && data.items.length > 0 && (
        <>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {data.items.map((s) => (
              <button key={s.id} onClick={() => setSelected(s)} className="flex min-w-0 flex-col items-start rounded-[1.7rem] border border-[#d4af37]/12 bg-[#243223]/65 p-6 text-left transition hover:-translate-y-1 hover:border-[#d4af37]/30 hover:bg-[#969b87]/10" data-testid={`card-story-${s.id}`}>
                <div className="mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-[#d4af37]/10 text-[#d4af37]"><Scroll size={22} /></div>
                <p className="text-[10px] font-bold uppercase tracking-[.2em] text-[#d4af37]">{s.theme}</p>
                <h3 className="mt-2 break-words text-xl font-bold text-[#f5f1df]">{s.title}</h3>
                <p className="mt-1 text-[11px] text-[#9fa28c]">{fmtDate(s.publicationDate, tz)} · {s.editionLabel}</p>
                <p className="mt-3 line-clamp-4 break-words text-sm leading-relaxed text-[#aaa890]">{s.summary}</p>
                <span className="mt-5 flex items-center gap-1.5 text-xs font-bold text-[#d4af37]">Oku <ChevronRight size={14} /></span>
              </button>
            ))}
          </div>
          <nav className="flex flex-wrap items-center justify-center gap-2" aria-label="Sayfalar" data-testid="nav-pagination">
            <button disabled={page <= 1} onClick={() => go(page - 1)} className="flex h-10 items-center gap-1 rounded-xl border border-[#d4af37]/20 px-3 text-xs font-bold text-[#d9d2bb] disabled:opacity-35" data-testid="button-page-prev"><ChevronLeft size={15} /> Önceki</button>
            {pageWindow(page, data.totalPages).map((p) => typeof p === 'number' ? (
              <button key={p} onClick={() => go(p)} aria-current={p === page ? 'page' : undefined} className={`h-10 min-w-10 rounded-xl px-3 text-xs font-bold ${p === page ? 'bg-[#d4af37] text-[#2e3b2b]' : 'border border-[#d4af37]/20 text-[#d9d2bb]'}`} data-testid={`button-page-${p}`}>{p}</button>
            ) : <span key={p} className="px-1 text-[#766f53]">…</span>)}
            <button disabled={page >= data.totalPages} onClick={() => go(page + 1)} className="flex h-10 items-center gap-1 rounded-xl border border-[#d4af37]/20 px-3 text-xs font-bold text-[#d9d2bb] disabled:opacity-35" data-testid="button-page-next">Sonraki <ChevronRight size={15} /></button>
          </nav>
          <p className="text-center text-[11px] text-[#9fa28c]">Toplam {data.total} kıssa · Sayfa {data.page} / {data.totalPages}</p>
        </>
      )}
    </div>
  );
}
