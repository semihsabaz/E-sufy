import { useEffect, useMemo, useRef, useState, type CSSProperties, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { turkeyDate } from '@workspace/prayer-alerts';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Link, Route, Switch, Router as WouterRouter, useLocation, useParams } from 'wouter';
import {
  ArrowLeft, BookOpen, ChevronRight, CircleHelp, Clock3, Compass, ExternalLink,
  GraduationCap, Hand, Heart, Home as HomeIcon, Library, LocateFixed, MapPin, Menu, Minus, Moon,
  Plus, RotateCcw, Scroll, Search, Settings2, Sparkles, Sun, Tags,
  Volume2, X, Youtube
} from 'lucide-react';
import NotFound from '@/pages/not-found';
import { esmaNames } from '@/data/esma';
import StoriesPage from '@/pages/StoriesPage';
import SettingsPage from '@/pages/SettingsPage';
import { PrayerAlertsButton } from './components/PrayerAlerts';
import { ReligiousChat } from '@/components/ReligiousChat';

const queryClient = new QueryClient();

type Prayer = { key: string; label: string; arabic: string; time: string };
type PrayerResponse = { data?: { timings?: Record<string, string>; date?: { readable?: string; hijri?: { day?: string; month?: { en?: string }; year?: string } } } };
const prayerMeta: Prayer[] = [
  { key: 'Fajr', label: 'İmsak', arabic: 'الفجر', time: '05:31' },
  { key: 'Sunrise', label: 'Güneş', arabic: 'الشروق', time: '07:02' },
  { key: 'Dhuhr', label: 'Öğle', arabic: 'الظهر', time: '13:08' },
  { key: 'Asr', label: 'İkindi', arabic: 'العصر', time: '16:27' },
  { key: 'Maghrib', label: 'Akşam', arabic: 'المغرب', time: '19:02' },
  { key: 'Isha', label: 'Yatsı', arabic: 'العشاء', time: '20:29' },
];
const cities = [
  'Adana', 'Adıyaman', 'Afyonkarahisar', 'Ağrı', 'Aksaray', 'Amasya', 'Ankara', 'Antalya', 'Ardahan', 'Artvin',
  'Aydın', 'Balıkesir', 'Bartın', 'Batman', 'Bayburt', 'Bilecik', 'Bingöl', 'Bitlis', 'Bolu', 'Burdur',
  'Bursa', 'Çanakkale', 'Çankırı', 'Çorum', 'Denizli', 'Diyarbakır', 'Düzce', 'Edirne', 'Elazığ', 'Erzincan',
  'Erzurum', 'Eskişehir', 'Gaziantep', 'Giresun', 'Gümüşhane', 'Hakkâri', 'Hatay', 'Iğdır', 'Isparta', 'İstanbul',
  'İzmir', 'Kahramanmaraş', 'Karabük', 'Karaman', 'Kars', 'Kastamonu', 'Kayseri', 'Kırıkkale', 'Kırklareli', 'Kırşehir',
  'Kilis', 'Kocaeli', 'Konya', 'Kütahya', 'Malatya', 'Manisa', 'Mardin', 'Mersin', 'Muğla', 'Muş',
  'Nevşehir', 'Niğde', 'Ordu', 'Osmaniye', 'Rize', 'Sakarya', 'Samsun', 'Siirt', 'Sinop', 'Sivas',
  'Şanlıurfa', 'Şırnak', 'Tekirdağ', 'Tokat', 'Trabzon', 'Tunceli', 'Uşak', 'Van', 'Yalova', 'Yozgat', 'Zonguldak',
];

const hadiths = [
  { text: 'Ameller niyetlere göredir. Herkese niyet ettiği şey vardır.', source: 'Buhârî, Bed’ü’l-vahy 1', narrator: 'Hz. Ömer (r.a.)' },
  { text: 'Sizin en hayırlınız, Kur’an’ı öğrenen ve öğreteninizdir.', source: 'Buhârî, Fedâilü’l-Kur’ân 21', narrator: 'Hz. Osman (r.a.)' },
  { text: 'Güzel söz sadakadır.', source: 'Buhârî, Edeb 34', narrator: 'Ebû Hüreyre (r.a.)' },
  { text: 'Allah, sizden birinizin yaptığı işi sağlam ve güzel yapmasından hoşnut olur.', source: 'Beyhakî, Şuabu’l-Îmân', narrator: 'Hz. Âişe (r.a.)' },
  { text: 'Kolaylaştırınız, zorlaştırmayınız; müjdeleyiniz, nefret ettirmeyiniz.', source: 'Buhârî, İlim 11', narrator: 'Enes b. Mâlik (r.a.)' },
];

const fallbackSurahs = [
  { number: 1, name: 'Al-Fatihah', englishName: 'Fâtiha', englishNameTranslation: 'Açılış', numberOfAyahs: 7, revelationType: 'Mekkî' },
  { number: 2, name: 'Al-Baqarah', englishName: 'Bakara', englishNameTranslation: 'İnek', numberOfAyahs: 286, revelationType: 'Medenî' },
  { number: 3, name: 'Ali Imran', englishName: 'Âl-i İmrân', englishNameTranslation: 'Âl-i İmrân', numberOfAyahs: 200, revelationType: 'Medenî' },
  { number: 36, name: 'Ya-Sin', englishName: 'Yâsîn', englishNameTranslation: 'Yâsîn', numberOfAyahs: 83, revelationType: 'Mekkî' },
  { number: 55, name: 'Ar-Rahman', englishName: 'Rahmân', englishNameTranslation: 'Rahmân', numberOfAyahs: 78, revelationType: 'Mekkî' },
  { number: 67, name: 'Al-Mulk', englishName: 'Mülk', englishNameTranslation: 'Mülk', numberOfAyahs: 30, revelationType: 'Mekkî' },
  { number: 112, name: 'Al-Ikhlas', englishName: 'İhlâs', englishNameTranslation: 'Samimiyet', numberOfAyahs: 4, revelationType: 'Mekkî' },
];
const fallbackAyahs = [
  { numberInSurah: 1, arabic: 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ', tr: 'Rahmân ve Rahîm olan Allah’ın adıyla.' },
  { numberInSurah: 2, arabic: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ', tr: 'Hamd, âlemlerin Rabbi Allah’a mahsustur.' },
  { numberInSurah: 3, arabic: 'الرَّحْمَنِ الرَّحِيمِ', tr: 'O, Rahmân’dır ve Rahîm’dir.' },
  { numberInSurah: 4, arabic: 'مَالِكِ يَوْمِ الدِّينِ', tr: 'Hesap ve ceza gününün sahibidir.' },
  { numberInSurah: 5, arabic: 'إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ', tr: 'Yalnız sana ibadet eder, yalnız senden yardım dileriz.' },
  { numberInSurah: 6, arabic: 'اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ', tr: 'Bizi dosdoğru yola ilet.' },
  { numberInSurah: 7, arabic: 'صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ', tr: 'Nimet verdiklerinin yoluna.' },
];
const turkishSurahNames = [
  'Fâtiha', 'Bakara', 'Âl-i İmrân', 'Nisâ', 'Mâide', 'En’âm', 'A’râf', 'Enfâl', 'Tevbe', 'Yûnus',
  'Hûd', 'Yûsuf', 'Ra’d', 'İbrâhîm', 'Hicr', 'Nahl', 'İsrâ', 'Kehf', 'Meryem', 'Tâhâ',
  'Enbiyâ', 'Hac', 'Mü’minûn', 'Nûr', 'Furkân', 'Şuarâ', 'Neml', 'Kasas', 'Ankebût', 'Rûm',
  'Lokmân', 'Secde', 'Ahzâb', 'Sebe’', 'Fâtır', 'Yâsîn', 'Sâffât', 'Sâd', 'Zümer', 'Mü’min',
  'Fussilet', 'Şûrâ', 'Zuhruf', 'Duhân', 'Câsiye', 'Ahkâf', 'Muhammed', 'Fetih', 'Hucurât', 'Kâf',
  'Zâriyât', 'Tûr', 'Necm', 'Kamer', 'Rahmân', 'Vâkıa', 'Hadîd', 'Mücâdele', 'Haşr', 'Mümtehine',
  'Saf', 'Cuma', 'Münâfikûn', 'Teğâbün', 'Talâk', 'Tahrîm', 'Mülk', 'Kalem', 'Hâkka', 'Meâric',
  'Nûh', 'Cin', 'Müzzemmil', 'Müddessir', 'Kıyâmet', 'İnsan', 'Mürselât', 'Nebe’', 'Nâziât', 'Abese',
  'Tekvîr', 'İnfitâr', 'Mutaffifîn', 'İnşikâk', 'Bürûc', 'Târık', 'A’lâ', 'Gâşiye', 'Fecr', 'Beled',
  'Şems', 'Leyl', 'Duhâ', 'İnşirâh', 'Tîn', 'Alak', 'Kadr', 'Beyyine', 'Zilzâl', 'Âdiyât',
  'Kâria', 'Tekâsür', 'Asr', 'Hümeze', 'Fîl', 'Kureyş', 'Mâûn', 'Kevser', 'Kâfirûn', 'Nasr',
  'Tebbet', 'İhlâs', 'Felak', 'Nâs',
] as const;
function getTurkishSurahName(number: number) {
  return turkishSurahNames[number - 1] ?? 'Sure';
}

function getSurahRecitationUrl(number: number) {
  return `https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/${number}.mp3`;
}

const bismillahPrefix = /^\uFEFF?\s*بِسْمِ\s+(?:ٱللَّهِ|اللَّهِ|اللَّهِ)\s+(?:ٱلرَّحْمَٰنِ|الرَّحْمَنِ)\s+(?:ٱلرَّحِيمِ|الرَّحِيمِ)\s*/u;
const bismillahArabic = 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ';

function normalizeAyahs(surahNumber: number, arabicAyahs: { numberInSurah: number; text?: string; arabic?: string }[], turkishAyahs: { text?: string; tr?: string }[]) {
  const mapped = arabicAyahs.map((ayah, index) => ({ numberInSurah: ayah.numberInSurah, arabic: ayah.text ?? ayah.arabic ?? '', tr: turkishAyahs[index]?.text ?? turkishAyahs[index]?.tr ?? '' }));
  if (surahNumber === 9 || !mapped.length) return mapped;
  const firstVerse = mapped[0].arabic.replace(/^\uFEFF/, '').trim().replace(bismillahPrefix, '').trim();
  if (surahNumber === 1 && !firstVerse) return mapped.slice(1);
  return [{ ...mapped[0], arabic: firstVerse }, ...mapped.slice(1)];
}

function usePrayerTimes(city: string) {
  const [prayers, setPrayers] = useState<Prayer[]>(prayerMeta);
  const [date, setDate] = useState('Bugün');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [day, setDay] = useState(turkeyDate);
  useEffect(() => {
    const timer = setInterval(() => setDay(turkeyDate()), 30000);
    return () => clearInterval(timer);
  }, []);
  useEffect(() => {
    let alive = true;
    setLoading(true);
    setError(false);
    fetch(`https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(city)}&country=Turkey&method=13`)
      .then((res) => { if (!res.ok) throw new Error('Prayer service'); return res.json() as Promise<PrayerResponse>; })
      .then((json) => {
        if (!alive) return;
        const timings = json.data?.timings;
        if (!timings || prayerMeta.some((item) => !/^\d{2}:\d{2}/.test(timings[item.key] ?? ''))) throw new Error('Invalid prayer times');
        setPrayers(prayerMeta.map((item) => ({ ...item, time: timings[item.key]!.slice(0, 5) })));
        setDate(json.data?.date?.readable ?? 'Bugün');
      })
      .catch(() => alive && setError(true))
      .finally(() => alive && setLoading(false));
    return () => { alive = false; };
  }, [city, day]);
  return { prayers, date, loading, error };
}

function getNextPrayer(prayers: Prayer[]) {
  const now = new Date();
  const current = now.getHours() * 60 + now.getMinutes();
  const future = prayers.map((p) => ({ ...p, minutes: Number(p.time.slice(0, 2)) * 60 + Number(p.time.slice(3)) })).find((p) => p.minutes > current);
  return future ?? { ...prayers[0], minutes: Number(prayers[0].time.slice(0, 2)) * 60 + Number(prayers[0].time.slice(3)) + 1440 };
}

function useCountdown(prayer: Prayer) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const timer = window.setInterval(() => setNow(Date.now()), 1000); return () => window.clearInterval(timer); }, []);
  const current = new Date(now);
  let target = new Date(now);
  target.setHours(Number(prayer.time.slice(0, 2)), Number(prayer.time.slice(3)), 0, 0);
  if (target.getTime() <= now) target.setDate(target.getDate() + 1);
  const diff = Math.max(0, target.getTime() - now);
  const hours = Math.floor(diff / 3600000).toString().padStart(2, '0');
  const minutes = Math.floor(diff / 60000 % 60).toString().padStart(2, '0');
  const seconds = Math.floor(diff / 1000 % 60).toString().padStart(2, '0');
  return { label: `${hours}:${minutes}:${seconds}`, date: current };
}

const navItems = [
  { href: '/', label: 'Ana Sayfa', icon: HomeIcon },
  { href: '/prayer', label: 'Namaz Vakitleri', icon: Clock3 },
  { href: '/quran', label: "Kur’an-ı Kerim", icon: BookOpen },
  { href: '/qibla', label: 'Kıble Bulucu', icon: Compass },
  { href: '/duas', label: 'Dualar', icon: Hand },
  { href: '/namaz-kilinis', label: 'Namaz Kılınışı', icon: GraduationCap },
  { href: '/tasbih', label: 'Tesbih', icon: CircleHelp },
  { href: '/esmaul-husna', label: 'Esmaül Hüsna', icon: Tags },
  { href: '/hadith', label: 'Hadis', icon: Library },
  { href: '/stories', label: 'Kıssalar', icon: Scroll },
  { href: '/live', label: 'Canlı Yayın', icon: Youtube },
];

function AppShell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [mobileMenu, setMobileMenu] = useState(false);
  return <div className="app-shell">
    <aside className="side-rail fixed inset-y-0 left-0 z-30 hidden w-[248px] flex-col px-5 py-7 md:flex">
      <Link href="/" className="mb-12 flex items-center gap-3 px-3" data-testid="link-logo">
        <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[#d4af37] text-[#2e3b2b] shadow-lg shadow-black/20"><Moon size={22} fill="currentColor" /></span>
        <span><strong className="block text-[17px] tracking-[.12em] text-[#f5f1df]">E-Sufy</strong><small className="text-[10px] tracking-[.22em] text-[#c7b780]">İSLAMİ ARKADAŞIN</small></span>
      </Link>
      <p className="mb-3 px-3 text-[10px] font-bold uppercase tracking-[.2em] text-[#a79866]">Gününü aydınlat</p>
      <nav className="space-y-1">
        {navItems.map(({ href, label, icon: Icon }) => <Link key={href} href={href} className={`nav-item flex items-center gap-3 rounded-2xl px-3 py-3 text-[13px] font-semibold ${location === href || (href !== '/' && location.startsWith(href)) ? 'active' : ''}`} data-testid={`link-nav-${label}`}>
          <Icon size={18} strokeWidth={1.8} /><span>{label}</span>{href === '/live' && <span className="ml-auto h-2 w-2 rounded-full bg-[#b65d48] pulse-soft" />}
        </Link>)}
      </nav>
      <div className="mt-auto rounded-3xl border border-[#d4af37]/15 bg-[#d4af37]/[.06] p-4">
        <p className="arabic mb-2 text-right text-lg text-[#d4af37]">وَاذْكُر رَّبَّكَ إِذَا نَسِيتَ</p>
        <p className="text-[11px] leading-relaxed text-[#c7c3ae]">“Unuttuğun zaman Rabbini an.”</p>
        <p className="mt-2 text-[10px] text-[#938b6e]">Kehf Suresi, 24</p>
      </div>
    </aside>
    <header className="topbar fixed inset-x-0 top-0 z-20 flex h-[74px] items-center justify-between px-5 backdrop-blur-xl md:ml-[248px] md:px-10">
      <div className="flex items-center gap-3 md:hidden">
        <button className="rounded-xl p-2 text-[#d4af37]" onClick={() => setMobileMenu(!mobileMenu)} aria-label="Menüyü aç" data-testid="button-mobile-menu">{mobileMenu ? <X size={21} /> : <Menu size={21} />}</button>
        <span className="font-bold tracking-[.15em] text-[#f5f1df]">E-Sufy</span>
      </div>
      <div className="hidden items-center gap-2 text-[12px] text-[#a7a893] md:flex"><span className="h-2 w-2 rounded-full bg-[#d4af37]" />Huzurlu bir gün için küçük bir adım</div>
      <div className="ml-auto flex items-center gap-3">
        <span className="hidden text-[12px] text-[#c7c3ae] sm:inline">{new Intl.DateTimeFormat('tr-TR', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date())}</span>
        <PrayerAlertsButton />
        <Link href="/settings" className="grid h-9 w-9 place-items-center rounded-xl bg-[#d4af37]/10 text-[#d4af37]" aria-label="Ayarlar" data-testid="button-settings"><Settings2 size={17} /></Link>
      </div>
    </header>
    {mobileMenu && <div className="fixed inset-0 z-40 bg-[#172218]/95 p-6 pt-24 backdrop-blur-xl md:hidden">
      <nav className="space-y-2">{navItems.map(({ href, label, icon: Icon }) => <Link onClick={() => setMobileMenu(false)} href={href} key={href} className="flex items-center gap-4 rounded-2xl p-4 text-lg text-[#f5f1df]" data-testid={`link-mobile-${label}`}><Icon className="text-[#d4af37]" size={20} />{label}<ChevronRight className="ml-auto text-[#766f53]" size={17} /></Link>)}</nav>
    </div>}
    <main className="main-frame page-content pt-[74px]"><div className="mobile-bottom-space mx-auto max-w-[1380px] px-5 py-7 md:px-10 md:py-10">{children}</div></main>
    <nav className="bottom-tabs hide-scrollbar fixed inset-x-0 bottom-0 z-30 flex justify-start overflow-x-auto border-t border-[#d4af37]/15 bg-[#172218]/95 px-2 pt-2 backdrop-blur-xl md:hidden">
      {navItems.map(({ href, label, icon: Icon }) => <Link href={href} key={href} className={`flex min-w-[64px] flex-1 flex-col items-center gap-1 px-0.5 py-1 text-[9px] font-semibold ${location === href || (href !== '/' && location.startsWith(href)) ? 'text-[#d4af37]' : 'text-[#939985]'}`} data-testid={`link-bottom-${label}`}><Icon size={18} /><span className="max-w-[58px] truncate">{label.replace('Namaz Vakitleri', 'Vakitler').replace('Kur’an-ı Kerim', 'Kur’an').replace('Canlı Yayın', 'Canlı').replace('Kıble Bulucu', 'Kıble')}</span></Link>)}
    </nav>
  </div>;
}

function SectionTitle({ eyebrow, title, action }: { eyebrow?: string; title: string; action?: React.ReactNode }) {
  return <div className="mb-6 flex items-end justify-between gap-4"><div>{eyebrow && <p className="mb-2 text-[10px] font-bold uppercase tracking-[.22em] text-[#d4af37]">{eyebrow}</p>}<h2 className="font-[Manrope] text-2xl font-bold tracking-[-.04em] text-[#f5f1df] md:text-3xl">{title}</h2></div>{action}</div>;
}

function CitySelect({ city, setCity }: { city: string; setCity: (city: string) => void }) {
  return <label className="flex items-center gap-2 rounded-xl border border-[#d4af37]/20 bg-[#243223]/80 px-3 py-2 text-xs text-[#d9d2bb]"><MapPin size={14} className="text-[#d4af37]" /><select value={city} onChange={(e) => setCity(e.target.value)} className="bg-transparent font-semibold outline-none" data-testid="select-city">{cities.map((item) => <option className="bg-[#2e3b2b]" key={item}>{item}</option>)}</select></label>;
}

function PrayerStrip({ prayers, loading, error, compact = false }: { prayers: Prayer[]; loading: boolean; error: boolean; compact?: boolean }) {
  const next = getNextPrayer(prayers);
  const countdown = useCountdown(next);
  return <div className={`grid grid-cols-2 gap-2 sm:grid-cols-3 ${compact ? 'lg:grid-cols-6' : 'lg:grid-cols-3'}`}>
    {prayers.map((p, index) => <div key={p.key} className={`relative overflow-hidden rounded-2xl border p-4 ${p.key === next.key ? 'border-[#d4af37]/55 bg-[#d4af37]/[.12]' : 'border-[#d4af37]/10 bg-[#243223]/60'}`} data-testid={`prayer-card-${p.key}`}>
      {p.key === next.key && <span className="absolute right-3 top-3 h-1.5 w-1.5 rounded-full bg-[#d4af37] pulse-soft" />}
      <div className="flex items-start justify-between"><span className="text-[11px] font-semibold text-[#aaa890]">{p.label}</span><span className="arabic text-sm text-[#9e9b7e]">{p.arabic}</span></div>
      <p className={`mt-3 count-number text-2xl font-bold ${p.key === next.key ? 'text-[#d4af37]' : 'text-[#f5f1df]'}`}>{loading ? '— —' : p.time}</p>
      {p.key === next.key && <p className="mt-1 text-[10px] text-[#d4af37]">Sıradaki • {countdown.label}</p>}
      {index === 0 && error && <p className="mt-1 text-[10px] text-[#b7aa81]">Yaklaşık vakit</p>}
    </div>)}
  </div>;
}

function Home() {
  const [city, setCityState] = useState(() => localStorage.getItem('prayer-city') ?? 'Kayseri');
  const setCity = (nextCity: string) => {
    setCityState(nextCity);
    localStorage.setItem('prayer-city', nextCity);
    window.dispatchEvent(new Event('prayer-city-change'));
  };
  const { prayers, loading, error } = usePrayerTimes(city);
  const next = getNextPrayer(prayers);
  const countdown = useCountdown(next);
  const dayHadith = hadiths[new Date().getDate() % hadiths.length];
  return <div className="space-y-10">
    <section className="hero-image fade-up relative min-h-[330px] overflow-hidden rounded-[2rem] border border-[#d4af37]/20 p-7 shadow-2xl shadow-black/20 md:min-h-[365px] md:p-12">
      <div className="relative max-w-xl"><p className="mb-5 text-[10px] font-bold uppercase tracking-[.3em] text-[#e0c55f]">Selamün aleyküm</p><h1 className="font-[Manrope] text-4xl font-extrabold leading-[1.04] tracking-[-.07em] text-[#fff9e6] md:text-6xl">Gününüz<br /><span className="text-[#d4af37]">bereketli</span> olsun.</h1><p className="mt-5 max-w-sm text-sm leading-relaxed text-[#e1dbc8]">Kalbinize iyi gelecek küçük hatırlatmalar, her gün yanınızda.</p><div className="mt-7 flex flex-wrap items-center gap-3"><CitySelect city={city} setCity={setCity} /><span className="flex items-center gap-1.5 text-xs text-[#dfd6bc]"><LocateFixed size={13} className="text-[#d4af37]" />Konumunuz</span></div></div>
      <div className="absolute bottom-6 right-7 hidden text-right md:block"><p className="arabic text-5xl text-[#e1c867]/80">نُورٌ عَلَىٰ نُورٍ</p><p className="mt-1 text-[11px] text-[#dacda9]">Nur üstüne nur</p></div>
    </section>
    <section className="fade-up fade-up-delay-1">
      <div className="mb-5 flex flex-wrap items-end justify-between gap-3"><div><p className="mb-1 text-[10px] font-bold uppercase tracking-[.22em] text-[#d4af37]">{loading ? 'Vakitler yükleniyor' : 'Bugünün vakitleri'}</p><h2 className="font-[Manrope] text-2xl font-bold text-[#f5f1df]">{new Intl.DateTimeFormat('tr-TR', { day: 'numeric', month: 'long' }).format(countdown.date)}</h2></div><Link href="/prayer" className="flex items-center gap-1 text-xs font-semibold text-[#d4af37]" data-testid="link-all-prayer">Tümünü gör <ChevronRight size={15} /></Link></div>
      <PrayerStrip prayers={prayers} loading={loading} error={error} compact />
    </section>
    <section className="fade-up fade-up-delay-2 grid gap-4 md:grid-cols-[1.25fr_.75fr]">
      <div className="glass-panel rounded-[1.7rem] p-6 md:p-7"><div className="flex items-start justify-between"><div><p className="text-[10px] font-bold uppercase tracking-[.2em] text-[#c1b67f]">Sıradaki vakit</p><h3 className="mt-2 text-xl font-bold text-[#f5f1df]">{next.label}</h3><p className="mt-1 text-xs text-[#aaa890]">{next.arabic} · {next.time}</p></div><div className="grid h-12 w-12 place-items-center rounded-2xl bg-[#d4af37]/10 text-[#d4af37]"><Clock3 size={22} /></div></div><div className="mt-6 flex items-end gap-3"><span className="count-number text-5xl font-bold text-[#d4af37] md:text-6xl" data-testid="countdown-home">{countdown.label}</span><span className="mb-2 text-xs text-[#aaa890]">kaldı</span></div><div className="mt-5 h-1 overflow-hidden rounded-full bg-[#d4af37]/10"><div className="h-full w-[63%] rounded-full bg-[#d4af37]" /></div></div>
      <div className="rounded-[1.7rem] border border-[#d4af37]/15 bg-[#75633a]/25 p-6 md:p-7"><div className="flex items-center gap-2 text-[#d4af37]"><Sparkles size={16} /><p className="text-[10px] font-bold uppercase tracking-[.2em]">Günün hadisi</p></div><p className="arabic mt-5 text-right text-2xl leading-relaxed text-[#f5f1df]">إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ</p><p className="mt-4 text-[14px] leading-relaxed text-[#efe9d4]">“{dayHadith.text}”</p><p className="mt-4 text-[11px] text-[#b9ac80]">{dayHadith.narrator} · {dayHadith.source}</p><Link href="/hadith" className="mt-5 inline-flex items-center gap-1 text-xs font-bold text-[#d4af37]" data-testid="link-read-hadith">Hadisi oku <ChevronRight size={15} /></Link></div>
    </section>
    <section className="fade-up fade-up-delay-3"><SectionTitle eyebrow="Keşfet" title="İbadet yolculuğunuz" /><div className="grid grid-cols-2 gap-3 md:grid-cols-3 lg:grid-cols-6">
      {[{ href: '/quran', icon: BookOpen, title: 'Kur’an oku', detail: 'Kalbinle dinle' }, { href: '/qibla', icon: Compass, title: 'Kıbleyi bul', detail: 'Pusula ile yön' }, { href: '/stories', icon: Scroll, title: 'Kıssalar', detail: 'İbretlik hikayeler' }, { href: '/tasbih', icon: CircleHelp, title: 'Tesbih çek', detail: 'Zikrin huzuru' }, { href: '/hadith', icon: Library, title: 'Hadis-i şerif', detail: 'Bugünün sözü' }, { href: '/live', icon: Youtube, title: 'Canlı yayın', detail: 'Mekke ve Medine' }].map(({ href, icon: Icon, title, detail }) => <Link href={href} key={href} className="module-card rounded-[1.5rem] border border-[#d4af37]/12 bg-[#243223]/65 p-5" data-testid={`card-module-${title}`}><Icon size={20} className="text-[#d4af37]" /><h3 className="mt-7 text-sm font-bold text-[#f5f1df]">{title}</h3><p className="mt-1 text-[11px] text-[#9fa28c]">{detail}</p><ChevronRight size={15} className="mt-4 text-[#756d54]" /></Link>)}</div></section>
  </div>;
}

function PrayerPage() {
  const [city, setCityState] = useState(() => localStorage.getItem('prayer-city') ?? 'Kayseri');
  const setCity = (nextCity: string) => {
    setCityState(nextCity);
    localStorage.setItem('prayer-city', nextCity);
    window.dispatchEvent(new Event('prayer-city-change'));
  };
  const { prayers, loading, error, date } = usePrayerTimes(city);
  const next = getNextPrayer(prayers);
  const countdown = useCountdown(next);
  return <div className="space-y-8"><div className="flex flex-wrap items-end justify-between gap-4"><div><p className="mb-2 text-[10px] font-bold uppercase tracking-[.22em] text-[#d4af37]">Vakitler</p><h1 className="font-[Manrope] text-3xl font-extrabold tracking-[-.06em] text-[#f5f1df] md:text-5xl">Namaz vakitleri</h1><p className="mt-3 text-sm text-[#a7a893]">Günün ritmini ibadetle güzelleştirin.</p></div><CitySelect city={city} setCity={setCity} /></div>
    <div className="glass-panel grid items-center gap-5 rounded-[1.7rem] p-6 md:grid-cols-[1fr_auto] md:p-8"><div><p className="text-[10px] font-bold uppercase tracking-[.2em] text-[#d4af37]">Sıradaki namaz</p><div className="mt-2 flex items-baseline gap-3"><h2 className="text-2xl font-bold text-[#f5f1df]">{next.label}</h2><span className="text-sm text-[#aaa890]">{next.time}</span></div><p className="mt-2 flex items-center gap-2 text-xs text-[#aaa890]"><MapPin size={13} className="text-[#d4af37]" />{city} · {date}</p></div><div className="md:text-right"><p className="count-number text-4xl font-bold tracking-tight text-[#d4af37] md:text-5xl" data-testid="countdown-prayer">{countdown.label}</p><p className="mt-1 text-xs text-[#aaa890]">vaktin başlamasına</p></div></div>
    <div className="space-y-3"><SectionTitle eyebrow="Bugün" title="Günlük çizelge" action={<span className="text-xs text-[#989a86]">Türkiye · Metot 13</span>} />{loading ? <PrayerSkeleton /> : <div className="space-y-2">{prayers.map((p) => <div key={p.key} className={`flex items-center justify-between rounded-2xl border px-5 py-4 ${p.key === next.key ? 'border-[#d4af37]/50 bg-[#d4af37]/[.1]' : 'border-[#d4af37]/10 bg-[#243223]/60'}`} data-testid={`row-prayer-${p.key}`}><div className="flex items-center gap-4"><span className={`grid h-9 w-9 place-items-center rounded-xl text-sm ${p.key === next.key ? 'bg-[#d4af37] text-[#2e3b2b]' : 'bg-[#d4af37]/10 text-[#d4af37]'}`}>{p.key === 'Sunrise' ? <Sun size={16} /> : <Clock3 size={16} />}</span><div><p className="font-semibold text-[#f5f1df]">{p.label}</p><p className="text-[11px] text-[#969b87]">{p.arabic}</p></div></div><div className="flex items-center gap-4"><span className="count-number text-xl font-bold text-[#f5f1df]">{p.time}</span>{p.key === next.key && <span className="hidden rounded-full bg-[#d4af37]/15 px-3 py-1 text-[10px] font-bold text-[#d4af37] sm:inline">SIRADAKİ</span>}</div></div>)}</div>}{error && <p className="text-xs text-[#c5b782]">Vakit servisine ulaşılamadı; varsayılan vakitler gösteriliyor.</p>}</div>
    <div className="rounded-[1.7rem] border border-[#d4af37]/10 bg-[#243223]/45 p-6"><div className="flex gap-4"><Compass className="mt-1 text-[#d4af37]" size={20} /><div><h3 className="font-bold text-[#f5f1df]">Vakitler hakkında</h3><p className="mt-2 max-w-2xl text-xs leading-relaxed text-[#aaa890]">Vakitler, Diyanet İşleri Başkanlığı’nın Metot 13 hesaplama yöntemiyle sunulan Aladhan verisinden alınır. Şehrinizi değiştirerek size en yakın çizelgeyi görebilirsiniz.</p></div></div></div>
  </div>;
}

function PrayerSkeleton() { return <div className="space-y-2">{prayerMeta.map((p) => <div key={p.key} className="h-[73px] animate-pulse rounded-2xl bg-[#243223]/80" />)}</div>; }

type Surah = typeof fallbackSurahs[number];

function QuranDetail({
  info,
  ayahs,
  surahLoading,
  setLocation,
}: {
  info: Surah;
  ayahs: typeof fallbackAyahs;
  surahLoading: boolean;
  setLocation: (path: string) => void;
}) {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [audioStatus, setAudioStatus] = useState<'idle' | 'loading' | 'playing' | 'paused' | 'error'>('idle');
  const [audioError, setAudioError] = useState(false);
  useEffect(() => {
    const audio = audioRef.current;
    setAudioStatus('idle');
    setAudioError(false);
    return () => {
      audio?.pause();
      if (audio) audio.currentTime = 0;
    };
  }, [info.number]);
  const toggleRecitation = async () => {
    const audio = audioRef.current;
    if (!audio) return;
    setAudioError(false);
    if (!audio.paused) {
      audio.pause();
      return;
    }
    setAudioStatus('loading');
    try {
      await audio.play();
    } catch {
      setAudioStatus('error');
      setAudioError(true);
    }
  };
  return <div className="space-y-7">
    <button onClick={() => setLocation('/quran')} className="flex items-center gap-2 text-xs font-bold text-[#c8b568]" data-testid="button-back-surahs"><ArrowLeft size={16} />Sure listesine dön</button>
    <div className="relative overflow-hidden rounded-[1.8rem] border border-[#d4af37]/20 bg-[#75633a]/20 p-7 md:p-10">
      <div className="relative text-center">
        {info.number !== 9 && <p dir="rtl" className="arabic mb-5 text-center text-2xl leading-relaxed text-[#d4af37] md:text-3xl">{bismillahArabic}</p>}
        <p className="text-[10px] font-bold uppercase tracking-[.25em] text-[#d4af37]">Sure {info.number} · {info.revelationType === 'Meccan' ? 'Mekkî' : info.revelationType}</p>
        <h1 className="mt-4 text-4xl font-extrabold tracking-[-.04em] text-[#f5f1df] md:text-5xl">{getTurkishSurahName(info.number)}</h1>
        <p className="arabic mt-2 text-3xl text-[#f5f1df]">{info.name}</p>
        <p className="mt-3 text-xs text-[#aaa890]">{info.numberOfAyahs} ayet · Ayet ayet okuma</p>
        <div className="mx-auto mt-6 max-w-2xl rounded-2xl border border-[#d4af37]/20 bg-[#172218]/70 p-4 text-left" data-testid="quran-recitation-player">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="text-[9px] font-bold uppercase tracking-[.18em] text-[#d4af37]">Tilavet · Mişari Râşid el-Afâsî</p>
              <p className="mt-1 text-xs text-[#d6cfb8]">{audioStatus === 'loading' ? 'Ses kaydı yükleniyor…' : audioStatus === 'playing' ? 'Tilavet çalıyor' : audioStatus === 'error' || audioError ? 'Ses kaydı başlatılamadı' : 'Sureyi dinlemeye hazır'}</p>
            </div>
            <button onClick={() => { void toggleRecitation(); }} className="rounded-xl bg-[#d4af37] px-3 py-2 text-xs font-bold text-[#2e3b2b] transition hover:bg-[#e7c759]" data-testid="button-toggle-recitation">{audioStatus === 'playing' ? 'Duraklat' : 'Oynat'}</button>
          </div>
          <audio ref={audioRef} className="mt-3 w-full accent-[#d4af37]" controls preload="none" src={getSurahRecitationUrl(info.number)} aria-label={`${getTurkishSurahName(info.number)} suresi tilaveti`} onLoadStart={() => setAudioStatus('loading')} onCanPlay={() => setAudioStatus((current) => current === 'playing' ? current : 'paused')} onPlay={() => setAudioStatus('playing')} onPause={() => setAudioStatus('paused')} onEnded={() => setAudioStatus('paused')} onError={() => { setAudioStatus('error'); setAudioError(true); }} />
        </div>
      </div>
    </div>
    <div className="mx-auto max-w-4xl space-y-3">
      {surahLoading ? <div className="h-44 animate-pulse rounded-3xl bg-[#243223]" /> : ayahs.map((a) => <article key={a.numberInSurah} className="rounded-3xl border border-[#d4af37]/10 bg-[#243223]/65 p-5 md:p-7" data-testid={`ayah-${a.numberInSurah}`}>
        <div className="flex items-start gap-4"><span className="grid h-8 w-8 shrink-0 place-items-center rounded-full border border-[#d4af37]/35 text-[11px] text-[#d4af37]">{a.numberInSurah}</span><div className="min-w-0 flex-1"><div className="grid gap-5 md:grid-cols-2 md:divide-x md:divide-[#d4af37]/15"><section className="min-w-0 md:pr-6"><p className="mb-2 text-[9px] font-bold uppercase tracking-[.2em] text-[#c2b77f]">Arapça</p><p dir="rtl" className="arabic text-right text-2xl leading-[1.9] text-[#f5f1df] md:text-3xl">{a.arabic}</p></section><section className="min-w-0 border-t border-[#d4af37]/15 pt-5 md:border-t-0 md:pl-6 md:pt-0"><p className="mb-2 text-[9px] font-bold uppercase tracking-[.2em] text-[#c2b77f]">Türkçe anlamı</p><p className="text-[14px] leading-8 text-[#d1ccb8]">{a.tr}</p></section></div></div></div>
      </article>)}
    </div>
  </div>;
}

function QuranPage() {
  const params = useParams<{ number?: string }>();
  const [, setLocation] = useLocation();
  const selected = params.number ? Number(params.number) : null;
  const [surahs, setSurahs] = useState<Surah[]>(fallbackSurahs);
  const [search, setSearch] = useState('');
  const [loadingIndex, setLoadingIndex] = useState(true);
  const [indexError, setIndexError] = useState(false);
  const [ayahs, setAyahs] = useState(fallbackAyahs);
  const [surahLoading, setSurahLoading] = useState(false);
  useEffect(() => {
    fetch('https://api.alquran.cloud/v1/surah').then((r) => { if (!r.ok) throw new Error(); return r.json(); }).then((json) => { if (Array.isArray(json.data)) setSurahs(json.data.map((s: Surah) => ({ ...s, englishName: s.englishName, englishNameTranslation: s.englishNameTranslation }))); }).catch(() => setIndexError(true)).finally(() => setLoadingIndex(false));
  }, []);
  useEffect(() => {
    if (!selected) return;
    setSurahLoading(true);
    fetch(`https://api.alquran.cloud/v1/surah/${selected}/editions/quran-uthmani,tr.diyanet`).then((r) => { if (!r.ok) throw new Error(); return r.json(); }).then((json) => {
      const editions = json.data;
      if (Array.isArray(editions) && editions[0]?.ayahs && editions[1]?.ayahs) setAyahs(normalizeAyahs(selected, editions[0].ayahs, editions[1].ayahs));
    }).catch(() => setAyahs(normalizeAyahs(selected, fallbackAyahs, fallbackAyahs))).finally(() => setSurahLoading(false));
  }, [selected]);
  const visible = useMemo(() => surahs.filter((s) => `${s.number} ${getTurkishSurahName(s.number)} ${s.englishName} ${s.englishNameTranslation} ${s.name}`.toLocaleLowerCase('tr').includes(search.toLocaleLowerCase('tr'))), [surahs, search]);
  if (selected) {
    const info = surahs.find((s) => s.number === selected) ?? fallbackSurahs[0];
    return <QuranDetail info={info} ayahs={ayahs} surahLoading={surahLoading} setLocation={setLocation} />;
    /*
    return <div className="space-y-7"><button onClick={() => setLocation('/quran')} className="flex items-center gap-2 text-xs font-bold text-[#c8b568]" data-testid="button-back-surahs"><ArrowLeft size={16} />Sure listesine dön</button><div className="relative overflow-hidden rounded-[1.8rem] border border-[#d4af37]/20 bg-[#75633a]/20 p-7 md:p-10"><div className="relative text-center"><p className="text-[10px] font-bold uppercase tracking-[.25em] text-[#d4af37]">Sure {info.number} · {info.revelationType === 'Meccan' ? 'Mekkî' : info.revelationType}</p><h1 className="mt-4 text-4xl font-extrabold tracking-[-.04em] text-[#f5f1df] md:text-5xl">{getTurkishSurahName(info.number)}</h1><p className="arabic mt-2 text-3xl text-[#f5f1df]">{info.name}</p><p className="mt-3 text-xs text-[#aaa890]">{info.numberOfAyahs} ayet · Ayet ayet okuma</p><div className="mx-auto mt-6 max-w-2xl rounded-2xl border border-[#d4af37]/20 bg-[#172218]/70 p-4 text-left" data-testid="quran-recitation-player"><div className="flex flex-wrap items-center justify-between gap-3"><div><p className="text-[9px] font-bold uppercase tracking-[.18em] text-[#d4af37]">Tilavet · Mişari Râşid el-Afâsî</p><p className="mt-1 text-xs text-[#d6cfb8]">{audioStatus === 'loading' ? 'Ses kaydı yükleniyor…' : audioStatus === 'playing' ? 'Tilavet çalıyor' : audioStatus === 'error' || audioError ? 'Ses kaydı başlatılamadı' : 'Sureyi dinlemeye hazır'}</p></div><button onClick={() => { void toggleRecitation(); }} className="rounded-xl bg-[#d4af37] px-3 py-2 text-xs font-bold text-[#2e3b2b] transition hover:bg-[#e7c759]" data-testid="button-toggle-recitation">{audioStatus === 'playing' ? 'Duraklat' : 'Oynat'}</button></div><audio ref={audioRef} className="mt-3 w-full accent-[#d4af37]" controls preload="none" src={getSurahRecitationUrl(info.number)} aria-label={`${getTurkishSurahName(info.number)} suresi tilaveti`} onLoadStart={() => setAudioStatus('loading')} onCanPlay={() => setAudioStatus((current) => current === 'playing' ? current : 'paused')} onPlay={() => setAudioStatus('playing')} onPause={() => setAudioStatus('paused')} onEnded={() => setAudioStatus('paused')} onError={() => { setAudioStatus('error'); setAudioError(true); }} /></div></div></div></div><div className="mx-auto max-w-4xl space-y-3">{surahLoading ? <div className="h-44 animate-pulse rounded-3xl bg-[#243223]" /> : ayahs.map((a) => <article key={a.numberInSurah} className="rounded-3xl border border-[#d4af37]/10 bg-[#243223]/65 p-5 md:p-7" data-testid={`ayah-${a.numberInSurah}`}><div className="flex items-start gap-4"><span className="grid h-8 w-8 shrink-0 place-items-center rounded-full border border-[#d4af37]/35 text-[11px] text-[#d4af37]">{a.numberInSurah}</span><div className="min-w-0 flex-1"><div className="grid gap-5 md:grid-cols-2 md:divide-x md:divide-[#d4af37]/15"><section className="min-w-0 md:pr-6"><p className="mb-2 text-[9px] font-bold uppercase tracking-[.2em] text-[#c2b77f]">Arapça</p><p dir="rtl" className="arabic text-right text-2xl leading-[1.9] text-[#f5f1df] md:text-3xl">{a.arabic}</p></section><section className="min-w-0 border-t border-[#d4af37]/15 pt-5 md:border-t-0 md:pl-6 md:pt-0"><p className="mb-2 text-[9px] font-bold uppercase tracking-[.2em] text-[#c2b77f]">Türkçe anlamı</p><p className="text-[14px] leading-8 text-[#d1ccb8]">{a.tr}</p></section></div></div></div></article>)}</div></div>;
    */
  }
  return <div className="space-y-8"><div className="flex flex-wrap items-end justify-between gap-4"><div><p className="mb-2 text-[10px] font-bold uppercase tracking-[.22em] text-[#d4af37]">Tilavet</p><h1 className="font-[Manrope] text-3xl font-extrabold tracking-[-.06em] text-[#f5f1df] md:text-5xl">Kur’an-ı Kerim</h1><p className="mt-3 text-sm text-[#a7a893]">Her ayette kalbe dokunan bir çağrı.</p></div><button className="flex items-center gap-2 rounded-xl border border-[#d4af37]/20 px-3 py-2 text-xs text-[#d6cfb8]" data-testid="button-quran-settings"><Volume2 size={15} className="text-[#d4af37]" /> Sesli okuma</button></div><div className="glass-panel rounded-[1.6rem] p-5"><div className="flex items-center gap-3 border-b border-[#d4af37]/10 pb-4"><Search size={18} className="text-[#d4af37]" /><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Sure ara — isim veya numara" className="w-full bg-transparent text-sm text-[#f5f1df] outline-none placeholder:text-[#7f8876]" data-testid="input-search-surah" />{search && <button onClick={() => setSearch('')} aria-label="Aramayı temizle" data-testid="button-clear-search"><X size={16} className="text-[#aaa890]" /></button>}</div><div className="mt-5 flex items-center justify-between text-xs text-[#9fa28c]"><span>{loadingIndex ? 'Sureler hazırlanıyor…' : `${visible.length} sure`}</span><span className="flex items-center gap-1"><Library size={13} /> 114 sure</span></div></div>{indexError && <div className="rounded-2xl border border-[#d4af37]/20 bg-[#75633a]/15 p-4 text-xs text-[#c8b568]">Sure servisine ulaşılamadı. Temel sureler çevrimdışı olarak hazır.</div>}<div className="grid gap-2 md:grid-cols-2">{visible.map((s) => <button onClick={() => setLocation(`/quran/${s.number}`)} className="quran-row flex items-center gap-4 rounded-2xl border border-[#d4af37]/10 bg-[#243223]/60 p-4 text-left" key={s.number} data-testid={`button-surah-${s.number}`}><span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-[#d4af37]/10 text-xs font-bold text-[#d4af37]">{s.number}</span><span className="min-w-0 flex-1"><strong className="block truncate text-sm text-[#f5f1df]">{getTurkishSurahName(s.number)}</strong><span className="text-[11px] text-[#939985]">{s.numberOfAyahs} ayet</span></span><span className="arabic text-xl text-[#c2b77f]">{s.name}</span><ChevronRight size={16} className="text-[#716d55]" /></button>)}</div>{!visible.length && <div className="rounded-3xl border border-dashed border-[#d4af37]/20 p-12 text-center"><Search className="mx-auto text-[#8e8a69]" size={25} /><p className="mt-3 text-sm text-[#bbb69f]">Aradığınız sure bulunamadı.</p></div>}</div>;
}

function TasbihPage() {
  const presets = [{ name: 'Sübhanallah', target: 33 }, { name: 'Elhamdülillah', target: 33 }, { name: 'Allahu Ekber', target: 33 }, { name: 'La ilahe illallah', target: 99 }];
  const params = new URLSearchParams(window.location.search);
  const requestedName = params.get('name');
  const requestedArabic = params.get('arabic');
  const requestedTarget = Number(params.get('target'));
  const [preset, setPreset] = useState<{ name: string; target: number; arabic?: string }>(
    requestedName && requestedTarget > 0 ? { name: `Yâ ${requestedName}`, target: requestedTarget, arabic: requestedArabic ?? '' } : presets[0],
  );
  const [count, setCount] = useState(() => Number(localStorage.getItem('nur-tasbih-count') ?? 0));
  const [target, setTarget] = useState(() => requestedTarget > 0 ? requestedTarget : Number(localStorage.getItem('nur-tasbih-target') ?? 33));
  useEffect(() => { if (requestedName && requestedTarget > 0) setCount(0); }, []);
  useEffect(() => { localStorage.setItem('nur-tasbih-count', String(count)); localStorage.setItem('nur-tasbih-target', String(target)); }, [count, target]);
  const progress = `${Math.min(100, count / target * 100)}%`;
  const choose = (item: typeof presets[number]) => { setPreset(item); setTarget(item.target); setCount(0); };
  return <div className="mx-auto max-w-5xl space-y-8"><div><p className="mb-2 text-[10px] font-bold uppercase tracking-[.22em] text-[#d4af37]">Zikir</p><h1 className="font-[Manrope] text-3xl font-extrabold tracking-[-.06em] text-[#f5f1df] md:text-5xl">Tesbih</h1><p className="mt-3 text-sm text-[#a7a893]">Dilin zikri, kalbin huzuru.</p></div><div className="grid gap-5 lg:grid-cols-[.8fr_1.2fr]"><div className="glass-panel rounded-[2rem] p-6 md:p-8"><p className="mb-4 text-[10px] font-bold uppercase tracking-[.2em] text-[#aaa277]">Zikir seçin</p><div className="space-y-2">{presets.map((item) => <button onClick={() => choose(item)} key={item.name} className={`flex w-full items-center justify-between rounded-2xl border p-4 text-left ${preset.name === item.name ? 'border-[#d4af37]/45 bg-[#d4af37]/10' : 'border-[#d4af37]/10 bg-[#243223]/50'}`} data-testid={`button-preset-${item.name}`}><span className={`text-sm font-semibold ${preset.name === item.name ? 'text-[#d4af37]' : 'text-[#ded8c5]'}`}>{item.name}</span><span className="text-[11px] text-[#9b9e89]">{item.target}</span></button>)}</div><label className="mt-6 block text-[10px] font-bold uppercase tracking-[.2em] text-[#aaa277]">Hedef sayı</label><input type="number" min="1" value={target} onChange={(e) => setTarget(Math.max(1, Number(e.target.value)))} className="mt-3 w-full rounded-xl border border-[#d4af37]/15 bg-[#243223] px-4 py-3 text-sm text-[#f5f1df] outline-none" data-testid="input-tasbih-target" /></div><div className="rounded-[2rem] border border-[#d4af37]/20 bg-[#243223]/65 p-6 text-center md:p-9"><div className="mb-5 flex items-center justify-between text-xs text-[#9fa28c]"><span>{preset.name}</span><span>{count} / {target}</span></div><div className="mx-auto grid h-64 w-64 place-items-center rounded-full p-3 tasbih-ring md:h-72 md:w-72" style={{ '--progress': progress } as CSSProperties}><div className="grid h-full w-full place-items-center rounded-full bg-[#2e3b2b] shadow-inner shadow-black/30"><div><p className="arabic text-3xl text-[#d4af37]">{preset.arabic || 'سُبْحَانَ اللَّهِ'}</p><p className="count-number mt-2 text-6xl font-bold text-[#f5f1df]" data-testid="text-tasbih-count">{count}</p><p className="mt-1 text-xs text-[#9fa28c]">zikir</p></div></div></div><button onClick={() => setCount((v) => Math.min(target, v + 1))} className="mx-auto mt-7 grid h-20 w-20 place-items-center rounded-full bg-[#d4af37] text-[#2e3b2b] shadow-xl shadow-[#d4af37]/15 transition-transform hover:scale-105 active:scale-95" aria-label="Bir tesbih ekle" data-testid="button-tasbih-plus"><Plus size={32} strokeWidth={2.5} /></button><div className="mt-5 flex justify-center gap-2"><button onClick={() => setCount((v) => Math.max(0, v - 1))} className="flex items-center gap-2 rounded-xl border border-[#d4af37]/15 px-4 py-2 text-xs text-[#bcb9a5]" data-testid="button-tasbih-minus"><Minus size={14} /> Bir azalt</button><button onClick={() => setCount(0)} className="flex items-center gap-2 rounded-xl border border-[#d4af37]/15 px-4 py-2 text-xs text-[#bcb9a5]" data-testid="button-tasbih-reset"><RotateCcw size={14} /> Sıfırla</button></div></div></div><div className="flex items-center gap-3 rounded-2xl border border-[#d4af37]/10 bg-[#75633a]/15 px-5 py-4 text-xs text-[#b9af87]"><Heart size={16} className="text-[#d4af37]" />Zikriniz bu cihazda saklanır; sayacınız sayfayı kapattığınızda kaybolmaz.</div></div>;
}

function EsmaulHusnaPage() {
  const [, setLocation] = useLocation();
  const [search, setSearch] = useState('');
  const query = search.toLocaleLowerCase('tr').trim();
  const visible = esmaNames.filter((name) => `${name.title} ${name.meaning} ${name.arabic}`.toLocaleLowerCase('tr').includes(query));
  return <div className="min-w-0 space-y-8"><SectionTitle eyebrow="99 güzel isim" title="Esmaül Hüsna" /><p className="-mt-5 max-w-2xl text-sm leading-7 text-[#a7a893]">Allah’ın güzel isimlerini, kısa anlamlarını ve geleneksel zikir sayılarını keşfedin.</p><div className="glass-panel sticky top-[72px] z-10 min-w-0 rounded-[1.4rem] p-4 md:top-4"><div className="flex min-w-0 items-center gap-3"><Search size={18} className="shrink-0 text-[#d4af37]" /><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Türkçe veya Arapça isim ara" className="min-w-0 flex-1 bg-transparent text-sm text-[#f5f1df] outline-none placeholder:text-[#7f8876]" data-testid="input-search-esma" />{search && <button className="shrink-0" onClick={() => setSearch('')} aria-label="Aramayı temizle"><X size={16} className="text-[#aaa890]" /></button>}</div></div><div className="flex flex-wrap items-center justify-between gap-2 text-xs text-[#9fa28c]"><span>{visible.length} isim</span><span>Toplam 99 isim</span></div><div className="grid min-w-0 gap-4 sm:grid-cols-2 xl:grid-cols-3">{visible.map((name) => <article key={name.id} className="flex min-w-0 min-h-[270px] flex-col rounded-[1.7rem] border border-[#d4af37]/15 bg-[#243223]/65 p-5"><div className="flex min-w-0 items-start justify-between gap-2"><span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-[#d4af37]/10 text-[11px] font-bold text-[#d4af37]">{name.id}</span><p dir="rtl" className="arabic min-w-0 max-w-[85%] break-words text-right text-3xl text-[#e0c45a]">{name.arabic}</p></div><h2 className="mt-6 break-words text-lg font-extrabold text-[#f5f1df]">{name.title}</h2><p className="mt-2 flex-1 break-words text-sm leading-6 text-[#aaa890]">{name.meaning}</p><div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-[#d4af37]/10 pt-4"><span className="min-w-0 flex-1 break-words text-xs font-bold text-[#c6b66f]">Yâ {name.title} · {name.target}</span><button onClick={() => setLocation(`/tasbih?name=${encodeURIComponent(name.title)}&arabic=${encodeURIComponent(name.arabic)}&target=${name.target}`)} className="shrink-0 rounded-xl bg-[#d4af37] px-3 py-2 text-xs font-extrabold text-[#2e3b2b]" data-testid={`button-start-esma-${name.id}`}>Zikre Başla</button></div></article>)}</div>{!visible.length && <div className="rounded-3xl border border-dashed border-[#d4af37]/20 p-12 text-center text-sm text-[#bbb69f]">Aramanızla eşleşen isim bulunamadı.</div>}<p className="text-center text-[11px] leading-5 text-[#858a78]">Zikir sayıları geleneksel ebced değerleridir; dinî bir zorunluluk ifade etmez.</p></div>;
}

function HadithPage() {
  const [index, setIndex] = useState(() => new Date().getDate() % hadiths.length);
  const hadith = hadiths[index];
  return <div className="mx-auto max-w-4xl space-y-9"><div className="text-center"><p className="mb-2 text-[10px] font-bold uppercase tracking-[.25em] text-[#d4af37]">Günün hatırlatması</p><h1 className="font-[Manrope] text-3xl font-extrabold tracking-[-.06em] text-[#f5f1df] md:text-5xl">Hadis-i şerif</h1><p className="mt-3 text-sm text-[#a7a893]">Güzel söz, güzel bir başlangıçtır.</p></div><article className="relative overflow-hidden rounded-[2rem] border border-[#d4af37]/25 bg-[#75633a]/20 p-7 text-center md:p-14"><span className="absolute left-7 top-7 font-serif text-7xl leading-none text-[#d4af37]/40">“</span><div className="relative"><p className="arabic text-4xl leading-[1.7] text-[#e6c961] md:text-5xl">إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ</p><div className="mx-auto my-8 h-px max-w-[180px] gold-line" /><p className="text-xl font-medium leading-[1.8] text-[#f5f1df] md:text-2xl">“{hadith.text}”</p><p className="mt-8 text-xs font-semibold text-[#d4af37]">{hadith.narrator}</p><p className="mt-2 text-[11px] text-[#aaa890]">{hadith.source}</p></div></article><div className="flex justify-center gap-3"><button onClick={() => setIndex((i) => (i - 1 + hadiths.length) % hadiths.length)} className="flex items-center gap-2 rounded-xl border border-[#d4af37]/20 px-4 py-3 text-xs font-bold text-[#d9d2bb]" data-testid="button-hadith-previous"><ArrowLeft size={15} /> Önceki</button><button onClick={() => setIndex(Math.floor(Math.random() * hadiths.length))} className="flex items-center gap-2 rounded-xl bg-[#d4af37] px-5 py-3 text-xs font-bold text-[#2e3b2b]" data-testid="button-hadith-random"><Sparkles size={15} /> Başka bir hadis</button></div><div className="grid gap-3 sm:grid-cols-3"><div className="rounded-2xl border border-[#d4af37]/10 bg-[#243223]/55 p-5 text-center"><p className="count-number text-2xl font-bold text-[#d4af37]">{index + 1}</p><p className="mt-1 text-[11px] text-[#9fa28c]">bugünkü sıra</p></div><div className="rounded-2xl border border-[#d4af37]/10 bg-[#243223]/55 p-5 text-center"><p className="text-2xl font-bold text-[#f5f1df]">Sahih</p><p className="mt-1 text-[11px] text-[#9fa28c]">kaynak seçkisi</p></div><div className="rounded-2xl border border-[#d4af37]/10 bg-[#243223]/55 p-5 text-center"><p className="text-2xl font-bold text-[#f5f1df]">Türkçe</p><p className="mt-1 text-[11px] text-[#9fa28c]">anlamıyla</p></div></div></div>;
}

/* ─── Dua data ────────────────────────────────────────────────────────── */
type Dua = { id: string; category: string; title: string; arabic: string; transliteration: string; turkish: string; source: string };
const DUA_LIST: Dua[] = [
  /* Yemek */
  { id: 'yemek-once', category: 'Yemek', title: 'Yemek Öncesi', arabic: 'بِسْمِ اللَّهِ', transliteration: 'Bismillâh.', turkish: 'Allah\'ın adıyla (yiyorum).', source: 'Buhârî, Et\'ime 2' },
  { id: 'yemek-sonra', category: 'Yemek', title: 'Yemek Sonrası', arabic: 'الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مِنَ الْمُسْلِمِينَ', transliteration: 'Elhamdülillâhillezî et\'amenâ ve sekânâ ve ce\'alenâ minel müslimîn.', turkish: 'Bizi yediren, içiren ve müslümanlardan kılan Allah\'a hamdolsun.', source: 'Ebû Dâvûd, Et\'ime 52' },
  /* Günlük – Sabah/Akşam */
  { id: 'sabah-uyanis', category: 'Günlük', title: 'Uyanış Duası', arabic: 'الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ', transliteration: 'Elhamdülillâhillezî ahyânâ ba\'de mâ emâtenâ ve ileyhin-nüşûr.', turkish: 'Bizi öldürdükten sonra tekrar dirilten Allah\'a hamdolsun. Dönüş O\'nadır.', source: 'Buhârî, De\'avât 8' },
  { id: 'uyku-dua', category: 'Günlük', title: 'Uyumadan Önce', arabic: 'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا', transliteration: 'Bismikellâhümme emûtü ve ahyâ.', turkish: 'Allahım! Senin adınla ölür ve yaşarım.', source: 'Buhârî, De\'avât 9' },
  { id: 'eve-giris', category: 'Günlük', title: 'Eve Girerken', arabic: 'بِسْمِ اللَّهِ وَلَجْنَا وَبِسْمِ اللَّهِ خَرَجْنَا وَعَلَى اللَّهِ رَبِّنَا تَوَكَّلْنَا', transliteration: 'Bismillâhi velecnâ ve bismillâhi haracnâ ve alallâhi Rabbinâ tevekkelnâ.', turkish: 'Allah\'ın adıyla girdik, Allah\'ın adıyla çıktık; Rabbimiz Allah\'a tevekkül ettik.', source: 'Ebû Dâvûd, Edeb 103' },
  { id: 'evden-cikis', category: 'Günlük', title: 'Evden Çıkarken', arabic: 'بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّهِ وَلاَ حَوْلَ وَلاَ قُوَّةَ إِلاَّ بِاللَّهِ', transliteration: 'Bismillâhi tevekkeltü alallâhi ve lâ havle ve lâ kuvvete illâ billâh.', turkish: 'Allah\'ın adıyla, Allah\'a tevekkül ettim. Güç ve kuvvet ancak Allah\'a aittir.', source: 'Tirmizî, De\'avât 44' },
  { id: 'tuvalet-giris', category: 'Günlük', title: 'Tuvalete Girerken', arabic: 'اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْخُبْثِ وَالْخَبَائِثِ', transliteration: 'Allâhümme innî eûzü bike minel hubsi vel habâis.', turkish: 'Allahım! Erkek ve dişi şeytanlardan sana sığınırım.', source: 'Buhârî, Vudû 9' },
  { id: 'tuvalet-cikis', category: 'Günlük', title: 'Tuvaletten Çıkarken', arabic: 'غُفْرَانَكَ', transliteration: 'Gufrâneke.', turkish: 'Mağfiretini dilerim (Allahım).', source: 'Tirmizî, Tahâret 8' },
  { id: 'sefer', category: 'Günlük', title: 'Yolculuk Duası', arabic: 'سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُونَ', transliteration: 'Sübhânellezî sehara lenâ hâzâ ve mâ künnâ lehu mukrinîn. Ve innâ ilâ Rabbinâ lemünkalibûn.', turkish: 'Bunu bize boyun eğdireni tesbih ederiz; biz buna güç yetiremezdik. Şüphesiz Rabbimize döneceğiz.', source: 'Ebû Dâvûd, Cihâd 72' },
  /* Namaz */
  { id: 'ezan-sonrasi', category: 'Namaz', title: 'Ezan Sonrası Dua', arabic: 'اللَّهُمَّ رَبَّ هَذِهِ الدَّعْوَةِ التَّامَّةِ وَالصَّلاَةِ الْقَائِمَةِ آتِ مُحَمَّدًا الْوَسِيلَةَ وَالْفَضِيلَةَ وَابْعَثْهُ مَقَامًا مَحْمُودًا الَّذِي وَعَدْتَهُ إِنَّكَ لَا تُخْلِفُ الْمِيعَادَ', transliteration: 'Allâhümme Rabbe hâzihed-da\'vetit-tâmmeti ves-salâtil kâimeti, âti Muhammeden el-vesîlete vel-fadîlete, veb\'ashu makâmen mahmûdenillezî ve\'adtehu, inneke lâ tuhliful mîâd.', turkish: 'Allahım! Şu eksiksiz davetin ve kılınacak namazın Rabbi! Muhammed\'e vesile ve fazileti ver; onu vadettiğin övgüye değer makama ulaştır. Şüphesiz sen sözünden dönmezsin.', source: 'Buhârî, Ezân 8' },
  { id: 'kunut', category: 'Namaz', title: 'Kunut Duası', arabic: 'اللَّهُمَّ اهْدِنَا فِيمَنْ هَدَيْتَ وَعَافِنَا فِيمَنْ عَافَيْتَ وَتَوَلَّنَا فِيمَنْ تَوَلَّيْتَ وَبَارِكْ لَنَا فِيمَا أَعْطَيْتَ وَقِنَا شَرَّ مَا قَضَيْتَ إِنَّكَ تَقْضِي وَلَا يُقْضَى عَلَيْكَ وَإِنَّهُ لَا يَذِلُّ مَنْ وَالَيْتَ تَبَارَكْتَ رَبَّنَا وَتَعَالَيْتَ', transliteration: 'Allâhümmehdinâ fîmen hedeyît, ve âfinâ fîmen âfeyt, ve tevellena fîmen tevelleyt, ve bârik lenâ fîmâ a\'tayt, ve kınâ şerra mâ kadayt. İnneke takdî ve lâ yukdâ aleyk. Ve innehü lâ yezillü men vâleyt. Tebârekte Rabbenâ ve teâleyt.', turkish: 'Allahım! Hidayet ettiklerin arasında bize de hidayet et; afiyet verdiklerin arasında bize de afiyet ver; dost edindiklerin arasında bizi de dost edin; verdiğin şeyleri bize hayırlı kıl; hükmettiğin şeylerin şerrinden bizi koru. Şüphesiz sen hükmedersin, sana hüküm verilmez. Dost edindiklerine zillet gelmez. Sen yücesin Rabbimiz ve büyüksün.', source: 'Ebû Dâvûd, Vitr 5' },
  /* Sure/Dua */
  { id: 'fatiha', category: 'Sure', title: 'Fâtiha Sûresi', arabic: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ ۝ الرَّحْمَٰنِ الرَّحِيمِ ۝ مَالِكِ يَوْمِ الدِّينِ ۝ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ۝ اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ ۝ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ', transliteration: 'Bismillâhirrahmânirrahîm. Elhamdü lillâhi Rabbil\'âlemîn. Errahmânirrahîm. Mâliki yevmiddîn. İyyâke na\'büdü ve iyyâke neste\'în. İhdinessırâtel müstekîm. Sırâtallezîne en\'amte aleyhim, ğayril mağdûbi aleyhim veleddâllîn.', turkish: 'Rahman ve Rahim Allah\'ın adıyla. Hamd âlemlerin Rabbi Allah\'a mahsustur. O, Rahman ve Rahim\'dir. Din (hesap) gününün sahibidir. Yalnız sana ibadet eder, yalnız senden yardım dileriz. Bizi doğru yola ilet. Nimet verdiklerinin yoluna; gazaba uğrayanların ve sapkınların yoluna değil.', source: 'Kur\'an 1:1-7' },
  { id: 'ihlas', category: 'Sure', title: 'İhlâs Sûresi', arabic: 'قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ', transliteration: 'Kul huvallâhu ahad. Allâhus-samed. Lem yelid ve lem yûled. Ve lem yekün lehû küfüven ahad.', turkish: 'De ki: O Allah birdir. Allah Samed\'dir (hiçbir şeye muhtaç olmayan, herkesin muhtaç olduğu). O doğurmamış ve doğurulmamıştır. Hiçbir şey O\'na denk değildir.', source: 'Kur\'an 112:1-4' },
  { id: 'felak', category: 'Sure', title: 'Felak Sûresi', arabic: 'قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ۝ مِن شَرِّ مَا خَلَقَ ۝ وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ ۝ وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ۝ وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ', transliteration: 'Kul eûzü birabbil-felek. Min şerri mâ halak. Ve min şerri ğâsikın izâ vekab. Ve min şerrinneffâsâti fil\'ukad. Ve min şerri hâsidin izâ hased.', turkish: 'De ki: Yarattığı şeylerin şerrinden, karanlığı çöktüğünde gecenin şerrinden, düğümlere üfleyenlerin şerrinden, haset ettiğinde hasedçinin şerrinden, şafağın Rabbine sığınırım.', source: 'Kur\'an 113:1-5' },
  { id: 'nas', category: 'Sure', title: 'Nâs Sûresi', arabic: 'قُلْ أَعُوذُ بِرَبِّ النَّاسِ ۝ مَلِكِ النَّاسِ ۝ إِلَٰهِ النَّاسِ ۝ مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ۝ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ۝ مِنَ الْجِنَّةِ وَالنَّاسِ', transliteration: 'Kul eûzü birabbin-nâs. Melikin-nâs. İlâhin-nâs. Min şerril vesvâsil-hannâs. Ellezî yüvesvisü fî sudûrin-nâs. Minel cinneti ven-nâs.', turkish: 'De ki: İnsanların Rabbine, insanların Melik\'ine, insanların İlah\'ına sığınırım. Sinsi vesvesecinin şerrinden; o ki insanların göğüslerine vesvese verir; cinlerden ve insanlardan olanların şerrinden.', source: 'Kur\'an 114:1-6' },
  /* Çeşitli */
  { id: 'istigfar', category: 'Çeşitli', title: 'İstiğfar', arabic: 'أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ الَّذِي لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ', transliteration: 'Estağfirullâhel\'azîmellezî lâ ilâhe illâ huvel-hayyel-kayyûme ve etûbü ileyh.', turkish: 'Kendisinden başka ilah olmayan, Hayy ve Kayyum olan Yüce Allah\'tan bağışlanma diler ve O\'na tevbe ederim.', source: 'Tirmizî, De\'avât 15' },
  { id: 'salavat', category: 'Çeşitli', title: 'Salât-ı İbrâhîmiyye', arabic: 'اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ كَمَا صَلَّيْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ إِنَّكَ حَمِيدٌ مَجِيدٌ ۝ اللَّهُمَّ بَارِكْ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ كَمَا بَارَكْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ إِنَّكَ حَمِيدٌ مَجِيدٌ', transliteration: 'Allâhümme salli alâ Muhammed ve alâ âli Muhammed, kemâ salleyte alâ İbrâhîme ve alâ âli İbrâhîm, inneke hamîdün mecîd. Allâhümme bârik alâ Muhammed ve alâ âli Muhammed, kemâ bârekte alâ İbrâhîme ve alâ âli İbrâhîm, inneke hamîdün mecîd.', turkish: 'Allahım! İbrahim\'e ve İbrahim\'in ailesine rahmetle muamele ettiğin gibi Muhammed\'e ve Muhammed\'in ailesine de rahmetle muamele et. Şüphesiz sen övgüye layıksın, yücesin. Allahım! İbrahim\'e ve İbrahim\'in ailesine bereket verdiğin gibi Muhammed\'e ve Muhammed\'in ailesine de bereket ver. Şüphesiz sen övgüye layıksın, yücesin.', source: 'Buhârî, Enbiyâ 10' },
  { id: 'subhane', category: 'Çeşitli', title: 'Sabah–Akşam Tesbih', arabic: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ', transliteration: 'Sübhânallâhi ve bihamdih.', turkish: 'Allah\'ı hamd ile tesbih ederim.', source: 'Buhârî, De\'avât 65; Müslim, Zikir 28' },
  { id: 'ayetkursi', category: 'Çeşitli', title: 'Âyetü\'l-Kürsî', arabic: 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَن ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ', transliteration: 'Allâhü lâ ilâhe illâ hüvel hayyül kayyûm. Lâ te\'huzühû sinetün ve lâ nevm. Lehu mâ fis-semâvâti ve mâ fil-ard. Men zellezî yeşfe\'u indehû illâ bi\'iznîh. Ya\'lemü mâ beyne eydîhim ve mâ halfehüm. Ve lâ yühîtûne bişey\'in min ilmihî illâ bimâ şâe. Vesi\'a kürsiyyühüs-semâvâti vel-ard. Ve lâ yeûdühü hıfzuhumâ. Ve hüvel aliyyül azîm.', turkish: 'Allah, kendisinden başka hiçbir ilah olmayandır. O, Hayy\'dır, Kayyum\'dur. O\'nu ne uyuklama, ne de uyku yakalar. Göklerde ve yerde ne varsa O\'nundur. O\'nun izni olmadan katında kim şefaat edebilir? O, önlerindekini ve arkalarındakini bilir. Onlar, O\'nun ilminden dilediği kadarından başka bir şeyi kavrayamazlar. O\'nun kürsüsü gökleri ve yeri kaplamıştır. Onları koruyup gözetmek O\'na ağır gelmez. O, Yüce\'dir, Azîm\'dir.', source: 'Kur\'an 2:255' },
];
const DUA_CATEGORIES = ['Tümü', 'Yemek', 'Günlük', 'Namaz', 'Sure', 'Çeşitli'];

function DuaCard({ dua }: { dua: Dua }) {
  return (
    <article className="rounded-3xl border border-[#d4af37]/12 bg-[#243223]/65 p-5 md:p-6">
      <div className="mb-3 flex items-center gap-2">
        <span className="rounded-lg bg-[#d4af37]/10 px-2 py-0.5 text-[10px] font-bold uppercase tracking-[.18em] text-[#d4af37]">{dua.category}</span>
        <h3 className="text-sm font-bold text-[#f5f1df]">{dua.title}</h3>
      </div>
      <p dir="rtl" className="arabic mb-4 text-right text-xl leading-[2] text-[#e6d896] md:text-2xl">{dua.arabic}</p>
      <p className="mb-2 text-[11px] italic leading-relaxed text-[#a9a58a]">{dua.transliteration}</p>
      <p className="mb-4 text-[13px] leading-relaxed text-[#cec9b4]">{dua.turkish}</p>
      <p className="mt-3 text-[10px] text-[#87866d]">{dua.source}</p>
    </article>
  );
}

function DualarPage() {
  const [cat, setCat] = useState('Tümü');
  const [search, setSearch] = useState('');
  const visible = useMemo(() => DUA_LIST.filter(d => (cat === 'Tümü' || d.category === cat) && (d.title + d.arabic + d.turkish).toLocaleLowerCase('tr').includes(search.toLocaleLowerCase('tr'))), [cat, search]);
  return (
    <div className="space-y-8">
      <div>
        <p className="mb-2 text-[10px] font-bold uppercase tracking-[.22em] text-[#d4af37]">İslami Dualar</p>
        <h1 className="font-[Manrope] text-3xl font-extrabold tracking-[-.06em] text-[#f5f1df] md:text-5xl">Dualar</h1>
        <p className="mt-3 text-sm text-[#a7a893]">Günlük hayatınıza eşlik eden mübarek dualar ve zikirler.</p>
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-2 rounded-xl border border-[#d4af37]/20 bg-[#243223]/80 px-3 py-2 text-xs">
          <Search size={14} className="text-[#d4af37]" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Dua ara…" className="w-40 bg-transparent text-[#f5f1df] outline-none placeholder:text-[#7f8876]" />
          {search && <button onClick={() => setSearch('')}><X size={14} className="text-[#aaa890]" /></button>}
        </div>
        <div className="flex flex-wrap gap-2">
          {DUA_CATEGORIES.map(c => (
            <button key={c} onClick={() => setCat(c)} className={`rounded-xl px-3 py-1.5 text-xs font-bold transition ${cat === c ? 'bg-[#d4af37] text-[#2e3b2b]' : 'border border-[#d4af37]/20 bg-[#243223]/60 text-[#c8c3a8] hover:border-[#d4af37]/40'}`}>{c}</button>
          ))}
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        {visible.map(d => <DuaCard key={d.id} dua={d} />)}
      </div>
      {!visible.length && (
        <div className="rounded-3xl border border-dashed border-[#d4af37]/20 p-12 text-center">
          <Scroll className="mx-auto text-[#8e8a69]" size={25} />
          <p className="mt-3 text-sm text-[#bbb69f]">Aradığınız dua bulunamadı.</p>
        </div>
      )}
    </div>
  );
}

/* ─── Prayer position SVGs ────────────────────────────────────────────── */
/* Prayer position SVGs – side-profile stick figures */
function SvgKiyamTekbir() {
  // Front view: standing, arms raised to ear level (İftitah Tekbiri)
  return (
    <svg viewBox="0 0 100 125" className="mx-auto h-24 w-auto" aria-hidden="true">
      <circle cx="50" cy="12" r="9" fill="none" stroke="#d4af37" strokeWidth="2.5" />
      {/* Body */}
      <line x1="50" y1="21" x2="50" y2="72" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Left upper arm → elbow at ear height */}
      <line x1="50" y1="34" x2="24" y2="24" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Left forearm upward (beside ear) */}
      <line x1="24" y1="24" x2="24" y2="10" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Right upper arm */}
      <line x1="50" y1="34" x2="76" y2="24" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Right forearm upward */}
      <line x1="76" y1="24" x2="76" y2="10" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Left leg */}
      <line x1="50" y1="72" x2="37" y2="102" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Right leg */}
      <line x1="50" y1="72" x2="63" y2="102" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Left foot */}
      <line x1="37" y1="102" x2="26" y2="105" stroke="#d4af37" strokeWidth="2" strokeLinecap="round" />
      {/* Right foot */}
      <line x1="63" y1="102" x2="74" y2="105" stroke="#d4af37" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}
function SvgKiyam() {
  // Front view: standing, hands folded at navel (Kıyam / Kıraat)
  return (
    <svg viewBox="0 0 100 125" className="mx-auto h-24 w-auto" aria-hidden="true">
      <circle cx="50" cy="12" r="9" fill="none" stroke="#d4af37" strokeWidth="2.5" />
      <line x1="50" y1="21" x2="50" y2="72" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Left arm → down and inward */}
      <line x1="50" y1="34" x2="33" y2="53" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Left forearm across to navel */}
      <line x1="33" y1="53" x2="52" y2="57" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Right arm → down and inward */}
      <line x1="50" y1="34" x2="67" y2="53" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Right forearm across to navel */}
      <line x1="67" y1="53" x2="48" y2="57" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="50" y1="72" x2="37" y2="102" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="50" y1="72" x2="63" y2="102" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="37" y1="102" x2="26" y2="105" stroke="#d4af37" strokeWidth="2" strokeLinecap="round" />
      <line x1="63" y1="102" x2="74" y2="105" stroke="#d4af37" strokeWidth="2" strokeLinecap="round" />
    </svg>
  );
}
function SvgRuku() {
  // Side view (facing left): body horizontal, legs vertical → clear 90° bow
  return (
    <svg viewBox="0 0 155 115" className="mx-auto h-24 w-auto" aria-hidden="true">
      {/* Head – at the left end of the horizontal torso */}
      <circle cx="26" cy="46" r="9" fill="none" stroke="#d4af37" strokeWidth="2.5" />
      {/* Horizontal torso (neck → hips) */}
      <line x1="35" y1="48" x2="106" y2="49" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Left (near) leg – vertical */}
      <line x1="100" y1="49" x2="92" y2="100" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Right (far) leg – vertical, offset */}
      <line x1="108" y1="49" x2="116" y2="100" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Left foot */}
      <line x1="92" y1="100" x2="79" y2="103" stroke="#d4af37" strokeWidth="2" strokeLinecap="round" />
      {/* Right foot */}
      <line x1="116" y1="100" x2="128" y2="103" stroke="#d4af37" strokeWidth="2" strokeLinecap="round" />
      {/* Left arm – from shoulder down to left knee */}
      <line x1="72" y1="49" x2="90" y2="78" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Right arm – from shoulder down to right knee */}
      <line x1="72" y1="49" x2="116" y2="78" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Knee dots */}
      <circle cx="90" cy="78" r="3.5" fill="#d4af37" />
      <circle cx="116" cy="78" r="3.5" fill="#d4af37" />
    </svg>
  );
}
function SvgSecde() {
  // Side view (facing left): head on ground, body arched up, knees on ground
  return (
    <svg viewBox="0 0 165 92" className="mx-auto h-20 w-auto" aria-hidden="true">
      {/* Dashed ground line */}
      <line x1="4" y1="80" x2="158" y2="80" stroke="#d4af37" strokeWidth="1" strokeLinecap="round" strokeDasharray="5 4" opacity="0.35" />
      {/* Head – forehead touching ground */}
      <circle cx="18" cy="62" r="8" fill="none" stroke="#d4af37" strokeWidth="2.5" />
      {/* Upper body – angled up from neck to hips (arch) */}
      <line x1="26" y1="58" x2="52" y2="42" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      <line x1="52" y1="42" x2="74" y2="33" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Thigh – from hips down to knees */}
      <line x1="74" y1="33" x2="92" y2="67" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Shin – from knees along the ground backward */}
      <line x1="92" y1="67" x2="136" y2="72" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Feet / toes pointing back */}
      <line x1="136" y1="72" x2="150" y2="64" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Left arm – from shoulder to palm on the ground (beside head) */}
      <line x1="46" y1="46" x2="20" y2="76" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Right arm – parallel */}
      <line x1="46" y1="46" x2="34" y2="76" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Palms flat on ground */}
      <line x1="6" y1="76" x2="34" y2="76" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}
function SvgOturuş() {
  // Front view: sitting on heels, hands resting on thighs/knees
  return (
    <svg viewBox="0 0 120 115" className="mx-auto h-24 w-auto" aria-hidden="true">
      <circle cx="60" cy="12" r="9" fill="none" stroke="#d4af37" strokeWidth="2.5" />
      {/* Body */}
      <line x1="60" y1="21" x2="60" y2="58" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Left arm – down to left knee */}
      <line x1="60" y1="35" x2="38" y2="53" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Right arm – down to right knee */}
      <line x1="60" y1="35" x2="82" y2="53" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Hand dots on knees */}
      <circle cx="38" cy="53" r="3.5" fill="#d4af37" />
      <circle cx="82" cy="53" r="3.5" fill="#d4af37" />
      {/* Left thigh – going out and down */}
      <line x1="56" y1="58" x2="26" y2="73" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Left shin – going down */}
      <line x1="26" y1="73" x2="20" y2="100" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Left foot – flat (sitting on it) */}
      <line x1="20" y1="100" x2="46" y2="103" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Right thigh */}
      <line x1="64" y1="58" x2="94" y2="73" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Right shin */}
      <line x1="94" y1="73" x2="100" y2="100" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
      {/* Right foot – flat */}
      <line x1="100" y1="100" x2="74" y2="103" stroke="#d4af37" strokeWidth="2.5" strokeLinecap="round" />
    </svg>
  );
}

const PRAYER_POSITIONS = [
  { key: 'tekbir', label: 'İftitah Tekbiri', desc: 'Eller kulaklara kaldırılır, "Allahu Ekber" denir.', image: 'prayer-figures/tekbir.png' },
  { key: 'kiyam', label: 'Kıyam', desc: 'Elleri göbek altında kavuşturarak Sübhâneke, Fâtiha ve bir sure okunur.', image: 'prayer-figures/kiyam.png' },
  { key: 'ruku', label: 'Rükû', desc: 'Bel 90° eğilir, eller dizlerin üzerine konur, "Sübhâne Rabbiyel Azîm" 3 kez okunur.', image: 'prayer-figures/ruku.png' },
  { key: 'secde', label: 'Secde', desc: 'Alın, burun, iki el, iki diz ve ayak parmaklarıyla yere kapanılır, "Sübhâne Rabbiyel A\'lâ" 3 kez okunur.', image: 'prayer-figures/secde.png' },
  { key: 'oturuş', label: 'Oturuş (Ka\'de)', desc: 'İki secde arasında kısaca oturulur; son rek\'atte Ettehiyyâtü ve salavât okunur.', image: 'prayer-figures/oturus.png' },
];

const NAMAZ_TABLE = [
  { name: 'Sabah', arabic: 'الفجر', sunnet: [{ label: '2 Sünnet', type: 'before' }], farz: '2 Farz', total: 4 },
  { name: 'Öğle', arabic: 'الظهر', sunnet: [{ label: '4 Sünnet', type: 'before' }, { label: '2 Sünnet', type: 'after' }], farz: '4 Farz', total: 10 },
  { name: 'İkindi', arabic: 'العصر', sunnet: [{ label: '4 Sünnet', type: 'before' }], farz: '4 Farz', total: 8 },
  { name: 'Akşam', arabic: 'المغرب', sunnet: [{ label: '2 Sünnet', type: 'after' }], farz: '3 Farz', total: 5 },
  { name: 'Yatsı', arabic: 'العشاء', sunnet: [{ label: '4 Sünnet', type: 'before' }, { label: '2 Sünnet', type: 'after' }, { label: '3 Vitr', type: 'vitr' }], farz: '4 Farz', total: 13 },
];

const NAMAZ_STEPS = [
  { step: 1, title: 'Niyet', detail: 'Hangi namazı kılacağınıza kalbinizden niyet edin. Kıbley yönüne dönün.' },
  { step: 2, title: 'İftitah Tekbiri', detail: '"Allahu Ekber" diyerek elleri kulaklara kaldırın; kadınlar göğüs hizasına, erkekler kulak memesine kadar kaldırır.' },
  { step: 3, title: 'Kıyam — Sübhâneke', detail: '"Sübhânekellâhümme ve bihamdik…" duasını okuyun, ardından "Eûzü billâhi mineş-şeytânirracîm, Bismillâhirrahmânirrahîm" deyin.' },
  { step: 4, title: 'Kıyam — Fâtiha', detail: 'Fâtiha sûresini okuyun. İlk rek\'atte ardından bir sure veya en az üç ayet okuyun.' },
  { step: 5, title: 'Rükû', detail: '"Allahu Ekber" diyerek öne eğilin. Elleri dizlerin üzerine koyun, sırtı düz tutun. "Sübhâne Rabbiyel Azîm" üç kez okuyun.' },
  { step: 6, title: 'Kıyama Kalkış', detail: '"Semiallâhu limen hamideh" diyerek doğrulun. Ayakta "Rabbenâ lekel hamd" ekleyin.' },
  { step: 7, title: 'Birinci Secde', detail: '"Allahu Ekber" diyerek yere kapanın. Alın ve burun yere değmeli. "Sübhâne Rabbiyel A\'lâ" üç kez okuyun.' },
  { step: 8, title: 'Celsede Oturuş', detail: '"Allahu Ekber" diyerek kısa süre oturun. Ardından ikinci secdeye gidin.' },
  { step: 9, title: 'İkinci Secde', detail: 'Aynı şekilde ikinci secdeyi yapın. "Sübhâne Rabbiyel A\'lâ" üç kez okuyun.' },
  { step: 10, title: 'Ka\'de — Ettehiyyât', detail: 'Son rek\'atlerde oturun; Ettehiyyâtü, ardından Salât-ı İbrâhîmiyye ve dua okuyun.' },
  { step: 11, title: 'Selam', detail: 'Önce sağ, sonra sol omuz üzerine dönüp "Esselâmü aleyküm ve rahmetullâh" diyerek namazı tamamlayın.' },
];

function NamazKilisPage() {
  const [activeStep, setActiveStep] = useState<number | null>(null);
  return (
    <div className="space-y-10">
      <div>
        <p className="mb-2 text-[10px] font-bold uppercase tracking-[.22em] text-[#d4af37]">İbadet Rehberi</p>
        <h1 className="font-[Manrope] text-3xl font-extrabold tracking-[-.06em] text-[#f5f1df] md:text-5xl">Namaz Kılınışı</h1>
        <p className="mt-3 text-sm text-[#a7a893]">5 vakit namazın rekat sayıları ve adım adım kılınış rehberi.</p>
      </div>

      {/* Rekat tablosu */}
      <section className="space-y-4">
        <SectionTitle eyebrow="Rekât Dağılımı" title="5 Vakit Namaz" />
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5">
          {NAMAZ_TABLE.map(p => (
            <div key={p.name} className="overflow-hidden rounded-[1.5rem] border border-[#d4af37]/15 bg-[#243223]/65">
              <div className="bg-[#d4af37]/10 px-4 py-3 text-center">
                <p className="arabic text-xl text-[#d4af37]">{p.arabic}</p>
                <h3 className="mt-1 font-bold text-[#f5f1df]">{p.name}</h3>
                <p className="mt-0.5 text-[10px] font-bold text-[#d4af37]">Toplam {p.total} Rekât</p>
              </div>
              <div className="space-y-1.5 p-4">
                {p.sunnet.filter(s => s.type === 'before').map((s, i) => (
                  <div key={i} className="flex items-center gap-2 rounded-lg bg-[#d4af37]/8 px-3 py-1.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-[#d4af37]/60" />
                    <span className="text-[11px] text-[#c8c3a8]">{s.label} <span className="text-[#8e8a69]">(önceki)</span></span>
                  </div>
                ))}
                <div className="flex items-center gap-2 rounded-lg border border-[#d4af37]/30 bg-[#d4af37]/12 px-3 py-1.5">
                  <span className="h-1.5 w-1.5 rounded-full bg-[#d4af37]" />
                  <span className="text-[11px] font-bold text-[#e6d896]">{p.farz}</span>
                </div>
                {p.sunnet.filter(s => s.type === 'after').map((s, i) => (
                  <div key={i} className="flex items-center gap-2 rounded-lg bg-[#d4af37]/8 px-3 py-1.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-[#d4af37]/60" />
                    <span className="text-[11px] text-[#c8c3a8]">{s.label} <span className="text-[#8e8a69]">(sonraki)</span></span>
                  </div>
                ))}
                {p.sunnet.filter(s => s.type === 'vitr').map((s, i) => (
                  <div key={i} className="flex items-center gap-2 rounded-lg bg-[#75633a]/30 px-3 py-1.5">
                    <span className="h-1.5 w-1.5 rounded-full bg-[#c8a84b]/60" />
                    <span className="text-[11px] text-[#c8c3a8]">{s.label}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Namaz pozisyonları */}
      <section className="space-y-4">
        <SectionTitle eyebrow="Namaz Hareketleri" title="Temel Pozisyonlar" />
        <div className="grid gap-3 grid-cols-2 sm:grid-cols-3 lg:grid-cols-5">
          {PRAYER_POSITIONS.map(({ key, label, desc, image }) => (
            <div key={key} className="rounded-[1.5rem] border border-[#d4af37]/12 bg-[#243223]/65 p-4 text-center">
              <div className="mb-3 flex h-40 items-end justify-center overflow-hidden rounded-2xl border border-[#d4af37]/10 bg-gradient-to-b from-[#31422f] to-[#172218] p-2">
                <img src={`${import.meta.env.BASE_URL}${image}`} alt={`${label} namaz pozisyonunu gösteren sakalsız ve bıyıksız insan figürü`} className="h-full w-full object-contain object-bottom" />
              </div>
              <h4 className="text-xs font-bold text-[#f5f1df]">{label}</h4>
              <p className="mt-1.5 text-[10px] leading-relaxed text-[#9a9680]">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Adım adım rehber */}
      <section className="space-y-4">
        <SectionTitle eyebrow="Nasıl Kılınır?" title="Adım Adım Rehber" />
        <div className="space-y-2">
          {NAMAZ_STEPS.map(s => (
            <button key={s.step} onClick={() => setActiveStep(activeStep === s.step ? null : s.step)}
              className={`w-full rounded-2xl border text-left transition ${activeStep === s.step ? 'border-[#d4af37]/40 bg-[#d4af37]/[.08]' : 'border-[#d4af37]/10 bg-[#243223]/60 hover:border-[#d4af37]/25'}`}>
              <div className="flex items-center gap-4 px-5 py-4">
                <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-xl text-xs font-bold ${activeStep === s.step ? 'bg-[#d4af37] text-[#2e3b2b]' : 'bg-[#d4af37]/10 text-[#d4af37]'}`}>{s.step}</span>
                <span className="font-semibold text-[#f5f1df]">{s.title}</span>
                <ChevronRight size={15} className={`ml-auto text-[#756d54] transition-transform ${activeStep === s.step ? 'rotate-90' : ''}`} />
              </div>
              {activeStep === s.step && (
                <div className="border-t border-[#d4af37]/10 px-5 py-4">
                  <p className="text-sm leading-relaxed text-[#cec9b4]">{s.detail}</p>
                </div>
              )}
            </button>
          ))}
        </div>
      </section>

      <div className="flex gap-3 rounded-2xl border border-[#d4af37]/10 bg-[#75633a]/15 p-5 text-xs leading-relaxed text-[#b9af87]">
        <GraduationCap size={18} className="shrink-0 text-[#d4af37]" />
        Bu rehber Hanefi mezhebine göre hazırlanmıştır. Kılınış detayları mezheplere göre küçük farklılıklar gösterebilir.
      </div>
    </div>
  );
}

function LivePage() {
  const streams = [
    { title: 'Mescid-i Haram', city: 'Mekke', url: 'https://www.youtube.com/embed/live_stream?channel=UCk9Yw4jHf9J8c4n9iXx6u4A', fallback: 'https://www.youtube.com/results?search_query=Makkah+Live+official' },
    { title: 'Mescid-i Nebevî', city: 'Medine', url: 'https://www.youtube.com/embed/live_stream?channel=UCmK1c0nG6Xn5r3Y1x8n7q2Q', fallback: 'https://www.youtube.com/results?search_query=Madinah+Live+official' },
  ];
  return <div className="space-y-8"><div><p className="mb-2 text-[10px] font-bold uppercase tracking-[.22em] text-[#d4af37]">Bağlantı</p><h1 className="font-[Manrope] text-3xl font-extrabold tracking-[-.06em] text-[#f5f1df] md:text-5xl">Kutsal mekânlardan canlı</h1><p className="mt-3 max-w-xl text-sm leading-relaxed text-[#a7a893]">Mekke ve Medine’nin huzurunu bulunduğunuz yere taşıyın.</p></div><div className="grid gap-5 lg:grid-cols-2">{streams.map((stream) => <article key={stream.city} className="overflow-hidden rounded-[1.7rem] border border-[#d4af37]/15 bg-[#243223]/65"><div className="aspect-video bg-[#1a251a]"><iframe title={`${stream.city} canlı yayın`} src={stream.url} className="h-full w-full" allow="autoplay; encrypted-media" allowFullScreen /></div><div className="flex items-center justify-between p-5"><div><p className="text-[10px] font-bold uppercase tracking-[.18em] text-[#d4af37]">{stream.city}</p><h2 className="mt-1 font-bold text-[#f5f1df]">{stream.title}</h2></div><a href={stream.fallback} target="_blank" rel="noreferrer" className="flex items-center gap-2 rounded-xl border border-[#d4af37]/20 px-3 py-2 text-[11px] font-bold text-[#cdbb78]" data-testid={`link-live-${stream.city}`}><ExternalLink size={14} /> YouTube’da aç</a></div></article>)}</div><div className="flex gap-3 rounded-2xl border border-[#d4af37]/10 bg-[#75633a]/15 p-5 text-xs leading-relaxed text-[#b9af87]"><Youtube size={18} className="shrink-0 text-[#d4af37]" />Yayınlar YouTube üzerindeki herkese açık resmi kanallardan görüntülenir. Bağlantı açılmazsa “YouTube’da aç” seçeneğini deneyebilirsiniz.</div></div>;
}


function QiblaPage() {
  const [qibla, setQibla] = useState<number | null>(null);
  const [heading, setHeading] = useState<number | null>(null);
  const [geoError, setGeoError] = useState<string | null>(null);
  const [orientError, setOrientError] = useState<string | null>(null);
  const [needsPermission, setNeedsPermission] = useState(false);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const lat = pos.coords.latitude;
          const lng = pos.coords.longitude;
          const makkahLat = 21.422487;
          const makkahLng = 39.826206;
          const phiK = (makkahLat * Math.PI) / 180.0;
          const lambdaK = (makkahLng * Math.PI) / 180.0;
          const phi = (lat * Math.PI) / 180.0;
          const lambda = (lng * Math.PI) / 180.0;
          const psi = (180.0 / Math.PI) * Math.atan2(Math.sin(lambdaK - lambda), Math.cos(phi) * Math.tan(phiK) - Math.sin(phi) * Math.cos(lambdaK - lambda));
          setQibla(Math.round(psi >= 0 ? psi : psi + 360));
        },
        (err) => {
          setGeoError("Konum izni reddedildi veya alınamadı. Lütfen tarayıcı ayarlarından izin verin.");
        },
        { enableHighAccuracy: true, timeout: 10000 }
      );
    } else {
      setGeoError("Tarayıcınız konum servisini desteklemiyor.");
    }

    if (typeof (window as any).DeviceOrientationEvent !== 'undefined' && typeof (window as any).DeviceOrientationEvent.requestPermission === 'function') {
      setNeedsPermission(true);
    } else {
      startOrientation();
    }

    return () => {
      window.removeEventListener('deviceorientationabsolute', handleOrientation);
      window.removeEventListener('deviceorientation', handleOrientation);
    };
  }, []);

  const handleOrientation = (event: any) => {
    let h = event.webkitCompassHeading;
    if (h === undefined || h === null) {
      if (event.absolute && event.alpha !== null) {
        h = 360 - event.alpha;
      }
    }
    if (h !== null && h !== undefined) {
      setHeading(Math.round(h));
      setOrientError(null);
    }
  };

  const startOrientation = () => {
    if (typeof window.DeviceOrientationEvent === 'undefined') {
      setOrientError("Cihazınızda pusula sensörü bulunmuyor.");
      return;
    }
    const eventName = 'ondeviceorientationabsolute' in window ? 'deviceorientationabsolute' : 'deviceorientation';
    window.addEventListener(eventName, handleOrientation);
  };

  const requestPermission = async () => {
    try {
      const p = await (window as any).DeviceOrientationEvent.requestPermission();
      if (p === 'granted') {
        setNeedsPermission(false);
        startOrientation();
      } else {
        setOrientError("Sensör izni verilmedi.");
      }
    } catch (e) {
      setOrientError("Sensör izni alınamadı. Bu işlemi HTTPS bağlantısı üzerinden yapmalısınız.");
    }
  };

  const diff = heading !== null && qibla !== null ? (Math.abs(heading - qibla) > 180 ? 360 - Math.abs(heading - qibla) : Math.abs(heading - qibla)) : null;
  const isAligned = diff !== null && diff <= 5;
  const compassRotation = heading !== null ? -heading : 0;
  const qiblaRotation = qibla !== null ? qibla : 0;

  return (
    <div className="space-y-8">
      <SectionTitle eyebrow="Yönünüz" title="Kıble Bulucu" />

      {geoError || orientError ? (
        <div className="rounded-[1.7rem] border border-[#b65d48]/30 bg-[#b65d48]/10 p-6">
          <h3 className="font-bold text-[#f5f1df]">Pusula Çalıştırılamadı</h3>
          {geoError && <p className="mt-2 text-sm text-[#dacda9]">{geoError}</p>}
          {orientError && <p className="mt-2 text-sm text-[#dacda9]">{orientError}</p>}
          <p className="mt-4 text-xs text-[#b9ac80]">Tarayıcınız veya cihazınız pusula özelliğini desteklemiyor ya da izin vermediniz.</p>
        </div>
      ) : needsPermission ? (
        <div className="rounded-[1.7rem] border border-[#d4af37]/20 bg-[#243223]/60 p-6 text-center">
          <Compass className="mx-auto mb-4 text-[#d4af37]" size={32} />
          <h3 className="font-bold text-[#f5f1df]">Sensör İzni Gerekli</h3>
          <p className="mt-2 text-sm text-[#aaa890]">Kıbleyi bulmak için cihazınızın pusula sensörüne erişmemiz gerekiyor.</p>
          <button
            onClick={requestPermission}
            className="mt-5 rounded-xl bg-[#d4af37] px-6 py-2.5 text-sm font-bold text-[#2e3b2b] transition hover:bg-[#e0c55f]"
            data-testid="button-request-sensor"
          >
            İzin Ver
          </button>
        </div>
      ) : qibla === null ? (
        <div className="flex min-h-[300px] flex-col items-center justify-center rounded-[1.7rem] border border-[#d4af37]/10 bg-[#243223]/45 p-6">
          <span className="h-8 w-8 animate-spin rounded-full border-2 border-[#d4af37] border-t-transparent" />
          <p className="mt-4 text-sm text-[#aaa890]">Konumunuz belirleniyor...</p>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center gap-8">
          <div className="text-center">
            <h2 className={`text-4xl font-extrabold tracking-tight transition-colors duration-500 ${isAligned ? 'text-[#d4af37]' : 'text-[#f5f1df]'}`} data-testid="text-qibla-status">
              {isAligned ? 'Kıbleye Döndünüz' : 'Pusulayı Çevirin'}
            </h2>
            <p className="mt-2 text-sm text-[#aaa890]">Kıble Yönü: {qibla}° {heading !== null && `• Sizin Yönünüz: ${heading}°`}</p>
          </div>

          <div className="relative mx-auto mt-4 aspect-square w-full max-w-[320px]">
            {/* Outer Compass Ring */}
            <div className={`absolute inset-0 rounded-full border-[6px] transition-colors duration-500 ${isAligned ? 'border-[#d4af37]' : 'border-[#d4af37]/20'} bg-[#172218] shadow-2xl`}></div>

            {/* Directions (N, E, S, W) - Rotates with heading */}
            <div
              className="absolute inset-2 transition-transform duration-300 ease-out"
              style={{ transform: `rotate(${compassRotation}deg)` }}
              data-testid="compass-disk"
            >
              {[...Array(36)].map((_, i) => (
                <div
                  key={i}
                  className="absolute left-1/2 top-0 h-[50%] w-0.5 -translate-x-1/2 origin-bottom"
                  style={{ transform: `rotate(${i * 10}deg)` }}
                >
                  <div className={`mx-auto w-px bg-[#d4af37]/40 ${i % 9 === 0 ? 'h-3' : 'h-1.5'}`}></div>
                </div>
              ))}

              {/* North Marker */}
              <div className="absolute left-1/2 top-5 -translate-x-1/2 text-xs font-bold text-[#b65d48]">K</div>
              <div className="absolute right-5 top-1/2 -translate-y-1/2 text-xs font-bold text-[#aaa890]">D</div>
              <div className="absolute bottom-5 left-1/2 -translate-x-1/2 text-xs font-bold text-[#aaa890]">G</div>
              <div className="absolute left-5 top-1/2 -translate-y-1/2 text-xs font-bold text-[#aaa890]">B</div>

              {/* Qibla Marker / Kaaba on the disk */}
              <div
                className="absolute left-1/2 top-0 h-[50%] w-6 -translate-x-1/2 origin-bottom"
                style={{ transform: `rotate(${qiblaRotation}deg)` }}
              >
                <div className="absolute left-1/2 top-1 -translate-x-1/2">
                  <svg width="24" height="24" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg" className="drop-shadow-[0_0_8px_rgba(212,175,55,0.6)]">
                    <path d="M 25 25 L 75 25 L 75 90 L 25 90 Z" fill="#243223" stroke="#d4af37" strokeWidth="6" />
                    <path d="M 25 45 L 75 45" stroke="#d4af37" strokeWidth="8" />
                    <path d="M 42 25 L 42 45 M 58 25 L 58 45" stroke="#d4af37" strokeWidth="3" />
                  </svg>
                </div>
              </div>
            </div>

            {/* Static center alignment indicator (You always look 'up') */}
            <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
              <div className="h-4 w-4 rounded-full border-2 border-[#d4af37] bg-[#172218]"></div>
            </div>

            {/* The Pointer line always points UP */}
            <div className={`pointer-events-none absolute left-1/2 top-[10%] h-[40%] w-[3px] -translate-x-1/2 rounded-t-full bg-gradient-to-t ${isAligned ? 'from-transparent to-[#d4af37]' : 'from-transparent to-[#d4af37]/50'}`}></div>
          </div>

          <div className="max-w-sm rounded-2xl bg-[#d4af37]/5 px-5 py-4 text-center">
            <p className="text-xs text-[#aaa890]">
              Cihazınızı yere paralel tutun. Kıble yönü ile yeşil çizgiyi hizalayın. Mıknatıs veya metal eşyalardan uzak durun.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><AppShell><Switch><Route path="/" component={Home} /><Route path="/prayer" component={PrayerPage} /><Route path="/quran" component={QuranPage} /><Route path="/quran/:number" component={QuranPage} /><Route path="/duas" component={DualarPage} /><Route path="/namaz-kilinis" component={NamazKilisPage} /><Route path="/tasbih" component={TasbihPage} /><Route path="/esmaul-husna" component={EsmaulHusnaPage} /><Route path="/hadith" component={HadithPage} /><Route path="/qibla" component={QiblaPage} /><Route path="/stories" component={StoriesPage} /><Route path="/live" component={LivePage} /><Route path="/settings" component={SettingsPage} /><Route component={NotFound} /></Switch><ReligiousChat /></AppShell></ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;