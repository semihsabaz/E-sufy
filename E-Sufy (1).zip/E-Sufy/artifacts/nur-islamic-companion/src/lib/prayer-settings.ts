import { parsePrayerSettings, PRAYER_SOUNDS, type PrayerSettings, type SoundId } from '@workspace/prayer-alerts';
export { PRAYER_SOUNDS, type PrayerSettings, type SoundId };
export function getPrayerSettings() { return parsePrayerSettings(localStorage.getItem('prayer-alert-settings')); }
export function savePrayerSettings(settings: PrayerSettings) {
  localStorage.setItem('prayer-alert-settings', JSON.stringify(settings));
  window.dispatchEvent(new Event('prayer-settings-change'));
}
let player: HTMLAudioElement | undefined;
let activated = false;
export function isPrayerAudioActivated() { return activated; }
export function isPrayerSoundPlaying() { return !!player && !player.paused && !player.ended; }
export function stopPrayerSound() {
  if (player) { player.pause(); player.currentTime = 0; }
  window.dispatchEvent(new Event('prayer-audio-change'));
}
export async function previewPrayerSound(sound: SoundId) {
  if (!player) {
    player = new Audio();
    player.addEventListener('ended', () => window.dispatchEvent(new Event('prayer-audio-change')));
  }
  stopPrayerSound();
  player.src = `${import.meta.env.BASE_URL}sounds/${sound}.wav`;
  player.volume = 0.8;
  await player.play();
  activated = true;
  window.dispatchEvent(new Event('prayer-audio-change'));
}
export async function requestPrayerPermissions() {
  // Preview is deliberately triggered by an explicit user action to enable audio.
  await previewPrayerSound(getPrayerSettings().reminderTone);
  if ('Notification' in window && Notification.permission === 'default') await Notification.requestPermission();
}
export type PrayerAlertStatus = { error: string | null; city: string; scheduledUntil: string | null };
let status: PrayerAlertStatus = { error: null, city: 'Kayseri', scheduledUntil: null };
export function getPrayerAlertStatus() { return status; }
export function reportPrayerAlertStatus(value: PrayerAlertStatus) {
  status = value; window.dispatchEvent(new Event('prayer-alert-status'));
}
