import { Ionicons } from '@expo/vector-icons';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { Card, CityPicker, getNextPrayer, Header, PrayerStrip, Screen, SectionLabel, useCountdown, usePrayerTimes } from '@/components/nur';
import { notifyPrayerCityChanged } from '@/components/AdhanAlert';

export default function PrayerScreen() {
  const colors = useColors();
  const [city, setCityState] = useState('Kayseri');
  useEffect(() => {
    void AsyncStorage.getItem('prayer-city').then((savedCity) => {
      if (savedCity) setCityState(savedCity);
    });
  }, []);
  const setCity = (nextCity: string) => {
    setCityState(nextCity);
    void AsyncStorage.setItem('prayer-city', nextCity);
    notifyPrayerCityChanged(nextCity);
  };
  const { prayers, date, loading, error, retry } = usePrayerTimes(city);
  const next = getNextPrayer(prayers);
  const countdown = useCountdown(next);
  return <Screen><Header title="Namaz vakitleri" subtitle="Günün ritmini ibadetle güzelleştirin." action={<View style={[styles.headerIcon, { backgroundColor: `${colors.primary}18` }]}><Ionicons name="time-outline" size={20} color={colors.primary} /></View>} /><View style={styles.gap}><SectionLabel>Şehir seçin</SectionLabel><CityPicker city={city} onChange={setCity} /></View><Card><View style={styles.row}><View><SectionLabel>Sıradaki namaz</SectionLabel><Text style={[styles.nextName, { color: colors.foreground }]}>{next.label} · {next.time}</Text><Text style={[styles.muted, { color: colors.mutedForeground }]}>{city} · {date}</Text></View><Text style={[styles.countdown, { color: colors.primary }]}>{countdown.label}</Text></View><Text style={[styles.helper, { color: colors.mutedForeground }]}>vaktin başlamasına</Text></Card><View style={styles.gap}><View style={styles.row}><SectionLabel>Günlük çizelge</SectionLabel><Text style={[styles.muted, { color: colors.mutedForeground }]}>Metot 13</Text></View>{loading ? <View style={styles.skeleton}><View style={[styles.skeletonLine, { backgroundColor: colors.muted }]} /><View style={[styles.skeletonLine, { backgroundColor: colors.muted }]} /><View style={[styles.skeletonLine, { backgroundColor: colors.muted }]} /></View> : <View style={styles.list}>{prayers.map((prayer) => <View key={prayer.key} style={[styles.prayerRow, { backgroundColor: colors.card, borderColor: prayer.key === next.key ? `${colors.primary}75` : `${colors.primary}18` }]}><View style={[styles.rowIcon, { backgroundColor: prayer.key === next.key ? colors.primary : `${colors.primary}18` }]}><Ionicons name={prayer.key === 'Sunrise' ? 'sunny-outline' : 'time-outline'} size={17} color={prayer.key === next.key ? colors.primaryForeground : colors.primary} /></View><View style={styles.prayerInfo}><Text style={[styles.prayerName, { color: colors.foreground }]}>{prayer.label}</Text><Text style={[styles.muted, { color: colors.mutedForeground }]}>{prayer.arabic}</Text></View><Text style={[styles.time, { color: colors.foreground }]}>{prayer.time}</Text></View>)}</View>}{error ? <View style={styles.errorRow}><Text style={[styles.muted, { color: colors.primary }]}>Vakit servisine ulaşılamadı; yaklaşık vakitler gösteriliyor.</Text><Pressable onPress={retry}><Text style={[styles.link, { color: colors.primary }]}>Tekrar dene</Text></Pressable></View> : null}</View></Screen>;
}

const styles = StyleSheet.create({
  gap: { gap: 14 },
  headerIcon: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  nextName: { marginTop: 8, fontSize: 19, fontWeight: '800' },
  muted: { marginTop: 4, fontSize: 11, lineHeight: 17 },
  countdown: { fontSize: 22, fontWeight: '800' },
  helper: { marginTop: 6, fontSize: 11, textAlign: 'right' },
  list: { gap: 8 },
  prayerRow: { minHeight: 68, flexDirection: 'row', alignItems: 'center', borderRadius: 18, borderWidth: 1, padding: 12 },
  rowIcon: { width: 36, height: 36, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  prayerInfo: { flex: 1, marginLeft: 12 },
  prayerName: { fontSize: 14, fontWeight: '700' },
  time: { fontSize: 19, fontWeight: '800' },
  skeleton: { gap: 8 },
  skeletonLine: { height: 68, borderRadius: 18, opacity: 0.75 },
  errorRow: { gap: 8 },
  link: { fontSize: 12, fontWeight: '700' },
});