import { Ionicons } from '@expo/vector-icons';
import * as Location from 'expo-location';
import { Magnetometer } from 'expo-sensors';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Linking, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { Card, Header, Screen, SectionLabel } from '@/components/nur';
import { useColors } from '@/hooks/useColors';

type Coordinates = { latitude: number; longitude: number };
type FinderState = 'idle' | 'loading' | 'active' | 'denied' | 'unavailable' | 'error';

const KAABA = { latitude: 21.4225, longitude: 39.8262 };

function toRadians(value: number) {
  return value * Math.PI / 180;
}

function qiblaBearing({ latitude, longitude }: Coordinates) {
  const lat = toRadians(latitude);
  const kaabaLat = toRadians(KAABA.latitude);
  const longitudeDifference = toRadians(KAABA.longitude - longitude);
  const y = Math.sin(longitudeDifference);
  const x = Math.cos(lat) * Math.tan(kaabaLat) - Math.sin(lat) * Math.cos(longitudeDifference);
  return (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
}

export default function QiblaScreen() {
  const colors = useColors();
  const [permission, requestPermission] = Location.useForegroundPermissions();
  const [coordinates, setCoordinates] = useState<Coordinates | null>(null);
  const [heading, setHeading] = useState<number | null>(null);
  const [state, setState] = useState<FinderState>('idle');
  const subscriptionRef = useRef<ReturnType<typeof Magnetometer.addListener> | null>(null);

  const bearing = useMemo(() => coordinates ? qiblaBearing(coordinates) : null, [coordinates]);
  const turn = bearing !== null && heading !== null ? (bearing - heading + 360) % 360 : 0;
  const shortestTurn = turn > 180 ? turn - 360 : turn;
  const aligned = bearing !== null && heading !== null && Math.abs(shortestTurn) <= 5;

  useEffect(() => () => subscriptionRef.current?.remove(), []);

  const startFinder = async () => {
    if (Platform.OS === 'web') {
      setState('unavailable');
      return;
    }
    setState('loading');
    const nextPermission = permission?.granted ? permission : await requestPermission();
    if (!nextPermission.granted) {
      setState('denied');
      return;
    }
    try {
      const available = await Magnetometer.isAvailableAsync();
      if (!available) {
        setState('unavailable');
        return;
      }
      const position = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      setCoordinates(position.coords);
      Magnetometer.setUpdateInterval(120);
      subscriptionRef.current?.remove();
      subscriptionRef.current = Magnetometer.addListener(({ x, y }) => {
        const magneticHeading = (Math.atan2(y, x) * 180 / Math.PI + 360) % 360;
        setHeading(magneticHeading);
      });
      setState('active');
    } catch {
      setState('error');
    }
  };

  const status = state === 'active'
    ? aligned ? 'Kıble yönündesiniz' : `${Math.abs(Math.round(shortestTurn))}° ${shortestTurn < 0 ? 'sola' : 'sağa'} dönün`
    : state === 'loading' ? 'Konum ve pusula hazırlanıyor'
    : 'Canlı kıble pusulasını başlatın';

  return (
    <Screen>
      <Header title="Kıble Bulucu" subtitle="Cihaz pusulanızla Kâbe yönüne hizalanın." />
      <Card style={styles.compassCard}>
        <Text style={[styles.status, { color: aligned ? colors.primary : colors.foreground }]} testID="text-qibla-status">{status}</Text>
        <Text style={[styles.degree, { color: colors.mutedForeground }]}>
          {bearing === null ? 'Kıble açısı hesaplanmadı' : `Kıble ${Math.round(bearing)}° · Yönünüz ${Math.round(heading ?? 0)}°`}
        </Text>
        <View style={[styles.compass, { borderColor: `${colors.primary}55`, backgroundColor: colors.background }]} testID="compass-disk">
          <Text style={[styles.north, { color: colors.primary }]}>K</Text>
          <Text style={[styles.south, { color: colors.mutedForeground }]}>G</Text>
          <Text style={[styles.west, { color: colors.mutedForeground }]}>B</Text>
          <Text style={[styles.east, { color: colors.mutedForeground }]}>D</Text>
          <View style={[styles.needle, { transform: [{ rotate: `${shortestTurn}deg` }] }]}>
            <View style={[styles.arrow, { borderBottomColor: colors.primary }]} />
            <View style={styles.kaaba} accessibilityLabel="Kâbe simgesi">
              <View style={[styles.kaabaBand, { backgroundColor: colors.primary }]} />
            </View>
            <View style={[styles.needleLine, { backgroundColor: colors.primary }]} />
          </View>
          <View style={[styles.centerPin, { backgroundColor: colors.primary }]} />
        </View>
        {state !== 'active' ? (
          <Pressable onPress={startFinder} testID="button-start-qibla" style={({ pressed }) => [styles.startButton, { backgroundColor: colors.primary, opacity: pressed ? 0.78 : 1 }]}>
            <Ionicons name="compass-outline" size={19} color={colors.primaryForeground} />
            <Text style={[styles.startText, { color: colors.primaryForeground }]}>
              {state === 'loading' ? 'Hazırlanıyor' : 'Pusulayı Başlat'}
            </Text>
          </Pressable>
        ) : null}
        {state === 'denied' ? (
          <View style={styles.message}>
            <Text style={[styles.messageText, { color: colors.mutedForeground }]}>Konum izni olmadan bulunduğunuz noktaya göre kıble açısı hesaplanamaz.</Text>
            {!permission?.canAskAgain && Platform.OS !== 'web' ? (
              <Pressable onPress={() => Linking.openSettings()} testID="button-open-settings">
                <Text style={[styles.settingsText, { color: colors.primary }]}>Ayarları aç</Text>
              </Pressable>
            ) : null}
          </View>
        ) : null}
        {state === 'unavailable' || state === 'error' ? (
          <Text style={[styles.messageText, { color: colors.mutedForeground }]}>
            {Platform.OS === 'web' ? 'Canlı pusula için uygulamayı sensörlü bir mobil cihazda açın.' : 'Bu cihazdan pusula verisi alınamadı. Sensör ve konum ayarlarınızı kontrol edin.'}
          </Text>
        ) : null}
      </Card>
      <View style={styles.guide}>
        <SectionLabel>Doğru ölçüm için</SectionLabel>
        <Text style={[styles.guideText, { color: colors.mutedForeground }]}>Cihazı yere paralel tutun ve metal eşyalardan uzaklaşın. Pusulayı kalibre etmek için telefonu birkaç kez sekiz şeklinde hareket ettirin.</Text>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  compassCard: { alignItems: 'center', paddingVertical: 24 },
  status: { fontSize: 22, fontWeight: '800', textAlign: 'center' },
  degree: { marginTop: 7, fontSize: 11, textAlign: 'center' },
  compass: { width: 286, height: 286, marginTop: 24, borderRadius: 143, borderWidth: 2, position: 'relative', alignItems: 'center', justifyContent: 'center' },
  north: { position: 'absolute', top: 12, fontSize: 15, fontWeight: '900' },
  south: { position: 'absolute', bottom: 12, fontSize: 13, fontWeight: '800' },
  west: { position: 'absolute', left: 14, fontSize: 13, fontWeight: '800' },
  east: { position: 'absolute', right: 14, fontSize: 13, fontWeight: '800' },
  needle: { position: 'absolute', width: 42, height: 242, alignItems: 'center' },
  arrow: { width: 0, height: 0, borderLeftWidth: 12, borderRightWidth: 12, borderBottomWidth: 24, borderLeftColor: 'transparent', borderRightColor: 'transparent' },
  kaaba: { width: 32, height: 36, marginTop: 4, backgroundColor: '#121411', borderWidth: 1, borderColor: '#766734', justifyContent: 'center' },
  kaabaBand: { width: '100%', height: 4 },
  needleLine: { width: 2, height: 70, opacity: 0.8 },
  centerPin: { width: 15, height: 15, borderRadius: 8, borderWidth: 3, borderColor: '#F5F1DF' },
  startButton: { marginTop: 24, minHeight: 48, borderRadius: 15, paddingHorizontal: 22, flexDirection: 'row', alignItems: 'center', gap: 9 },
  startText: { fontSize: 13, fontWeight: '800' },
  message: { marginTop: 16, alignItems: 'center', gap: 10 },
  messageText: { marginTop: 16, maxWidth: 290, fontSize: 12, lineHeight: 18, textAlign: 'center' },
  settingsText: { fontSize: 13, fontWeight: '800' },
  guide: { gap: 9 },
  guideText: { fontSize: 12, lineHeight: 19 },
});