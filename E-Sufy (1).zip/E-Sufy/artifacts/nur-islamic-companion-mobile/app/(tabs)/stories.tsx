import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import { AppState, Pressable, StyleSheet, Text, View } from 'react-native';
import { getListStoriesQueryKey, useListStories, type PublishedStory } from '@workspace/api-client-react';
import { Card, Header, LoadingState, Screen, SectionLabel } from '@/components/nur';
import { useColors } from '@/hooks/useColors';

function pageWindow(current: number, total: number): (number | string)[] {
  const nums = [...new Set([1, total, current - 1, current, current + 1])].filter((n) => n >= 1 && n <= total).sort((a, b) => a - b);
  const out: (number | string)[] = [];
  nums.forEach((n, i) => { if (i > 0 && n - nums[i - 1] > 1) out.push(`gap${i}`); out.push(n); });
  return out;
}

function fmt(iso: string, tz?: string) {
  try { return new Intl.DateTimeFormat('tr-TR', { day: 'numeric', month: 'long', year: 'numeric', timeZone: tz || 'Europe/Istanbul' }).format(new Date(iso)); } catch { return iso; }
}

export default function StoriesScreen() {
  const colors = useColors();
  const router = useRouter();
  const params = useLocalSearchParams<{ page?: string }>();
  const raw = parseInt(Array.isArray(params.page) ? params.page[0] : params.page ?? '1', 10);
  const page = Number.isFinite(raw) && raw >= 1 ? Math.min(raw, 100000) : 1;
  const [selected, setSelected] = useState<PublishedStory | null>(null);
  const { data, isLoading, isError, refetch } = useListStories({ page }, { query: { queryKey: getListStoriesQueryKey({ page }), refetchInterval: 60000, refetchOnWindowFocus: true } });
  const refetchRef = useRef(refetch);
  refetchRef.current = refetch;
  useEffect(() => {
    const subscription = AppState.addEventListener('change', (state) => {
      if (state === 'active') void refetchRef.current();
    });
    return () => subscription.remove();
  }, []);
  useEffect(() => { setSelected(null); }, [page]);
  const nextAt = data?.nextPublicationAt;
  useEffect(() => {
    if (!nextAt) return;
    const ms = new Date(nextAt).getTime() - Date.now() + 1500;
    if (ms <= 0 || ms > 2147483000) return;
    const t = setTimeout(() => { refetchRef.current(); }, ms);
    return () => clearTimeout(t);
  }, [nextAt]);
  const go = (p: number) => router.setParams({ page: String(p) });
  const tz = data?.publicationTimezone;

  const note = (
    <View style={[styles.note, { borderColor: `${colors.primary}30`, backgroundColor: `${colors.primary}0D` }]}>
      <Ionicons name="sparkles-outline" size={16} color={colors.primary} />
      <Text style={[styles.noteText, { color: colors.mutedForeground }]}>Günlük kıssalar, belirtilen kaynaklara dayanılarak yapay zekâ ile yeniden ifade edilmiştir. Metin Kur’an ayetlerinin birebir çevirisi değildir; ayet ve hadis için kaynağa başvurun.</Text>
    </View>
  );

  if (selected) {
    return (
      <Screen>
        <Pressable onPress={() => setSelected(null)} style={[styles.back, { backgroundColor: `${colors.primary}18` }]} testID="button-back-stories">
          <Ionicons name="arrow-back" size={16} color={colors.primary} /><Text style={[styles.backText, { color: colors.primary }]}>Geri</Text>
        </Pressable>
        <Card>
          <Text style={[styles.theme, { color: colors.primary }]}>{selected.theme} · {selected.editionLabel}</Text>
          <Text style={[styles.readTitle, { color: colors.foreground }]}>{selected.title}</Text>
          <Text style={[styles.meta, { color: colors.mutedForeground }]}>Yayın tarihi: {fmt(selected.publicationDate, tz)}</Text>
          <View style={{ marginTop: 14 }}>{note}</View>
          {selected.content.split(/\n{2,}/).map((p, i) => <Text key={i} style={[styles.body, { color: colors.foreground }]}>{p}</Text>)}
          <View style={[styles.lesson, { borderColor: `${colors.primary}30`, backgroundColor: `${colors.primary}0D` }]}>
            <Text style={[styles.theme, { color: colors.primary }]}>Hayat dersi</Text>
            <Text style={[styles.lessonText, { color: colors.foreground }]}>{selected.lesson}</Text>
          </View>
          <Text style={[styles.meta, { color: colors.mutedForeground, marginTop: 16 }]}>Kaynak: {selected.source}</Text>
        </Card>
      </Screen>
    );
  }

  return (
    <Screen>
      <Header title="Günlük Kıssalar" subtitle="Her gün 00:00'da (İstanbul) yeni kıssa yayınlanır." />
      {note}
      <SectionLabel>{page > 1 ? `Arşiv · sayfa ${page}` : 'En yeni yayınlar'}</SectionLabel>
      {isLoading ? <LoadingState label="Kıssalar yükleniyor" /> : null}
      {isError && !isLoading ? (
        <Card><Text style={[styles.title, { color: colors.foreground }]}>Kıssalar yüklenemedi</Text>
          <Text style={[styles.summary, { color: colors.mutedForeground }]}>Bağlantınızı kontrol edip tekrar deneyin.</Text>
          <Pressable onPress={() => refetch()} style={[styles.retry, { backgroundColor: colors.primary }]} testID="button-retry-stories"><Text style={[styles.retryText, { color: colors.primaryForeground }]}>Tekrar dene</Text></Pressable></Card>
      ) : null}
      {data && data.items.length === 0 ? (
        <Card><Text style={[styles.title, { color: colors.foreground }]}>{page > 1 ? 'Bu sayfada kıssa yok' : 'Henüz kıssa yayınlanmadı'}</Text>
          {page > 1 ? <Pressable onPress={() => go(1)} testID="button-empty-first"><Text style={[styles.summary, { color: colors.primary }]}>İlk sayfaya dön</Text></Pressable> : null}</Card>
      ) : null}
      {data && data.items.length > 0 ? (
        <>
          <View style={styles.list}>
            {data.items.map((s) => (
              <Pressable key={s.id} onPress={() => setSelected(s)} testID={`card-story-${s.id}`}>
                <Card>
                  <Text style={[styles.theme, { color: colors.primary }]}>{s.theme}</Text>
                  <Text style={[styles.title, { color: colors.foreground }]}>{s.title}</Text>
                  <Text style={[styles.meta, { color: colors.mutedForeground }]}>{fmt(s.publicationDate, tz)} · {s.editionLabel}</Text>
                  <Text numberOfLines={4} style={[styles.summary, { color: colors.mutedForeground }]}>{s.summary}</Text>
                </Card>
              </Pressable>
            ))}
          </View>
          <View style={styles.pager}>
            <Pressable disabled={page <= 1} onPress={() => go(page - 1)} accessibilityLabel="Önceki sayfa" style={[styles.pageBtn, { borderColor: `${colors.primary}30`, opacity: page <= 1 ? 0.35 : 1 }]} testID="button-page-prev"><Ionicons name="chevron-back" size={16} color={colors.foreground} /></Pressable>
            {pageWindow(page, data.totalPages).map((p) => typeof p === 'number' ? (
              <Pressable key={p} onPress={() => go(p)} style={[styles.pageBtn, { borderColor: `${colors.primary}30`, backgroundColor: p === page ? colors.primary : 'transparent' }]} testID={`button-page-${p}`}>
                <Text style={[styles.pageText, { color: p === page ? colors.primaryForeground : colors.foreground }]}>{p}</Text>
              </Pressable>
            ) : <Text key={p} style={{ color: colors.mutedForeground }}>…</Text>)}
            <Pressable disabled={page >= data.totalPages} onPress={() => go(page + 1)} accessibilityLabel="Sonraki sayfa" style={[styles.pageBtn, { borderColor: `${colors.primary}30`, opacity: page >= data.totalPages ? 0.35 : 1 }]} testID="button-page-next"><Ionicons name="chevron-forward" size={16} color={colors.foreground} /></Pressable>
          </View>
          <Text style={[styles.meta, { color: colors.mutedForeground, textAlign: 'center' }]}>Toplam {data.total} kıssa · Sayfa {data.page} / {data.totalPages}</Text>
        </>
      ) : null}
    </Screen>
  );
}

const styles = StyleSheet.create({
  list: { gap: 12 },
  note: { borderWidth: 1, borderRadius: 14, padding: 12, flexDirection: 'row', gap: 9, alignItems: 'flex-start' },
  noteText: { flex: 1, fontSize: 11, lineHeight: 17 },
  theme: { fontSize: 9, fontWeight: '800', letterSpacing: 1.5, textTransform: 'uppercase' },
  title: { marginTop: 4, fontSize: 17, fontWeight: '800' },
  readTitle: { marginTop: 8, fontSize: 24, fontWeight: '800' },
  meta: { marginTop: 6, fontSize: 11, lineHeight: 16 },
  summary: { marginTop: 10, fontSize: 13, lineHeight: 21 },
  body: { marginTop: 16, fontSize: 15, lineHeight: 26 },
  lesson: { marginTop: 20, borderWidth: 1, borderRadius: 14, padding: 13 },
  lessonText: { marginTop: 6, fontSize: 13, lineHeight: 20, fontWeight: '600' },
  back: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 6, borderRadius: 13, paddingHorizontal: 14, paddingVertical: 10 },
  backText: { fontSize: 13, fontWeight: '700' },
  retry: { alignSelf: 'flex-start', marginTop: 14, borderRadius: 13, paddingHorizontal: 16, paddingVertical: 11 },
  retryText: { fontSize: 12, fontWeight: '700' },
  pager: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'center', gap: 8 },
  pageBtn: { minWidth: 40, height: 40, borderRadius: 12, borderWidth: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 8 },
  pageText: { fontSize: 13, fontWeight: '800' },
});
