import { Ionicons } from '@expo/vector-icons';
import { useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, TextInput, useWindowDimensions, View } from 'react-native';
import { setAudioModeAsync, useAudioPlayer, useAudioPlayerStatus } from 'expo-audio';
import { useColors } from '@/hooks/useColors';
import { Card, Header, Screen, SectionLabel } from '@/components/nur';

type Surah = { number: number; name: string; englishName: string; englishNameTranslation: string; numberOfAyahs: number; revelationType: string };
type Ayah = { numberInSurah: number; arabic: string; tr: string };
const fallback: Surah[] = [
  { number: 1, name: 'Al-Fatihah', englishName: 'Fâtiha', englishNameTranslation: 'Açılış', numberOfAyahs: 7, revelationType: 'Mekkî' },
  { number: 2, name: 'Al-Baqarah', englishName: 'Bakara', englishNameTranslation: 'İnek', numberOfAyahs: 286, revelationType: 'Medenî' },
  { number: 3, name: 'Ali Imran', englishName: 'Âl-i İmrân', englishNameTranslation: 'Âl-i İmrân', numberOfAyahs: 200, revelationType: 'Medenî' },
  { number: 36, name: 'Ya-Sin', englishName: 'Yâsîn', englishNameTranslation: 'Yâsîn', numberOfAyahs: 83, revelationType: 'Mekkî' },
  { number: 55, name: 'Ar-Rahman', englishName: 'Rahmân', englishNameTranslation: 'Rahmân', numberOfAyahs: 78, revelationType: 'Mekkî' },
  { number: 112, name: 'Al-Ikhlas', englishName: 'İhlâs', englishNameTranslation: 'Samimiyet', numberOfAyahs: 4, revelationType: 'Mekkî' },
];
const fallbackAyahs: Ayah[] = [
  { numberInSurah: 1, arabic: 'بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ', tr: 'Rahmân ve Rahîm olan Allah’ın adıyla.' },
  { numberInSurah: 2, arabic: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ', tr: 'Hamd, âlemlerin Rabbi Allah’a mahsustur.' },
  { numberInSurah: 3, arabic: 'الرَّحْمَنِ الرَّحِيمِ', tr: 'O, Rahmân’dır ve Rahîm’dir.' },
];
const turkishSurahNames = [
  'Fâtiha', 'Bakara', 'Âl-i İmrân', 'Nisâ', 'Mâide', 'En’âm', 'A’râf', 'Enfâl', 'Tevbe', 'Yûnus',
  'Hûd', 'Yûsuf', 'Ra’d', 'İbrâhîm', 'Hicr', 'Nahl', 'İsrâ', 'Kehf', 'Meryem', 'Tâhâ',
  'Enbiyâ', 'Hac', 'Mü’minûn', 'Nûr', 'Furkân', 'Şuarâ', 'Neml', 'Kasas', 'Ankebût', 'Rûm',
  'Lokmân', 'Secde', 'Ahzâb', 'Sebe’', 'Fâtır', 'Yâsîn', 'Sâffât', 'Sâd', 'Zümer', 'Mü’min',
  'Fussilet', 'Şûrâ', 'Zuhruf', 'Duhân', 'Câsiye', 'Ahkâf', 'Muhammed', 'Fetih', 'Hucurât', 'Kâf',
  'Zâriyât', 'Tûr', 'Necm', 'Kamer', 'Rahmân', 'Vâkıa', 'Hadîd', 'Mücâdele', 'Haşr', 'Mümtehine',
  'Saf', 'Cuma', 'Münâfikûn', 'Teğâbün', 'Talâk', 'Tahrîm', 'Mülk', 'Kalem', 'Hâkka', 'Meâric',
  'Nûh', 'Cin', 'Müzzemmil', 'Müddessir', 'Kıyâmet', 'İnsan', 'Mürselât', 'Nebe’', 'Nâziât', 'Abese',
  'Tekvîr', 'İnfitâr', 'Mutaffifîn', 'İnşikâk', 'Bürûc', 'Târık', 'A’lâ', 'Gâşiye', 'Fecr', 'Beled',
  'Şems', 'Leyl', 'Duhâ', 'İnşirâh', 'Tîn', 'Alak', 'Kadr', 'Beyyine', 'Zilzâl', 'Âdiyât',
  'Kâria', 'Tekâsür', 'Asr', 'Hümeze', 'Fîl', 'Kureyş', 'Mâûn', 'Kevser', 'Kâfirûn', 'Nasr',
  'Tebbet', 'İhlâs', 'Felak', 'Nâs',
] as const;
function getTurkishSurahName(number: number) {
  return turkishSurahNames[number - 1] ?? 'Sure';
}

function getSurahRecitationUrl(number: number) {
  return `https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/${number}.mp3`;
}

const bismillahPrefix = /^\uFEFF?\s*بِسْمِ\s+(?:ٱللَّهِ|اللَّهِ|اللَّهِ)\s+(?:ٱلرَّحْمَٰنِ|الرَّحْمَنِ)\s+(?:ٱلرَّحِيمِ|الرَّحِيمِ)\s*/u;
const bismillahArabic = 'بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ';

function normalizeAyahs(surahNumber: number, arabicAyahs: { numberInSurah: number; text?: string; arabic?: string }[], turkishAyahs: { text?: string; tr?: string }[]) {
  const mapped = arabicAyahs.map((ayah, index) => ({ numberInSurah: ayah.numberInSurah, arabic: ayah.text ?? ayah.arabic ?? '', tr: turkishAyahs[index]?.text ?? turkishAyahs[index]?.tr ?? '' }));
  if (surahNumber === 9 || !mapped.length) return mapped;
  const firstArabic = mapped[0].arabic.replace(/^\uFEFF/, '').trim();
  const firstVerse = firstArabic.replace(bismillahPrefix, '').trim();
  if (surahNumber === 1 && !firstVerse) return mapped.slice(1);
  return [{ ...mapped[0], arabic: firstVerse }, ...mapped.slice(1)];
}

function formatDuration(seconds: number) {
  if (!Number.isFinite(seconds) || seconds < 0) return '0:00';
  const wholeSeconds = Math.floor(seconds);
  return `${Math.floor(wholeSeconds / 60)}:${(wholeSeconds % 60).toString().padStart(2, '0')}`;
}

export default function QuranScreen() {
  const colors = useColors();
  const { width } = useWindowDimensions();
  const wideReadingLayout = width >= 600;
  const [surahs, setSurahs] = useState<Surah[]>(fallback);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState<Surah | null>(null);
  const [ayahs, setAyahs] = useState<Ayah[]>(fallbackAyahs);
  const [loading, setLoading] = useState(true);
  const [reading, setReading] = useState(false);
  const [error, setError] = useState(false);
  const [audioRequested, setAudioRequested] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);
  const player = useAudioPlayer(selected ? getSurahRecitationUrl(selected.number) : null, { updateInterval: 500 });
  const audioStatus = useAudioPlayerStatus(player);

  useEffect(() => {
    void setAudioModeAsync({
      playsInSilentMode: true,
      interruptionMode: 'duckOthers',
      shouldPlayInBackground: false,
    });
  }, []);

  useEffect(() => {
    setAudioRequested(false);
    setAudioError(null);
  }, [selected?.number]);

  useEffect(() => { fetch('https://api.alquran.cloud/v1/surah').then((res) => { if (!res.ok) throw new Error(); return res.json(); }).then((json) => { if (Array.isArray(json.data)) setSurahs(json.data); }).catch(() => setError(true)).finally(() => setLoading(false)); }, []);
  const visible = useMemo(() => surahs.filter((item) => `${item.number} ${getTurkishSurahName(item.number)} ${item.englishName} ${item.englishNameTranslation} ${item.name}`.toLocaleLowerCase('tr').includes(search.toLocaleLowerCase('tr'))), [surahs, search]);
  const openSurah = (surah: Surah) => { setSelected(surah); setReading(true); fetch(`https://api.alquran.cloud/v1/surah/${surah.number}/editions/quran-uthmani,tr.diyanet`).then((res) => { if (!res.ok) throw new Error(); return res.json(); }).then((json) => { const editions = json.data; if (Array.isArray(editions) && editions[0]?.ayahs && editions[1]?.ayahs) setAyahs(normalizeAyahs(surah.number, editions[0].ayahs, editions[1].ayahs)); }).catch(() => setAyahs(normalizeAyahs(surah.number, fallbackAyahs, fallbackAyahs))).finally(() => setReading(false)); };
  const toggleRecitation = async () => {
    setAudioError(null);
    setAudioRequested(true);
    try {
      if (audioStatus.playing) {
        player.pause();
        return;
      }
      if (audioStatus.didJustFinish) await player.seekTo(0);
      player.play();
    } catch {
      setAudioError('Ses kaydı başlatılamadı. Lütfen bağlantınızı kontrol edip tekrar deneyin.');
    }
  };

  if (selected) {
    const audioLoading = audioRequested && (!audioStatus.isLoaded || audioStatus.isBuffering);
    const audioProgress = audioStatus.duration > 0
      ? `${formatDuration(audioStatus.currentTime)} / ${formatDuration(audioStatus.duration)}`
      : 'Hazırlanıyor';

    return <Screen>
      <Pressable onPress={() => setSelected(null)} style={styles.back}>
        <Ionicons name="arrow-back" size={17} color={colors.primary} />
        <Text style={[styles.link, { color: colors.primary }]}>Sure listesine dön</Text>
      </Pressable>
      <Card style={{ alignItems: 'center', backgroundColor: `${colors.accent}38` }}>
        {selected.number !== 9 ? <Text style={[styles.bismillah, { color: colors.primary }]}>{bismillahArabic}</Text> : null}
        <SectionLabel>Sure {selected.number} · {selected.revelationType}</SectionLabel>
        <Text style={[styles.surahTurkishTitle, { color: colors.foreground }]}>{getTurkishSurahName(selected.number)}</Text>
        <Text style={[styles.arabicTitle, { color: colors.foreground }]}>{selected.name}</Text>
        <Text style={[styles.muted, { color: colors.mutedForeground }]}>{selected.numberOfAyahs} ayet · Ayet ayet okuma</Text>
        <View style={[styles.audioPlayer, { backgroundColor: colors.card, borderColor: `${colors.primary}30` }]}>
          <View style={styles.audioPlayerCopy}>
            <Text style={[styles.audioEyebrow, { color: colors.primary }]}>TİLAVET · MİŞARİ RÂŞİD EL-AFÂSÎ</Text>
            <Text style={[styles.audioStatus, { color: colors.foreground }]}>{audioLoading ? 'Tilavet yükleniyor…' : audioStatus.playing ? 'Tilavet çalıyor' : 'Sureyi dinlemeye hazır'}</Text>
            <Text style={[styles.audioDuration, { color: colors.mutedForeground }]}>{audioProgress}</Text>
          </View>
          <Pressable
            accessibilityLabel={audioStatus.playing ? 'Tilaveti duraklat' : 'Tilaveti oynat'}
            onPress={() => { void toggleRecitation(); }}
            style={({ pressed }) => [styles.audioButton, { backgroundColor: colors.primary, opacity: pressed ? 0.78 : 1 }]}
          >
            {audioLoading ? <ActivityIndicator color={colors.background} /> : <Ionicons name={audioStatus.playing ? 'pause' : 'play'} size={22} color={colors.background} />}
          </Pressable>
        </View>
        {audioError ? <Text style={[styles.audioError, { color: colors.primary }]}>{audioError}</Text> : null}
      </Card>
      {reading ? <View style={styles.loader}><ActivityIndicator color={colors.primary} /><Text style={[styles.muted, { color: colors.mutedForeground }]}>Ayetler hazırlanıyor</Text></View> : <View style={styles.ayahList}>{ayahs.map((ayah) => <Card key={ayah.numberInSurah}><View style={styles.ayahNumber}><Text style={[styles.number, { color: colors.primary }]}>{ayah.numberInSurah}</Text></View><View style={[styles.ayahColumns, wideReadingLayout ? styles.ayahColumnsWide : styles.ayahColumnsStacked]}><View style={[styles.ayahPane, wideReadingLayout && styles.ayahPaneArabicWide]}><Text style={[styles.ayahLabel, { color: colors.primary }]}>ARAPÇA</Text><Text style={[styles.arabicAyah, { color: colors.foreground }]}>{ayah.arabic}</Text></View><View style={[styles.ayahPane, wideReadingLayout ? styles.ayahPaneTurkishWide : styles.ayahPaneTurkishStacked, wideReadingLayout && { borderLeftColor: `${colors.primary}30` }]}><Text style={[styles.ayahLabel, { color: colors.primary }]}>TÜRKÇE ANLAMI</Text><Text style={[styles.translation, { color: colors.secondaryForeground }]}>{ayah.tr}</Text></View></View></Card>)}</View>}
    </Screen>;
  }
  return <Screen><Header title="Kur’an-ı Kerim" subtitle="Her ayette kalbe dokunan bir çağrı." action={<View style={[styles.headerIcon, { backgroundColor: `${colors.primary}18` }]}><Ionicons name="book-outline" size={20} color={colors.primary} /></View>} /><Card><View style={styles.searchRow}><Ionicons name="search-outline" size={18} color={colors.primary} /><TextInput value={search} onChangeText={setSearch} placeholder="Sure ara — isim veya numara" placeholderTextColor={colors.mutedForeground} style={[styles.input, { color: colors.foreground }]} /></View><View style={styles.resultRow}><Text style={[styles.muted, { color: colors.mutedForeground }]}>{loading ? 'Sureler hazırlanıyor…' : `${visible.length} sure`}</Text><Text style={[styles.muted, { color: colors.mutedForeground }]}>114 sure</Text></View></Card>{error ? <Text style={[styles.muted, { color: colors.primary }]}>Sure servisine ulaşılamadı. Temel sureler hazır.</Text> : null}<View style={styles.surahList}>{visible.map((surah) => <Pressable key={surah.number} onPress={() => openSurah(surah)} style={({ pressed }) => [styles.surahRow, { backgroundColor: colors.card, borderColor: `${colors.primary}18`, opacity: pressed ? 0.75 : 1 }]}><View style={[styles.surahNumber, { backgroundColor: `${colors.primary}18` }]}><Text style={[styles.number, { color: colors.primary }]}>{surah.number}</Text></View><View style={styles.surahInfo}><Text style={[styles.surahName, { color: colors.foreground }]}>{getTurkishSurahName(surah.number)}</Text><Text style={[styles.muted, { color: colors.mutedForeground }]}>{surah.numberOfAyahs} ayet</Text></View><Text style={[styles.arabicSmall, { color: colors.primary }]}>{surah.name}</Text><Ionicons name="chevron-forward" size={16} color={colors.mutedForeground} /></Pressable>)}</View></Screen>;
}

const styles = StyleSheet.create({
  headerIcon: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  searchRow: { flexDirection: 'row', alignItems: 'center', gap: 10, borderBottomWidth: 1, borderBottomColor: '#D4AF3718', paddingBottom: 12 },
  input: { flex: 1, fontSize: 13 },
  resultRow: { marginTop: 13, flexDirection: 'row', justifyContent: 'space-between' },
  surahList: { gap: 8 },
  surahRow: { minHeight: 70, flexDirection: 'row', alignItems: 'center', borderRadius: 18, borderWidth: 1, padding: 12, gap: 11 },
  surahNumber: { width: 35, height: 35, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  number: { fontSize: 12, fontWeight: '800' },
  surahInfo: { flex: 1 },
  surahName: { fontSize: 13, fontWeight: '700' },
  arabicSmall: { fontFamily: 'serif', fontSize: 18 },
  back: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  link: { fontSize: 12, fontWeight: '700' },
  arabicTitle: { marginTop: 14, fontFamily: 'serif', fontSize: 40 },
  surahTurkishTitle: { marginTop: 12, fontSize: 27, fontWeight: '800' },
  surahTranslation: { marginTop: 4, fontSize: 17, fontWeight: '800' },
  muted: { marginTop: 4, fontSize: 11, lineHeight: 17 },
  bismillah: { alignSelf: 'stretch', marginBottom: 4, fontSize: 21, lineHeight: 36, textAlign: 'center', writingDirection: 'rtl' },
  audioPlayer: { width: '100%', marginTop: 18, flexDirection: 'row', alignItems: 'center', gap: 12, borderWidth: 1, borderRadius: 16, padding: 12 },
  audioPlayerCopy: { flex: 1, minWidth: 0 },
  audioEyebrow: { fontSize: 8, fontWeight: '800', letterSpacing: 0.9 },
  audioStatus: { marginTop: 4, fontSize: 13, fontWeight: '800' },
  audioDuration: { marginTop: 3, fontSize: 11 },
  audioButton: { width: 46, height: 46, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  audioError: { width: '100%', marginTop: 9, fontSize: 11, lineHeight: 16 },
  loader: { minHeight: 180, alignItems: 'center', justifyContent: 'center', gap: 10 },
  ayahList: { gap: 9 },
  ayahNumber: { width: 28, height: 28, borderRadius: 10, borderWidth: 1, borderColor: '#D4AF3735', alignItems: 'center', justifyContent: 'center' },
  arabicAyah: { marginTop: 15, textAlign: 'right', fontFamily: 'serif', fontSize: 26, lineHeight: 46 },
  ayahColumns: { gap: 16 },
  ayahColumnsWide: { flexDirection: 'row' },
  ayahColumnsStacked: { flexDirection: 'column' },
  ayahPane: { minWidth: 0, flex: 1 },
  ayahPaneArabicWide: { paddingRight: 16 },
  ayahPaneTurkishWide: { borderLeftWidth: 1, paddingLeft: 16 },
  ayahPaneTurkishStacked: { borderTopWidth: 1, borderTopColor: '#D4AF3730', paddingTop: 16 },
  translation: { fontSize: 14, lineHeight: 23 },
  ayahLabel: { marginTop: 10, fontSize: 9, fontWeight: '800', letterSpacing: 1.8 },
});