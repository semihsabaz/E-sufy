import { Ionicons } from '@expo/vector-icons';
import { useState, useMemo } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { Card, Header, Screen, SectionLabel } from '@/components/nur';

type Dua = { id: string; category: string; title: string; arabic: string; transliteration: string; turkish: string; source: string };

const DUA_LIST: Dua[] = [
  /* Yemek */
  { id: 'yemek-once', category: 'Yemek', title: 'Yemek Öncesi', arabic: 'بِسْمِ اللَّهِ', transliteration: 'Bismillâh.', turkish: "Allah'ın adıyla (yiyorum).", source: "Buhârî, Et'ime 2" },
  { id: 'yemek-sonra', category: 'Yemek', title: 'Yemek Sonrası', arabic: 'الْحَمْدُ لِلَّهِ الَّذِي أَطْعَمَنَا وَسَقَانَا وَجَعَلَنَا مِنَ الْمُسْلِمِينَ', transliteration: "Elhamdülillâhillezî et'amenâ ve sekânâ ve ce'alenâ minel müslimîn.", turkish: "Bizi yediren, içiren ve müslümanlardan kılan Allah'a hamdolsun.", source: "Ebû Dâvûd, Et'ime 52" },
  /* Günlük */
  { id: 'sabah-uyanis', category: 'Günlük', title: 'Uyanış Duası', arabic: 'الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ', transliteration: "Elhamdülillâhillezî ahyânâ ba'de mâ emâtenâ ve ileyhin-nüşûr.", turkish: "Bizi öldürdükten sonra tekrar dirilten Allah'a hamdolsun. Dönüş O'nadır.", source: "Buhârî, De'avât 8" },
  { id: 'uyku-dua', category: 'Günlük', title: 'Uyumadan Önce', arabic: 'بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا', transliteration: 'Bismikellâhümme emûtü ve ahyâ.', turkish: "Allahım! Senin adınla ölür ve yaşarım.", source: "Buhârî, De'avât 9" },
  { id: 'eve-giris', category: 'Günlük', title: 'Eve Girerken', arabic: 'بِسْمِ اللَّهِ وَلَجْنَا وَبِسْمِ اللَّهِ خَرَجْنَا وَعَلَى اللَّهِ رَبِّنَا تَوَكَّلْنَا', transliteration: "Bismillâhi velecnâ ve bismillâhi haracnâ ve alallâhi Rabbinâ tevekkelnâ.", turkish: "Allah'ın adıyla girdik, Allah'ın adıyla çıktık; Rabbimiz Allah'a tevekkül ettik.", source: "Ebû Dâvûd, Edeb 103" },
  { id: 'evden-cikis', category: 'Günlük', title: 'Evden Çıkarken', arabic: 'بِسْمِ اللَّهِ تَوَكَّلْتُ عَلَى اللَّهِ وَلاَ حَوْلَ وَلاَ قُوَّةَ إِلاَّ بِاللَّهِ', transliteration: "Bismillâhi tevekkeltü alallâhi ve lâ havle ve lâ kuvvete illâ billâh.", turkish: "Allah'ın adıyla, Allah'a tevekkül ettim. Güç ve kuvvet ancak Allah'a aittir.", source: "Tirmizî, De'avât 44" },
  { id: 'tuvalet-giris', category: 'Günlük', title: 'Tuvalete Girerken', arabic: 'اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الْخُبْثِ وَالْخَبَائِثِ', transliteration: "Allâhümme innî eûzü bike minel hubsi vel habâis.", turkish: "Allahım! Erkek ve dişi şeytanlardan sana sığınırım.", source: "Buhârî, Vudû 9" },
  { id: 'tuvalet-cikis', category: 'Günlük', title: 'Tuvaletten Çıkarken', arabic: 'غُفْرَانَكَ', transliteration: 'Gufrâneke.', turkish: "Mağfiretini dilerim (Allahım).", source: "Tirmizî, Tahâret 8" },
  { id: 'sefer', category: 'Günlük', title: 'Yolculuk Duası', arabic: 'سُبْحَانَ الَّذِي سَخَّرَ لَنَا هَذَا وَمَا كُنَّا لَهُ مُقْرِنِينَ وَإِنَّا إِلَى رَبِّنَا لَمُنْقَلِبُونَ', transliteration: "Sübhânellezî sehara lenâ hâzâ ve mâ künnâ lehu mukrinîn. Ve innâ ilâ Rabbinâ lemünkalibûn.", turkish: "Bunu bize boyun eğdireni tesbih ederiz; biz buna güç yetiremezdik. Şüphesiz Rabbimize döneceğiz.", source: "Ebû Dâvûd, Cihâd 72" },
  /* Namaz */
  { id: 'ezan-sonrasi', category: 'Namaz', title: 'Ezan Sonrası Dua', arabic: 'اللَّهُمَّ رَبَّ هَذِهِ الدَّعْوَةِ التَّامَّةِ وَالصَّلاَةِ الْقَائِمَةِ آتِ مُحَمَّدًا الْوَسِيلَةَ وَالْفَضِيلَةَ وَابْعَثْهُ مَقَامًا مَحْمُودًا الَّذِي وَعَدْتَهُ إِنَّكَ لَا تُخْلِفُ الْمِيعَادَ', transliteration: "Allâhümme Rabbe hâzihed-da'vetit-tâmmeti ves-salâtil kâimeti, âti Muhammeden el-vesîlete vel-fadîlete, veb'ashu makâmen mahmûdenillezî ve'adtehu, inneke lâ tuhliful mîâd.", turkish: "Allahım! Şu eksiksiz davetin ve kılınacak namazın Rabbi! Muhammed'e vesile ve fazileti ver; onu vadettiğin övgüye değer makama ulaştır. Şüphesiz sen sözünden dönmezsin.", source: "Buhârî, Ezân 8" },
  { id: 'kunut', category: 'Namaz', title: 'Kunut Duası', arabic: 'اللَّهُمَّ اهْدِنَا فِيمَنْ هَدَيْتَ وَعَافِنَا فِيمَنْ عَافَيْتَ وَتَوَلَّنَا فِيمَنْ تَوَلَّيْتَ وَبَارِكْ لَنَا فِيمَا أَعْطَيْتَ وَقِنَا شَرَّ مَا قَضَيْتَ إِنَّكَ تَقْضِي وَلَا يُقْضَى عَلَيْكَ وَإِنَّهُ لَا يَذِلُّ مَنْ وَالَيْتَ تَبَارَكْتَ رَبَّنَا وَتَعَالَيْتَ', transliteration: "Allâhümmehdinâ fîmen hedeyît, ve âfinâ fîmen âfeyt, ve tevellena fîmen tevelleyt, ve bârik lenâ fîmâ a'tayt, ve kınâ şerra mâ kadayt. İnneke takdî ve lâ yukdâ aleyk. Ve innehü lâ yezillü men vâleyt. Tebârekte Rabbenâ ve teâleyt.", turkish: "Allahım! Hidayet ettiklerin arasında bize de hidayet et; afiyet verdiklerin arasında bize de afiyet ver; dost edindiklerin arasında bizi de dost edin; verdiğin şeyleri bize hayırlı kıl; hükmettiğin şeylerin şerrinden bizi koru. Şüphesiz sen hükmedersin, sana hüküm verilmez. Dost edindiklerine zillet gelmez. Sen yücesin Rabbimiz ve büyüksün.", source: "Ebû Dâvûd, Vitr 5" },
  /* Sure */
  { id: 'fatiha', category: 'Sure', title: 'Fâtiha Sûresi', arabic: 'الْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ ۝ الرَّحْمَٰنِ الرَّحِيمِ ۝ مَالِكِ يَوْمِ الدِّينِ ۝ إِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ ۝ اهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ ۝ صِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ', transliteration: "Bismillâhirrahmânirrahîm. Elhamdü lillâhi Rabbil'âlemîn. Errahmânirrahîm. Mâliki yevmiddîn. İyyâke na'büdü ve iyyâke neste'în. İhdinessırâtel müstekîm. Sırâtallezîne en'amte aleyhim, ğayril mağdûbi aleyhim veleddâllîn.", turkish: "Rahman ve Rahim Allah'ın adıyla. Hamd âlemlerin Rabbi Allah'a mahsustur. O, Rahman ve Rahim'dir. Din (hesap) gününün sahibidir. Yalnız sana ibadet eder, yalnız senden yardım dileriz. Bizi doğru yola ilet. Nimet verdiklerinin yoluna; gazaba uğrayanların ve sapkınların yoluna değil.", source: "Kur'an 1:1-7" },
  { id: 'ihlas', category: 'Sure', title: 'İhlâs Sûresi', arabic: 'قُلْ هُوَ اللَّهُ أَحَدٌ ۝ اللَّهُ الصَّمَدُ ۝ لَمْ يَلِدْ وَلَمْ يُولَدْ ۝ وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ', transliteration: "Kul huvallâhu ahad. Allâhus-samed. Lem yelid ve lem yûled. Ve lem yekün lehû küfüven ahad.", turkish: "De ki: O Allah birdir. Allah Samed'dir (hiçbir şeye muhtaç olmayan, herkesin muhtaç olduğu). O doğurmamış ve doğurulmamıştır. Hiçbir şey O'na denk değildir.", source: "Kur'an 112:1-4" },
  { id: 'felak', category: 'Sure', title: 'Felak Sûresi', arabic: 'قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ ۝ مِن شَرِّ مَا خَلَقَ ۝ وَمِن شَرِّ غَاسِقٍ إِذَا وَقَبَ ۝ وَمِن شَرِّ النَّفَّاثَاتِ فِي الْعُقَدِ ۝ وَمِن شَرِّ حَاسِدٍ إِذَا حَسَدَ', transliteration: "Kul eûzü birabbil-felek. Min şerri mâ halak. Ve min şerri ğâsikın izâ vekab. Ve min şerrinneffâsâti fil'ukad. Ve min şerri hâsidin izâ hased.", turkish: "De ki: Yarattığı şeylerin şerrinden, karanlığı çöktüğünde gecenin şerrinden, düğümlere üfleyenlerin şerrinden, haset ettiğinde hasedçinin şerrinden, şafağın Rabbine sığınırım.", source: "Kur'an 113:1-5" },
  { id: 'nas', category: 'Sure', title: 'Nâs Sûresi', arabic: 'قُلْ أَعُوذُ بِرَبِّ النَّاسِ ۝ مَلِكِ النَّاسِ ۝ إِلَٰهِ النَّاسِ ۝ مِن شَرِّ الْوَسْوَاسِ الْخَنَّاسِ ۝ الَّذِي يُوَسْوِسُ فِي صُدُورِ النَّاسِ ۝ مِنَ الْجِنَّةِ وَالنَّاسِ', transliteration: "Kul eûzü birabbin-nâs. Melikin-nâs. İlâhin-nâs. Min şerril vesvâsil-hannâs. Ellezî yüvesvisü fî sudûrin-nâs. Minel cinneti ven-nâs.", turkish: "De ki: İnsanların Rabbine, insanların Melik'ine, insanların İlah'ına sığınırım. Sinsi vesvesecinin şerrinden; o ki insanların göğüslerine vesvese verir; cinlerden ve insanlardan olanların şerrinden.", source: "Kur'an 114:1-6" },
  /* Çeşitli */
  { id: 'istigfar', category: 'Çeşitli', title: 'İstiğfar', arabic: 'أَسْتَغْفِرُ اللَّهَ الْعَظِيمَ الَّذِي لَا إِلَهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ وَأَتُوبُ إِلَيْهِ', transliteration: "Estağfirullâhel'azîmellezî lâ ilâhe illâ huvel-hayyel-kayyûme ve etûbü ileyh.", turkish: "Kendisinden başka ilah olmayan, Hayy ve Kayyum olan Yüce Allah'tan bağışlanma diler ve O'na tevbe ederim.", source: "Tirmizî, De'avât 15" },
  { id: 'salavat', category: 'Çeşitli', title: 'Salât-ı İbrâhîmiyye', arabic: 'اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ كَمَا صَلَّيْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ إِنَّكَ حَمِيدٌ مَجِيدٌ ۝ اللَّهُمَّ بَارِكْ عَلَى مُحَمَّدٍ وَعَلَى آلِ مُحَمَّدٍ كَمَا بَارَكْتَ عَلَى إِبْرَاهِيمَ وَعَلَى آلِ إِبْرَاهِيمَ إِنَّكَ حَمِيدٌ مَجِيدٌ', transliteration: "Allâhümme salli alâ Muhammed ve alâ âli Muhammed, kemâ salleyte alâ İbrâhîme ve alâ âli İbrâhîm, inneke hamîdün mecîd. Allâhümme bârik alâ Muhammed ve alâ âli Muhammed, kemâ bârekte alâ İbrâhîme ve alâ âli İbrâhîm, inneke hamîdün mecîd.", turkish: "Allahım! İbrahim'e ve İbrahim'in ailesine rahmetle muamele ettiğin gibi Muhammed'e ve Muhammed'in ailesine de rahmetle muamele et. Şüphesiz sen övgüye layıksın, yücesin. Allahım! İbrahim'e ve İbrahim'in ailesine bereket verdiğin gibi Muhammed'e ve Muhammed'in ailesine de bereket ver. Şüphesiz sen övgüye layıksın, yücesin.", source: "Buhârî, Enbiyâ 10" },
  { id: 'subhane', category: 'Çeşitli', title: 'Sabah–Akşam Tesbih', arabic: 'سُبْحَانَ اللَّهِ وَبِحَمْدِهِ', transliteration: 'Sübhânallâhi ve bihamdih.', turkish: "Allah'ı hamd ile tesbih ederim.", source: "Buhârî, De'avât 65; Müslim, Zikir 28" },
  { id: 'ayetkursi', category: 'Çeşitli', title: "Âyetü'l-Kürsî", arabic: 'اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَّهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ ۗ مَن ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِّنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمَاوَاتِ وَالْأَرْضَ ۖ وَلَا يَئُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ', transliteration: "Allâhü lâ ilâhe illâ hüvel hayyül kayyûm. Lâ te'huzühû sinetün ve lâ nevm. Lehu mâ fis-semâvâti ve mâ fil-ard. Men zellezî yeşfe'u indehû illâ bi'iznîh. Ya'lemü mâ beyne eydîhim ve mâ halfehüm. Ve lâ yühîtûne bişey'in min ilmihî illâ bimâ şâe. Vesi'a kürsiyyühüs-semâvâti vel-ard. Ve lâ yeûdühü hıfzuhumâ. Ve hüvel aliyyül azîm.", turkish: "Allah, kendisinden başka hiçbir ilah olmayandır. O, Hayy'dır, Kayyum'dur. O'nu ne uyuklama, ne de uyku yakalar. Göklerde ve yerde ne varsa O'nundur. O'nun izni olmadan katında kim şefaat edebilir? O, önlerindekini ve arkalarındakini bilir. Onlar, O'nun ilminden dilediği kadarından başka bir şeyi kavrayamazlar. O'nun kürsüsü gökleri ve yeri kaplamıştır. Onları koruyup gözetmek O'na ağır gelmez. O, Yüce'dir, Azîm'dir.", source: "Kur'an 2:255" },
];

const CATEGORIES = ['Tümü', 'Yemek', 'Günlük', 'Namaz', 'Sure', 'Çeşitli'];

function DuaItem({ dua }: { dua: Dua }) {
  const colors = useColors();
  const [expanded, setExpanded] = useState(false);
  return (
    <Card>
      <Pressable onPress={() => setExpanded(e => !e)}>
        <View style={styles.duaHeader}>
          <View style={styles.duaMeta}>
            <View style={[styles.catBadge, { backgroundColor: `${colors.primary}18` }]}>
              <Text style={[styles.catText, { color: colors.primary }]}>{dua.category}</Text>
            </View>
            <Text style={[styles.duaTitle, { color: colors.foreground }]}>{dua.title}</Text>
          </View>
          <Ionicons name={expanded ? 'chevron-up' : 'chevron-down'} size={16} color={colors.mutedForeground} />
        </View>
        <Text style={[styles.arabicText, { color: colors.primary }]} numberOfLines={expanded ? undefined : 2}>{dua.arabic}</Text>
      </Pressable>

      {expanded && (
        <View style={styles.expandedContent}>
          <Text style={[styles.translitText, { color: colors.mutedForeground }]}>{dua.transliteration}</Text>
          <View style={[styles.divider, { backgroundColor: `${colors.primary}18` }]} />
          <Text style={[styles.turkishText, { color: colors.foreground }]}>{dua.turkish}</Text>
          <Text style={[styles.sourceText, { color: colors.mutedForeground }]}>{dua.source}</Text>
        </View>
      )}
    </Card>
  );
}

export default function DuasScreen() {
  const colors = useColors();
  const [cat, setCat] = useState('Tümü');
  const [search, setSearch] = useState('');

  const visible = useMemo(() =>
    DUA_LIST.filter(d =>
      (cat === 'Tümü' || d.category === cat) &&
      (d.title + d.arabic + d.turkish).toLocaleLowerCase('tr').includes(search.toLocaleLowerCase('tr'))
    ), [cat, search]);

  return (
    <Screen>
      <Header title="Dualar" subtitle="Günlük hayatınıza eşlik eden mübarek dualar." action={
        <View style={[styles.headerIcon, { backgroundColor: `${colors.primary}18` }]}>
          <Ionicons name="heart-outline" size={20} color={colors.primary} />
        </View>
      } />

      {/* Search */}
      <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: `${colors.primary}20` }]}>
        <Ionicons name="search-outline" size={16} color={colors.primary} />
        <TextInput
          value={search}
          onChangeText={setSearch}
          placeholder="Dua ara…"
          placeholderTextColor={colors.mutedForeground}
          style={[styles.searchInput, { color: colors.foreground }]}
        />
        {search ? <Pressable onPress={() => setSearch('')}><Ionicons name="close-outline" size={18} color={colors.mutedForeground} /></Pressable> : null}
      </View>

      {/* Categories */}
      <View style={styles.gap}>
        <SectionLabel>Kategori</SectionLabel>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.catRow}>
          {CATEGORIES.map(c => (
            <Pressable key={c} onPress={() => setCat(c)}
              style={[styles.catChip, { borderColor: c === cat ? colors.primary : `${colors.primary}25`, backgroundColor: c === cat ? `${colors.primary}20` : colors.card }]}>
              <Text style={[styles.catChipText, { color: c === cat ? colors.primary : colors.mutedForeground }]}>{c}</Text>
            </Pressable>
          ))}
        </ScrollView>
      </View>

      {/* List */}
      <View style={styles.list}>
        {visible.length === 0 && (
          <View style={styles.empty}>
            <Ionicons name="search-outline" size={32} color={colors.mutedForeground} />
            <Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Aradığınız dua bulunamadı.</Text>
          </View>
        )}
        {visible.map(dua => (
          <DuaItem key={dua.id} dua={dua} />
        ))}
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  headerIcon: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  searchBox: { flexDirection: 'row', alignItems: 'center', gap: 10, borderRadius: 16, borderWidth: 1, paddingHorizontal: 14, paddingVertical: 11 },
  searchInput: { flex: 1, fontSize: 13 },
  gap: { gap: 10 },
  catRow: { gap: 8, paddingRight: 4 },
  catChip: { flexDirection: 'row', alignItems: 'center', borderRadius: 12, borderWidth: 1, paddingHorizontal: 13, paddingVertical: 8 },
  catChipText: { fontSize: 12, fontWeight: '600' },
  list: { gap: 10 },
  duaHeader: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10, marginBottom: 10 },
  duaMeta: { flex: 1, gap: 4 },
  catBadge: { alignSelf: 'flex-start', borderRadius: 7, paddingHorizontal: 8, paddingVertical: 3 },
  catText: { fontSize: 9, fontWeight: '700', letterSpacing: 1.2, textTransform: 'uppercase' },
  duaTitle: { fontSize: 14, fontWeight: '700' },
  arabicText: { fontFamily: 'serif', fontSize: 20, lineHeight: 38, textAlign: 'right' },
  expandedContent: { gap: 10, marginTop: 12 },
  translitText: { fontSize: 11, fontStyle: 'italic', lineHeight: 18 },
  divider: { height: 1, marginVertical: 2 },
  turkishText: { fontSize: 13, lineHeight: 22 },
  audioBtn: { flexDirection: 'row', alignItems: 'center', gap: 8, alignSelf: 'flex-start', borderWidth: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10 },
  audioBtnText: { fontSize: 12, fontWeight: '700' },
  sourceText: { fontSize: 10, marginTop: 2 },
  empty: { alignItems: 'center', paddingVertical: 40, gap: 10 },
  emptyText: { fontSize: 13 },
});
