import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useMemo, useState } from 'react';
import { FlatList, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Header, Screen } from '@/components/nur';
import { esmaNames, type EsmaName } from '@/constants/esma';
import { useColors } from '@/hooks/useColors';

export default function EsmaulHusnaScreen() {
  const colors = useColors();
  const [search, setSearch] = useState('');
  const visible = useMemo(() => {
    const query = search.toLocaleLowerCase('tr').trim();
    return esmaNames.filter((name) => `${name.title} ${name.meaning} ${name.arabic}`.toLocaleLowerCase('tr').includes(query));
  }, [search]);

  const startDhikr = (name: EsmaName) => router.push({
    pathname: '/(tabs)/tasbih',
    params: { name: name.title, arabic: name.arabic, target: String(name.target) },
  });

  return (
    <Screen scroll={false}>
      <Header title="Esmaül Hüsna" subtitle="Allah’ın 99 güzel ismi ve anlamları." />
      <View style={[styles.search, { backgroundColor: colors.card, borderColor: `${colors.primary}25` }]}>
        <Ionicons name="search" size={19} color={colors.primary} />
        <TextInput value={search} onChangeText={setSearch} placeholder="Türkçe veya Arapça isim ara" placeholderTextColor={colors.mutedForeground} style={[styles.input, { color: colors.foreground }]} />
        {search ? <Pressable onPress={() => setSearch('')} accessibilityLabel="Aramayı temizle"><Ionicons name="close-circle" size={18} color={colors.mutedForeground} /></Pressable> : null}
      </View>
      <View style={styles.resultRow}><Text style={[styles.result, { color: colors.mutedForeground }]}>{visible.length} isim</Text><Text style={[styles.note, { color: colors.mutedForeground }]}>Geleneksel ebced değerleri</Text></View>
      <FlatList
        data={visible}
        keyExtractor={(item) => String(item.id)}
        showsVerticalScrollIndicator={false}
        scrollEnabled={visible.length > 0}
        contentContainerStyle={styles.list}
        renderItem={({ item }) => (
          <View style={[styles.card, { backgroundColor: colors.card, borderColor: `${colors.primary}24` }]}>
            <View style={styles.cardTop}>
              <View style={[styles.number, { backgroundColor: `${colors.primary}16` }]}><Text style={[styles.numberText, { color: colors.primary }]}>{item.id}</Text></View>
              <Text style={[styles.arabic, { color: colors.primary }]}>{item.arabic}</Text>
            </View>
            <Text style={[styles.title, { color: colors.foreground }]}>{item.title}</Text>
            <Text style={[styles.meaning, { color: colors.mutedForeground }]}>{item.meaning}</Text>
            <View style={[styles.footer, { borderTopColor: `${colors.primary}18` }]}>
              <Text style={[styles.target, { color: colors.primary }]}>Yâ {item.title} · {item.target}</Text>
              <Pressable onPress={() => startDhikr(item)} style={({ pressed }) => [styles.button, { backgroundColor: colors.primary, opacity: pressed ? 0.78 : 1 }]}>
                <Text style={[styles.buttonText, { color: colors.primaryForeground }]}>Zikre Başla</Text>
                <Ionicons name="arrow-forward" size={14} color={colors.primaryForeground} />
              </Pressable>
            </View>
          </View>
        )}
        ListEmptyComponent={<View style={styles.empty}><Ionicons name="search-outline" size={28} color={colors.mutedForeground} /><Text style={[styles.emptyText, { color: colors.mutedForeground }]}>Aramanızla eşleşen isim bulunamadı.</Text></View>}
        ListFooterComponent={<Text style={[styles.disclaimer, { color: colors.mutedForeground }]}>Zikir sayıları dinî bir zorunluluk ifade etmez.</Text>}
      />
    </Screen>
  );
}

const styles = StyleSheet.create({
  search: { minHeight: 50, flexDirection: 'row', alignItems: 'center', gap: 10, borderRadius: 16, borderWidth: 1, paddingHorizontal: 14 },
  input: { flex: 1, fontSize: 14, paddingVertical: 11 },
  resultRow: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 4, marginTop: 12 },
  result: { fontSize: 11, fontWeight: '700' },
  note: { fontSize: 10 },
  list: { gap: 12, paddingTop: 14, paddingBottom: 130 },
  card: { minWidth: 0, borderRadius: 21, borderWidth: 1, padding: 17 },
  cardTop: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 8 },
  number: { width: 30, height: 30, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  numberText: { fontSize: 11, fontWeight: '800' },
  arabic: { flex: 1, maxWidth: '85%', fontFamily: 'serif', fontSize: 31, lineHeight: 46, textAlign: 'right' },
  title: { marginTop: 12, fontSize: 18, fontWeight: '800', flexWrap: 'wrap' },
  meaning: { marginTop: 5, minHeight: 38, fontSize: 13, lineHeight: 20, flexWrap: 'wrap' },
  footer: { marginTop: 15, paddingTop: 13, borderTopWidth: 1, flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: 8 },
  target: { flex: 1, minWidth: 0, flexShrink: 1, fontSize: 12, fontWeight: '800' },
  button: { minHeight: 38, flexShrink: 0, flexDirection: 'row', alignItems: 'center', gap: 6, borderRadius: 12, paddingHorizontal: 13 },
  buttonText: { fontSize: 11, fontWeight: '800' },
  empty: { alignItems: 'center', paddingVertical: 70 },
  emptyText: { marginTop: 10, fontSize: 13 },
  disclaimer: { paddingVertical: 20, textAlign: 'center', fontSize: 10, lineHeight: 16 },
});