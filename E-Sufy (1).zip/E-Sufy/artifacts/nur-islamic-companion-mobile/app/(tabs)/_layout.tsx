import React from 'react';
import { Platform, StyleSheet, useColorScheme, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { Feather } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { isLiquidGlassAvailable } from 'expo-glass-effect';
import { Tabs } from 'expo-router';
import { Icon, Label, NativeTabs } from 'expo-router/unstable-native-tabs';
import { SymbolView } from 'expo-symbols';

// IMPORTANT: iOS 26 uses NativeTabs for native tabs with liquid glass support.
// NativeTabs intentionally does NOT use custom design tokens — liquid glass
// is a system-level appearance provided by iOS and cannot be overridden.
// Custom brand colors are applied only on the ClassicTabLayout path (older iOS / Android / web).
function NativeTabLayout() {
  return (
    <NativeTabs>
      <NativeTabs.Trigger name="settings" hidden />
      <NativeTabs.Trigger name="index">
        <Icon sf={{ default: 'house', selected: 'house.fill' }} />
        <Label>Ana Sayfa</Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="prayer">
        <Icon sf={{ default: 'clock', selected: 'clock.fill' }} />
        <Label>Vakitler</Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="quran">
        <Icon sf={{ default: 'book', selected: 'book.fill' }} />
        <Label>Kur’an</Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="tasbih">
        <Icon sf={{ default: 'circle', selected: 'circle.fill' }} />
        <Label>Tesbih</Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="more">
        <Icon sf={{ default: 'ellipsis', selected: 'ellipsis' }} />
        <Label>Daha fazla</Label>
      </NativeTabs.Trigger>
    </NativeTabs>
  );
}
// duas and namaz are navigated from the "more" tab — hidden from the tab bar

function ClassicTabLayout() {
  const colors = useColors();
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const isIOS = Platform.OS === 'ios';
  const isWeb = Platform.OS === 'web';

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: colors.primary,
        tabBarInactiveTintColor: colors.mutedForeground,
        headerShown: false,
        tabBarStyle: {
          position: 'absolute',
          backgroundColor: isIOS ? 'transparent' : colors.background,
          borderTopWidth: isWeb ? 1 : 0,
          borderTopColor: colors.border,
          elevation: 0,
          ...(isWeb ? { height: 84 } : {}),
        },
        tabBarBackground: () =>
          isIOS ? (
            <BlurView
              intensity={100}
              tint={isDark ? 'dark' : 'light'}
              style={StyleSheet.absoluteFill}
            />
          ) : isWeb ? (
            <View
              style={[
                StyleSheet.absoluteFill,
                { backgroundColor: colors.background },
              ]}
            />
          ) : null,
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Ana Sayfa',
          tabBarIcon: ({ color }) =>
            isIOS ? (
              <SymbolView name="house" tintColor={color} size={24} />
            ) : (
              <Feather name="home" size={22} color={color} />
            ),
        }}
      />
      <Tabs.Screen name="prayer" options={{ title: 'Vakitler', tabBarIcon: ({ color }) => isIOS ? <SymbolView name="clock" tintColor={color} size={22} /> : <Feather name="clock" size={21} color={color} /> }} />
      <Tabs.Screen name="quran" options={{ title: 'Kur’an', tabBarIcon: ({ color }) => isIOS ? <SymbolView name="book" tintColor={color} size={22} /> : <Feather name="book-open" size={21} color={color} /> }} />
      <Tabs.Screen name="tasbih" options={{ title: 'Tesbih', tabBarIcon: ({ color }) => isIOS ? <SymbolView name="circle" tintColor={color} size={22} /> : <Feather name="circle" size={21} color={color} /> }} />
      <Tabs.Screen name="more" options={{ title: 'Daha fazla', tabBarIcon: ({ color }) => isIOS ? <SymbolView name="ellipsis" tintColor={color} size={22} /> : <Feather name="more-horizontal" size={21} color={color} /> }} />
      <Tabs.Screen name="settings" options={{ href: null }} />
      <Tabs.Screen name="duas" options={{ href: null }} />
      <Tabs.Screen name="namaz" options={{ href: null }} />
      <Tabs.Screen name="qibla" options={{ href: null }} />
      <Tabs.Screen name="stories" options={{ href: null }} />
      <Tabs.Screen name="esmaul-husna" options={{ href: null }} />
    </Tabs>
  );
}

export default function TabLayout() {
  if (isLiquidGlassAvailable()) {
    return <NativeTabLayout />;
  }
  return <ClassicTabLayout />;
}
