import { Ionicons } from '@expo/vector-icons';
import { useColors } from '@/hooks/useColors';
import { Linking, Pressable, StyleSheet, Text, View } from 'react-native';
import { router } from 'expo-router';
import { Card, Header, OpenLive, Screen, SectionLabel, useHadith } from '@/components/nur';

export default function MoreScreen() {
  const colors = useColors();
  const { hadith, next } = useHadith();
  return (
    <Screen>
      <Header title="Daha fazlası" subtitle="Günün hatırlatmaları ve kutsal mekânlar." />

      {/* Quick nav cards */}
      <View style={styles.gap}>
        <SectionLabel>İbadet Rehberi</SectionLabel>
        <NavCard
          icon="heart-outline"
          title="Dualar"
          subtitle="Günlük dua ve zikirler"
          onPress={() => router.push('/(tabs)/duas')}
          colors={colors}
        />
        <NavCard
          icon="school-outline"
          title="Namaz Kılınışı"
          subtitle="Rekât sayıları ve adım adım rehber"
          onPress={() => router.push('/(tabs)/namaz')}
          colors={colors}
        />
        <NavCard
          icon="compass-outline"
          title="Kıble Bulucu"
          subtitle="Canlı pusula ile Kâbe yönünü bulun"
          onPress={() => router.push('/(tabs)/qibla')}
          colors={colors}
        />
        <NavCard
          icon="sparkles-outline"
          title="Esmaül Hüsna"
          subtitle="Allah’ın 99 güzel ismi, anlamları ve zikirleri"
          onPress={() => router.push('/(tabs)/esmaul-husna')}
          colors={colors}
        />
        <NavCard
          icon="notifications-outline"
          title="Namaz Hatırlatmaları"
          subtitle="Sesli uyarılar ve melodi seçimi"
          onPress={() => router.push('/(tabs)/settings')}
          colors={colors}
        />
        <NavCard
          icon="book-outline"
          title="Dini Hikayeler"
          subtitle="Kısa, ilham veren kıssalar ve öğütler"
          onPress={() => router.push('/(tabs)/stories')}
          colors={colors}
        />
      </View>

      {/* Hadith */}
      <View style={styles.gap}>
        <SectionLabel>Hadis-i şerif</SectionLabel>
        <Card style={{ backgroundColor: `${colors.accent}38` }}>
          <Text style={[styles.arabic, { color: colors.primary }]}>إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ</Text>
          <Text style={[styles.hadith, { color: colors.foreground }]}>"{hadith.text}"</Text>
          <Text style={[styles.meta, { color: colors.mutedForeground }]}>{hadith.narrator} · {hadith.source}</Text>
          <Pressable onPress={next} style={[styles.nextButton, { borderColor: `${colors.primary}35` }]}>
            <Ionicons name="shuffle-outline" size={15} color={colors.primary} />
            <Text style={[styles.nextText, { color: colors.primary }]}>Başka bir hadis</Text>
          </Pressable>
        </Card>
      </View>

      {/* Live */}
      <View style={styles.gap}>
        <SectionLabel>Mekke & Medine canlı</SectionLabel>
        <LiveCard city="Mekke" title="Mescid-i Haram" url="https://www.youtube.com/results?search_query=Makkah+Live+official" icon="business-outline" />
        <LiveCard city="Medine" title="Mescid-i Nebevî" url="https://www.youtube.com/results?search_query=Madinah+Live+official" icon="moon-outline" />
      </View>
    </Screen>
  );
}

function NavCard({ icon, title, subtitle, onPress, colors }: {
  icon: React.ComponentProps<typeof Ionicons>['name'];
  title: string;
  subtitle: string;
  onPress: () => void;
  colors: ReturnType<typeof useColors>;
}) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.navCard, { backgroundColor: colors.card, borderColor: `${colors.primary}20`, opacity: pressed ? 0.78 : 1 }]}>
      <View style={[styles.navIcon, { backgroundColor: `${colors.primary}18` }]}>
        <Ionicons name={icon} size={22} color={colors.primary} />
      </View>
      <View style={styles.navInfo}>
        <Text style={[styles.navTitle, { color: colors.foreground }]}>{title}</Text>
        <Text style={[styles.navSub, { color: colors.mutedForeground }]}>{subtitle}</Text>
      </View>
      <Ionicons name="chevron-forward" size={18} color={colors.mutedForeground} />
    </Pressable>
  );
}

function LiveCard({ city, title, url, icon }: { city: string; title: string; url: string; icon: React.ComponentProps<typeof Ionicons>['name'] }) {
  const colors = useColors();
  return (
    <Card>
      <View style={styles.liveRow}>
        <View style={[styles.liveIcon, { backgroundColor: `${colors.primary}18` }]}>
          <Ionicons name={icon} size={23} color={colors.primary} />
        </View>
        <View style={styles.liveInfo}>
          <Text style={[styles.city, { color: colors.primary }]}>{city}</Text>
          <Text style={[styles.title, { color: colors.foreground }]}>{title}</Text>
          <View style={styles.status}>
            <View style={[styles.dot, { backgroundColor: colors.destructive }]} />
            <Text style={[styles.meta, { color: colors.mutedForeground }]}>Resmî YouTube yayını</Text>
          </View>
        </View>
      </View>
      <OpenLive url={url} />
    </Card>
  );
}

const styles = StyleSheet.create({
  gap: { gap: 13 },
  navCard: { flexDirection: 'row', alignItems: 'center', gap: 14, borderRadius: 20, borderWidth: 1, padding: 14 },
  navIcon: { width: 46, height: 46, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  navInfo: { flex: 1 },
  navTitle: { fontSize: 15, fontWeight: '700' },
  navSub: { marginTop: 3, fontSize: 11, lineHeight: 16 },
  arabic: { fontFamily: 'serif', fontSize: 30, textAlign: 'right' },
  hadith: { marginTop: 18, fontSize: 17, lineHeight: 28 },
  meta: { marginTop: 12, fontSize: 11, lineHeight: 17 },
  nextButton: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 7, borderWidth: 1, borderRadius: 12, paddingHorizontal: 13, paddingVertical: 10, marginTop: 17 },
  nextText: { fontSize: 11, fontWeight: '700' },
  liveRow: { flexDirection: 'row', gap: 13, marginBottom: 16 },
  liveIcon: { width: 46, height: 46, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  liveInfo: { flex: 1 },
  city: { fontSize: 10, fontWeight: '700', letterSpacing: 1.8, textTransform: 'uppercase' },
  title: { marginTop: 4, fontSize: 16, fontWeight: '800' },
  status: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 },
  dot: { width: 7, height: 7, borderRadius: 4 },
});
