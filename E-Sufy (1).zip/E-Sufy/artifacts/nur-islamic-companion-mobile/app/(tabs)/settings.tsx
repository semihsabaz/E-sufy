import { Ionicons } from '@expo/vector-icons';
import { useEffect, useRef, useState } from 'react';
import { Pressable, StyleSheet, Switch, Text, View } from 'react-native';
import { router } from 'expo-router';
import { useColors } from '@/hooks/useColors';
import { Card, Header, Screen, SectionLabel } from '@/components/nur';
import {
  getPrayerAlertStatus, PRAYER_SOUNDS, previewPrayerSound, readPrayerSettings, requestPrayerPermissions,
  savePrayerSettings, settingsListeners, statusListeners, stopPrayerSound, type PrayerSettings, type SoundId,
} from '@/components/prayer-settings';

const defaults: PrayerSettings = { enabled: false, preAlert: true, atPrayer: true, reminderTone: 'soft', prayerTone: 'adhan' };

function Picker({ title, value, onChange, kind }: { title: string; value: SoundId; onChange: (v: SoundId) => void; kind: string }) {
  const colors = useColors();
  const [playing, setPlaying] = useState<SoundId | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);
  const toggle = async (id: SoundId) => {
    setErr(null);
    if (timer.current) clearTimeout(timer.current);
    if (playing === id) { stopPrayerSound(); setPlaying(null); return; }
    try {
      setPlaying(id); await previewPrayerSound(id);
      timer.current = setTimeout(() => setPlaying(null), id === 'adhan' ? 15000 : 3000);
    } catch { setPlaying(null); setErr('Ses çalınamadı.'); }
  };
  return <Card>
    <SectionLabel>{title}</SectionLabel>
    <View style={{ gap: 8, marginTop: 12 }}>
      {PRAYER_SOUNDS.map((s) => <View key={s.id} style={[styles.opt, { borderColor: value === s.id ? colors.primary : `${colors.primary}20`, backgroundColor: value === s.id ? `${colors.primary}14` : 'transparent' }]}>
        <Pressable accessibilityRole="radio" accessibilityState={{ selected: value === s.id }} testID={`radio-${kind}-${s.id}`} onPress={() => onChange(s.id)} style={styles.optMain}>
          <Ionicons name={value === s.id ? 'radio-button-on' : 'radio-button-off'} size={20} color={colors.primary} />
          <Text style={{ color: colors.foreground, fontWeight: '700', fontSize: 14, flexShrink: 1 }}>{s.label}</Text>
        </Pressable>
        <Pressable accessibilityLabel={`${s.label} melodisini ${playing === s.id ? 'durdur' : 'dinle'}`} testID={`button-preview-${kind}-${s.id}`} onPress={() => toggle(s.id)} style={[styles.play, { backgroundColor: `${colors.primary}18` }]}>
          <Ionicons name={playing === s.id ? 'stop' : 'play'} size={16} color={colors.primary} />
        </Pressable>
      </View>)}
    </View>
    {err ? <Text style={[styles.note, { color: colors.destructive }]}>{err}</Text> : null}
  </Card>;
}

function Row({ label, hint, value, onChange, disabled, id }: { label: string; hint: string; value: boolean; onChange: (v: boolean) => void; disabled?: boolean; id: string }) {
  const colors = useColors();
  return <Card><View style={styles.rowBetween}>
    <View style={{ flex: 1 }}><Text style={{ color: colors.foreground, fontWeight: '800', fontSize: 15 }}>{label}</Text><Text style={[styles.note, { color: colors.mutedForeground }]}>{hint}</Text></View>
    <Switch testID={id} accessibilityLabel={label} value={value} disabled={disabled} onValueChange={onChange} trackColor={{ true: colors.primary }} />
  </View></Card>;
}

export default function SettingsScreen() {
  const colors = useColors();
  const [settings, setSettings] = useState<PrayerSettings>(defaults);
  const [status, setStatus] = useState(getPrayerAlertStatus());
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    let alive = true;
    readPrayerSettings().then((s) => alive && setSettings(s)).catch(() => undefined);
    const a = (s: PrayerSettings) => setSettings(s);
    const b = (s: typeof status) => setStatus({ ...s });
    settingsListeners.add(a); statusListeners.add(b);
    return () => { alive = false; settingsListeners.delete(a); statusListeners.delete(b); stopPrayerSound(); };
  }, []);
  const update = async (patch: Partial<PrayerSettings>) => {
    const next = { ...settings, ...patch };
    setSettings(next);
    try { await savePrayerSettings(next); } catch { setError('Ayar kaydedilemedi.'); }
  };
  const setEnabled = async (on: boolean) => {
    setError(null);
    if (!on) { await update({ enabled: false }); return; }
    setBusy(true);
    try { await requestPrayerPermissions(); await update({ enabled: true }); }
    catch (e) { await update({ enabled: false }); setError(e instanceof Error && e.message ? e.message : 'Hatırlatmalar açılamadı. İzin verilmedi; ayar kapalı kaldı.'); }
    finally { setBusy(false); }
  };
  return <Screen>
    <Header title="Namaz hatırlatmaları" subtitle="Vakitler için sesli uyarılar." action={<Pressable onPress={() => router.back()} accessibilityLabel="Geri" testID="button-settings-back" style={[styles.back, { backgroundColor: `${colors.primary}18` }]}><Ionicons name="chevron-back" size={20} color={colors.primary} /></Pressable>} />
    <Row id="switch-prayer-enabled" label="Sesli hatırlatmalar" hint={busy ? 'İzinler isteniyor...' : 'Açtığınızda bildirim izni istenir.'} value={settings.enabled} onChange={setEnabled} disabled={busy} />
    {error ? <View accessibilityRole="alert" style={[styles.err, { borderColor: `${colors.destructive}60`, backgroundColor: `${colors.destructive}18` }]}><Text testID="text-prayer-error" style={{ color: colors.foreground, fontSize: 13, lineHeight: 19 }}>{error}</Text></View> : null}
    <Row id="switch-pre-alert" label="Vakitten 10 dakika önce" hint="Vakit girmeden önce kısa hatırlatma." value={settings.preAlert} onChange={(v) => update({ preAlert: v })} />
    <Row id="switch-at-prayer" label="Vakit girdiğinde" hint="Namaz vakti girdiği anda uyarı." value={settings.atPrayer} onChange={(v) => update({ atPrayer: v })} />
    <Picker kind="reminder" title="10 dakika önce melodisi" value={settings.reminderTone} onChange={(v) => update({ reminderTone: v })} />
    <Picker kind="prayer" title="Vakit girince melodisi" value={settings.prayerTone} onChange={(v) => update({ prayerTone: v })} />
    <Card style={{ backgroundColor: `${colors.accent}30` }}>
      <SectionLabel>Bilmeniz gerekenler</SectionLabel>
      <Text style={[styles.note, { color: colors.mutedForeground }]}>Hatırlatmalar, cihazda altı günlük kayan bir yerel plan olarak kurulur ve uygulamayı her açtığınızda yenilenir.</Text>
      <Text style={[styles.note, { color: colors.mutedForeground }]}>Melodi seçimleri derlenmiş (native) sürümde çalışır; Expo Go içinde sistem sesi kullanılabilir.</Text>
      <Text style={[styles.note, { color: colors.mutedForeground }]}>Sessiz mod, Rahatsız Etmeyin ve Android tam zamanlı alarm kısıtlamaları sesi etkileyebilir.</Text>
      <Text testID="text-prayer-status" style={[styles.note, { color: colors.mutedForeground }]}>Şehir: {status.city}{status.scheduledUntil ? ` · Planlanan: ${status.scheduledUntil}` : ''}</Text>
      {status.error ? <Text style={[styles.note, { color: colors.destructive }]}>{status.error}</Text> : null}
    </Card>
  </Screen>;
}

const styles = StyleSheet.create({
  rowBetween: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  note: { marginTop: 6, fontSize: 12, lineHeight: 18 },
  opt: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderRadius: 14, paddingLeft: 12, paddingRight: 8, minHeight: 52 },
  optMain: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10, minHeight: 48 },
  play: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  err: { borderWidth: 1, borderRadius: 14, padding: 12 },
  back: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
});
