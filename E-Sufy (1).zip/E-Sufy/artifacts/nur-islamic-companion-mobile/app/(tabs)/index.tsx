import { Feather, Ionicons } from '@expo/vector-icons';
import { Link, useRouter } from 'expo-router';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import {
  Card,
  formatDate,
  getNextPrayer,
  Header,
  Hero,
  PrayerStrip,
  Screen,
  SectionLabel,
  useCountdown,
  usePrayerTimes,
} from '@/components/nur';
import { usePrayerCity } from '@/components/prayer-city';

export default function HomeScreen() {
  const colors = useColors();
  const router = useRouter();
  const city = usePrayerCity();
  const { prayers, loading, error } = usePrayerTimes(city);
  const next = getNextPrayer(prayers);
  const countdown = useCountdown(next);

  return (
    <Screen>
      <Header
        title="Huzurlu bir gün"
        subtitle={new Intl.DateTimeFormat('tr-TR', { weekday: 'long' }).format(new Date())}
        action={<Pressable onPress={() => router.push('/(tabs)/settings')} accessibilityLabel="Namaz hatırlatma ayarları" testID="button-home-settings" style={[styles.iconBubble, { backgroundColor: `${colors.primary}18` }]}><Ionicons name="notifications-outline" size={20} color={colors.primary} /></Pressable>}
      />
      <Hero />
      <View style={styles.section}>
        <View style={styles.row}>
          <View>
            <SectionLabel>Bugünün vakitleri</SectionLabel>
            <Text style={[styles.date, { color: colors.foreground }]}>{formatDate(countdown.date)}</Text>
          </View>
          <Pressable onPress={() => router.push('/prayer')}>
            <Text style={[styles.link, { color: colors.primary }]}>Tümünü gör  ›</Text>
          </Pressable>
        </View>
        <PrayerStrip prayers={prayers} loading={loading} error={error} />
      </View>
      <Card>
        <View style={styles.row}>
          <View>
            <SectionLabel>Sıradaki vakit</SectionLabel>
            <Text style={[styles.nextName, { color: colors.foreground }]}>{next.label}</Text>
            <Text style={[styles.muted, { color: colors.mutedForeground }]}>{next.time} · {next.arabic}</Text>
          </View>
          <View style={[styles.iconBubble, { backgroundColor: `${colors.primary}18` }]}>
            <Ionicons name="time-outline" size={20} color={colors.primary} />
          </View>
        </View>
        <Text style={[styles.countdown, { color: colors.primary }]}>{countdown.label}</Text>
        <Text style={[styles.muted, { color: colors.mutedForeground }]}>vaktin başlamasına kaldı</Text>
      </Card>
      <Card style={{ backgroundColor: `${colors.accent}35` }}>
        <View style={styles.row}>
          <SectionLabel>Günün hadisi</SectionLabel>
          <Ionicons name="sparkles-outline" size={17} color={colors.primary} />
        </View>
        <Text style={[styles.arabic, { color: colors.foreground }]}>إِنَّمَا الأَعْمَالُ بِالنِّيَّاتِ</Text>
        <Text style={[styles.hadithText, { color: colors.foreground }]}>“Ameller niyetlere göredir. Herkese niyet ettiği şey vardır.”</Text>
        <Link href="/more" asChild>
          <Pressable style={styles.inlineLink}>
            <Text style={[styles.link, { color: colors.primary }]}>Hadisi oku  ›</Text>
          </Pressable>
        </Link>
      </Card>
      <View style={styles.section}>
        <SectionLabel>Keşfet</SectionLabel>
        <View style={styles.modules}>
          <Module icon="book-open" title="Kur’an oku" detail="Kalbinle dinle" onPress={() => router.push('/quran')} />
          <Module icon="circle" title="Tesbih çek" detail="Zikrin huzuru" onPress={() => router.push('/tasbih')} />
          <Module icon="book" title="Hadis-i şerif" detail="Bugünün sözü" onPress={() => router.push('/more')} />
        </View>
      </View>
    </Screen>
  );
}

function Module({
  icon,
  title,
  detail,
  onPress,
}: {
  icon: React.ComponentProps<typeof Feather>['name'];
  title: string;
  detail: string;
  onPress: () => void;
}) {
  const colors = useColors();
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.module,
        { backgroundColor: colors.card, borderColor: `${colors.primary}18`, opacity: pressed ? 0.75 : 1 },
      ]}
    >
      <Feather name={icon} size={20} color={colors.primary} />
      <Text style={[styles.moduleTitle, { color: colors.foreground }]}>{title}</Text>
      <Text style={[styles.muted, { color: colors.mutedForeground }]}>{detail}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  section: { gap: 14 },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  date: { marginTop: 5, fontSize: 22, fontWeight: '800' },
  link: { fontSize: 12, fontWeight: '700' },
  nextName: { marginTop: 8, fontSize: 21, fontWeight: '800' },
  muted: { marginTop: 4, fontSize: 11, lineHeight: 17 },
  iconBubble: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  countdown: { marginTop: 19, fontSize: 43, fontWeight: '800', letterSpacing: -1.7 },
  arabic: { marginTop: 18, textAlign: 'right', fontFamily: 'serif', fontSize: 27 },
  hadithText: { marginTop: 15, fontSize: 14, lineHeight: 23 },
  inlineLink: { marginTop: 15, alignSelf: 'flex-start' },
  modules: { flexDirection: 'row', gap: 8 },
  module: { flex: 1, minHeight: 122, borderRadius: 19, borderWidth: 1, padding: 13 },
  moduleTitle: { marginTop: 18, fontSize: 12, fontWeight: '700' },
});
