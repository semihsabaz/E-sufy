import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Haptics from 'expo-haptics';
import { useLocalSearchParams } from 'expo-router';
import { useEffect, useState } from 'react';
import { Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Card, Header, Screen, SectionLabel } from '@/components/nur';
import { useColors } from '@/hooks/useColors';

type DhikrPreset = { name: string; target: number; arabic?: string };
const presets: DhikrPreset[] = [
  { name: 'Sübhanallah', target: 33 },
  { name: 'Elhamdülillah', target: 33 },
  { name: 'Allahu Ekber', target: 33 },
  { name: 'La ilahe illallah', target: 99 },
];

export default function TasbihScreen() {
  const colors = useColors();
  const params = useLocalSearchParams<{ name?: string; arabic?: string; target?: string }>();
  const requestedTarget = Number(params.target);
  const requestedPreset: DhikrPreset | null = params.name && requestedTarget > 0
    ? { name: `Yâ ${params.name}`, target: requestedTarget, arabic: params.arabic }
    : null;
  const [preset, setPreset] = useState<DhikrPreset>(requestedPreset ?? presets[0]);
  const [count, setCount] = useState(0);
  const [target, setTarget] = useState(requestedTarget > 0 ? requestedTarget : 33);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    AsyncStorage.multiGet(['nur-tasbih-count', 'nur-tasbih-target']).then(([countValue, targetValue]) => {
      setCount(requestedPreset ? 0 : Number(countValue[1] ?? 0));
      setTarget(requestedPreset ? requestedPreset.target : Number(targetValue[1] ?? 33));
      setLoaded(true);
    });
  }, []);

  useEffect(() => {
    if (loaded) AsyncStorage.multiSet([['nur-tasbih-count', String(count)], ['nur-tasbih-target', String(target)]]);
  }, [count, target, loaded]);

  const selectPreset = (item: DhikrPreset) => {
    setPreset(item);
    setTarget(item.target);
    setCount(0);
  };
  const increment = () => {
    setCount((value) => Math.min(target, value + 1));
    void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };
  const progress = Math.min(1, count / Math.max(target, 1));

  return (
    <Screen>
      <Header title="Tesbih" subtitle="Dilin zikri, kalbin huzuru." />
      <View style={styles.gap}>
        <SectionLabel>Zikir seçin</SectionLabel>
        <View style={styles.presetGrid}>
          {presets.map((item) => (
            <Pressable key={item.name} onPress={() => selectPreset(item)} style={[styles.preset, { backgroundColor: item.name === preset.name ? `${colors.primary}18` : colors.card, borderColor: item.name === preset.name ? `${colors.primary}70` : `${colors.primary}18` }]}>
              <Text style={[styles.presetName, { color: item.name === preset.name ? colors.primary : colors.foreground }]}>{item.name}</Text>
              <Text style={[styles.muted, { color: colors.mutedForeground }]}>{item.target}</Text>
            </Pressable>
          ))}
        </View>
      </View>
      <Card>
        <View style={styles.selectedRow}>
          <Text style={[styles.selectedName, { color: colors.foreground }]}>{preset.name}</Text>
          <Text style={[styles.selectedTarget, { color: colors.primary }]}>{target} zikir</Text>
        </View>
        <View style={styles.row}>
          <SectionLabel>Hedef sayı</SectionLabel>
          <TextInput value={String(target)} onChangeText={(value) => setTarget(Math.max(1, Number(value.replace(/[^0-9]/g, '')) || 1))} keyboardType="number-pad" style={[styles.targetInput, { color: colors.foreground, borderColor: `${colors.primary}30` }]} />
        </View>
        <View style={[styles.counter, { borderColor: `${colors.primary}55` }]}>
          <Text style={[styles.counterArabic, { color: colors.primary }]}>{preset.arabic || 'سُبْحَانَ اللَّهِ'}</Text>
          <Text style={[styles.count, { color: colors.foreground }]}>{count}</Text>
          <Text style={[styles.muted, { color: colors.mutedForeground }]}>/ {target} zikir</Text>
        </View>
        <View style={[styles.progressTrack, { backgroundColor: `${colors.primary}18` }]}><View style={[styles.progress, { backgroundColor: colors.primary, width: `${progress * 100}%` }]} /></View>
        <Pressable onPress={increment} style={({ pressed }) => [styles.plus, { backgroundColor: colors.primary, transform: [{ scale: pressed ? 0.94 : 1 }] }]}><Text style={[styles.plusText, { color: colors.primaryForeground }]}>+</Text></Pressable>
        <View style={styles.actions}>
          <Pressable onPress={() => setCount((value) => Math.max(0, value - 1))} style={[styles.secondaryButton, { borderColor: `${colors.primary}25` }]}><Text style={[styles.secondaryText, { color: colors.secondaryForeground }]}>− Bir azalt</Text></Pressable>
          <Pressable onPress={() => setCount(0)} style={[styles.secondaryButton, { borderColor: `${colors.primary}25` }]}><Text style={[styles.secondaryText, { color: colors.secondaryForeground }]}>Sıfırla</Text></Pressable>
        </View>
      </Card>
      <Text style={[styles.note, { color: colors.mutedForeground }]}>Zikriniz bu cihazda saklanır; sayacınız sayfayı kapattığınızda kaybolmaz.</Text>
    </Screen>
  );
}

const styles = StyleSheet.create({
  gap: { gap: 13 },
  presetGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  preset: { width: '48%', minHeight: 64, borderRadius: 16, borderWidth: 1, padding: 11 },
  presetName: { fontSize: 12, fontWeight: '700' },
  muted: { marginTop: 4, fontSize: 11, lineHeight: 17 },
  selectedRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  selectedName: { fontSize: 14, fontWeight: '800' },
  selectedTarget: { fontSize: 11, fontWeight: '800' },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  targetInput: { width: 74, borderWidth: 1, borderRadius: 11, paddingHorizontal: 12, paddingVertical: 7, fontSize: 14, textAlign: 'center' },
  counter: { alignSelf: 'center', width: 230, height: 230, marginTop: 23, borderRadius: 115, borderWidth: 7, alignItems: 'center', justifyContent: 'center' },
  counterArabic: { fontFamily: 'serif', fontSize: 23 },
  count: { marginTop: 9, fontSize: 61, fontWeight: '800', letterSpacing: -2.5 },
  progressTrack: { height: 5, overflow: 'hidden', borderRadius: 5, marginTop: 24 },
  progress: { height: '100%', borderRadius: 5 },
  plus: { alignSelf: 'center', width: 76, height: 76, borderRadius: 38, marginTop: 24, alignItems: 'center', justifyContent: 'center' },
  plusText: { fontSize: 38, fontWeight: '300', lineHeight: 40 },
  actions: { flexDirection: 'row', justifyContent: 'center', gap: 8, marginTop: 17 },
  secondaryButton: { borderWidth: 1, borderRadius: 13, paddingHorizontal: 14, paddingVertical: 10 },
  secondaryText: { fontSize: 11, fontWeight: '600' },
  note: { fontSize: 12, lineHeight: 19, textAlign: 'center', paddingHorizontal: 16 },
});