import { Ionicons } from '@expo/vector-icons';
import { useState } from 'react';
import { Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { useColors } from '@/hooks/useColors';
import { Card, Header, Screen, SectionLabel } from '@/components/nur';
import Svg, { Circle, Line } from 'react-native-svg';

/* ── Prayer position SVG figures ──────────────────────────────────────── */
function FigTekbir({ color }: { color: string }) {
  // Front view: arms raised to ear level
  return (
    <Svg viewBox="0 0 100 125" width={60} height={75}>
      <Circle cx="50" cy="12" r="9" fill="none" stroke={color} strokeWidth="2.5" />
      <Line x1="50" y1="21" x2="50" y2="72" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="50" y1="34" x2="24" y2="24" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="24" y1="24" x2="24" y2="10" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="50" y1="34" x2="76" y2="24" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="76" y1="24" x2="76" y2="10" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="50" y1="72" x2="37" y2="102" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="50" y1="72" x2="63" y2="102" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="37" y1="102" x2="26" y2="105" stroke={color} strokeWidth="2" strokeLinecap="round" />
      <Line x1="63" y1="102" x2="74" y2="105" stroke={color} strokeWidth="2" strokeLinecap="round" />
    </Svg>
  );
}
function FigKiyam({ color }: { color: string }) {
  // Front view: hands folded at navel
  return (
    <Svg viewBox="0 0 100 125" width={60} height={75}>
      <Circle cx="50" cy="12" r="9" fill="none" stroke={color} strokeWidth="2.5" />
      <Line x1="50" y1="21" x2="50" y2="72" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="50" y1="34" x2="33" y2="53" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="33" y1="53" x2="52" y2="57" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="50" y1="34" x2="67" y2="53" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="67" y1="53" x2="48" y2="57" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="50" y1="72" x2="37" y2="102" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="50" y1="72" x2="63" y2="102" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="37" y1="102" x2="26" y2="105" stroke={color} strokeWidth="2" strokeLinecap="round" />
      <Line x1="63" y1="102" x2="74" y2="105" stroke={color} strokeWidth="2" strokeLinecap="round" />
    </Svg>
  );
}
function FigRuku({ color }: { color: string }) {
  // Side view (facing left): body horizontal, legs vertical – clear 90° bow
  return (
    <Svg viewBox="0 0 155 115" width={93} height={69}>
      <Circle cx="26" cy="46" r="9" fill="none" stroke={color} strokeWidth="2.5" />
      {/* Horizontal torso */}
      <Line x1="35" y1="48" x2="106" y2="49" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      {/* Vertical legs */}
      <Line x1="100" y1="49" x2="92" y2="100" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="108" y1="49" x2="116" y2="100" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="92" y1="100" x2="79" y2="103" stroke={color} strokeWidth="2" strokeLinecap="round" />
      <Line x1="116" y1="100" x2="128" y2="103" stroke={color} strokeWidth="2" strokeLinecap="round" />
      {/* Arms down to knees */}
      <Line x1="72" y1="49" x2="90" y2="78" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="72" y1="49" x2="116" y2="78" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Circle cx="90" cy="78" r="3.5" fill={color} />
      <Circle cx="116" cy="78" r="3.5" fill={color} />
    </Svg>
  );
}
function FigSecde({ color }: { color: string }) {
  // Side view (facing left): head on ground, body arched, knees on ground
  return (
    <Svg viewBox="0 0 165 92" width={99} height={55}>
      {/* Head – forehead at ground level */}
      <Circle cx="18" cy="62" r="8" fill="none" stroke={color} strokeWidth="2.5" />
      {/* Body arching up */}
      <Line x1="26" y1="58" x2="52" y2="42" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="52" y1="42" x2="74" y2="33" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      {/* Thigh – hips down to knees */}
      <Line x1="74" y1="33" x2="92" y2="67" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      {/* Shin – along ground */}
      <Line x1="92" y1="67" x2="136" y2="72" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      {/* Toes */}
      <Line x1="136" y1="72" x2="150" y2="64" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      {/* Arms to ground beside head */}
      <Line x1="46" y1="46" x2="20" y2="76" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="46" y1="46" x2="34" y2="76" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      {/* Palms flat */}
      <Line x1="6" y1="76" x2="34" y2="76" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
    </Svg>
  );
}
function FigOturuş({ color }: { color: string }) {
  // Front view: sitting on heels, hands on knees
  return (
    <Svg viewBox="0 0 120 115" width={72} height={69}>
      <Circle cx="60" cy="12" r="9" fill="none" stroke={color} strokeWidth="2.5" />
      <Line x1="60" y1="21" x2="60" y2="58" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="60" y1="35" x2="38" y2="53" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="60" y1="35" x2="82" y2="53" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Circle cx="38" cy="53" r="3.5" fill={color} />
      <Circle cx="82" cy="53" r="3.5" fill={color} />
      {/* Left thigh + shin + foot */}
      <Line x1="56" y1="58" x2="26" y2="73" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="26" y1="73" x2="20" y2="100" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="20" y1="100" x2="46" y2="103" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      {/* Right thigh + shin + foot */}
      <Line x1="64" y1="58" x2="94" y2="73" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="94" y1="73" x2="100" y2="100" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
      <Line x1="100" y1="100" x2="74" y2="103" stroke={color} strokeWidth="2.5" strokeLinecap="round" />
    </Svg>
  );
}

const POSITIONS = [
  { key: 'tekbir', label: 'Tekbir', desc: "Eller kulaklara kaldırılır, 'Allahu Ekber' denir.", image: require('../../assets/prayer-figures/tekbir.png') },
  { key: 'kiyam', label: 'Kıyam', desc: "Eller göbek altında kavuşturulur, Fâtiha ve sure okunur.", image: require('../../assets/prayer-figures/kiyam.png') },
  { key: 'ruku', label: 'Rükû', desc: "Bel öne eğilir, 'Sübhâne Rabbiyel Azîm' okunur.", image: require('../../assets/prayer-figures/ruku.png') },
  { key: 'secde', label: 'Secde', desc: "Yüz, eller, dizler yere kapanır, 'Sübhâne Rabbiyel A'lâ' okunur.", image: require('../../assets/prayer-figures/secde.png') },
  { key: 'oturuş', label: "Ka'de", desc: "Son rekâtte oturulur, Ettehiyyât ve salavât okunur.", image: require('../../assets/prayer-figures/oturus.png') },
];

const NAMAZ_TABLE = [
  { name: 'Sabah', arabic: 'الفجر', rows: [{ label: '2 Sünnet', type: 'sunnet' }, { label: '2 Farz', type: 'farz' }], total: 4 },
  { name: 'Öğle', arabic: 'الظهر', rows: [{ label: '4 Sünnet', type: 'sunnet' }, { label: '4 Farz', type: 'farz' }, { label: '2 Sünnet', type: 'sunnet' }], total: 10 },
  { name: 'İkindi', arabic: 'العصر', rows: [{ label: '4 Sünnet', type: 'sunnet' }, { label: '4 Farz', type: 'farz' }], total: 8 },
  { name: 'Akşam', arabic: 'المغرب', rows: [{ label: '3 Farz', type: 'farz' }, { label: '2 Sünnet', type: 'sunnet' }], total: 5 },
  { name: 'Yatsı', arabic: 'العشاء', rows: [{ label: '4 Sünnet', type: 'sunnet' }, { label: '4 Farz', type: 'farz' }, { label: '2 Sünnet', type: 'sunnet' }, { label: '3 Vitr', type: 'vitr' }], total: 13 },
];

const STEPS = [
  { step: 1, title: 'Niyet', detail: "Hangi namazı kılacağınıza kalbinizden niyet edin. Kıbleye yönelin." },
  { step: 2, title: 'İftitah Tekbiri', detail: "'Allahu Ekber' diyerek elleri kulaklara kaldırın; parmak uçları kulak memesine değer." },
  { step: 3, title: 'Sübhâneke', detail: "'Sübhânekellâhümme ve bihamdik…' duasını, ardından 'Eûzü Besmele'yi okuyun." },
  { step: 4, title: 'Fâtiha ve Sure', detail: "Fâtiha sûresini okuyun; ilk iki rekâtte arkasından bir sure veya en az üç âyet ekleyin." },
  { step: 5, title: 'Rükû', detail: "'Allahu Ekber' diyerek öne eğilin. 'Sübhâne Rabbiyel Azîm' üç kez okuyun." },
  { step: 6, title: 'Kıyama Kalkış', detail: "'Semiallâhu limen hamideh' diyerek doğrulun; 'Rabbenâ lekel hamd' ekleyin." },
  { step: 7, title: 'Birinci Secde', detail: "'Allahu Ekber' diyerek secdeye kapanın. 'Sübhâne Rabbiyel A'lâ' üç kez okuyun." },
  { step: 8, title: 'Celse', detail: "'Allahu Ekber' ile kısaca oturun. Ardından ikinci secdeye gidin." },
  { step: 9, title: 'İkinci Secde', detail: "İkinci secdeyi yapın. 'Sübhâne Rabbiyel A'lâ' üç kez okuyun." },
  { step: 10, title: "Ka'de — Ettehiyyât", detail: "Son rekâtte oturun; Ettehiyyâtü, Salât-ı İbrâhîmiyye ve dua okuyun." },
  { step: 11, title: 'Selam', detail: "Önce sağa, sonra sola dönüp 'Esselâmü aleyküm ve rahmetullâh' diyerek namazı tamamlayın." },
];

export default function NamazScreen() {
  const colors = useColors();
  const [openStep, setOpenStep] = useState<number | null>(null);

  return (
    <Screen>
      <Header title="Namaz Kılınışı" subtitle="Rekât sayıları ve adım adım rehber." action={
        <View style={[styles.headerIcon, { backgroundColor: `${colors.primary}18` }]}>
          <Ionicons name="school-outline" size={20} color={colors.primary} />
        </View>
      } />

      {/* Rekat table */}
      <View style={styles.section}>
        <SectionLabel>Rekât Dağılımı</SectionLabel>
        <View style={styles.tableGrid}>
          {NAMAZ_TABLE.map(p => (
            <Card key={p.name} style={styles.tableCard}>
              <Text style={[styles.tableArabic, { color: colors.primary }]}>{p.arabic}</Text>
              <Text style={[styles.tableName, { color: colors.foreground }]}>{p.name}</Text>
              <Text style={[styles.tableTotal, { color: colors.primary }]}>{p.total} Rekât</Text>
              <View style={styles.tableRows}>
                {p.rows.map((r, i) => (
                  <View key={i} style={[styles.tableRow, {
                    backgroundColor: r.type === 'farz' ? `${colors.primary}22` : r.type === 'vitr' ? `${colors.accent}30` : `${colors.primary}0d`,
                    borderColor: r.type === 'farz' ? `${colors.primary}50` : `${colors.primary}18`,
                  }]}>
                    <Text style={[styles.tableRowText, { color: r.type === 'farz' ? colors.primary : colors.mutedForeground, fontWeight: r.type === 'farz' ? '700' : '500' }]}>{r.label}</Text>
                  </View>
                ))}
              </View>
            </Card>
          ))}
        </View>
      </View>

      {/* Positions */}
      <View style={styles.section}>
        <SectionLabel>Temel Pozisyonlar</SectionLabel>
        <View style={styles.posGrid}>
          {POSITIONS.map(({ key, label, desc, image }) => (
            <Card key={key} style={styles.posCard}>
              <View style={[styles.figBox, { backgroundColor: `${colors.primary}0a`, borderColor: `${colors.primary}18` }]}>
                <Image source={image} style={styles.prayerFigure} resizeMode="contain" accessibilityLabel={`${label} namaz pozisyonunu gösteren sakalsız ve bıyıksız insan figürü`} />
              </View>
              <Text style={[styles.posLabel, { color: colors.foreground }]}>{label}</Text>
              <Text style={[styles.posDesc, { color: colors.mutedForeground }]}>{desc}</Text>
            </Card>
          ))}
        </View>
      </View>

      {/* Steps */}
      <View style={styles.section}>
        <SectionLabel>Adım Adım Rehber</SectionLabel>
        <View style={styles.stepList}>
          {STEPS.map(s => (
            <View key={s.step} style={[styles.stepCard, { backgroundColor: colors.card, borderColor: openStep === s.step ? `${colors.primary}45` : `${colors.primary}18` }]}>
              <Pressable onPress={() => setOpenStep(openStep === s.step ? null : s.step)} style={styles.stepHeader}>
                <View style={[styles.stepNum, { backgroundColor: openStep === s.step ? colors.primary : `${colors.primary}18` }]}>
                  <Text style={[styles.stepNumText, { color: openStep === s.step ? colors.primaryForeground : colors.primary }]}>{s.step}</Text>
                </View>
                <Text style={[styles.stepTitle, { color: colors.foreground }]}>{s.title}</Text>
                <Ionicons name={openStep === s.step ? 'chevron-up' : 'chevron-down'} size={16} color={colors.mutedForeground} />
              </Pressable>
              {openStep === s.step && (
                <View style={[styles.stepDetail, { borderTopColor: `${colors.primary}15` }]}>
                  <Text style={[styles.stepDetailText, { color: colors.secondaryForeground }]}>{s.detail}</Text>
                </View>
              )}
            </View>
          ))}
        </View>
      </View>

      <Card style={{ backgroundColor: `${colors.primary}0a` }}>
        <View style={styles.noteRow}>
          <Ionicons name="information-circle-outline" size={18} color={colors.primary} />
          <Text style={[styles.noteText, { color: colors.mutedForeground }]}>Bu rehber Hanefi mezhebine göre hazırlanmıştır.</Text>
        </View>
      </Card>
    </Screen>
  );
}

const styles = StyleSheet.create({
  headerIcon: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  section: { gap: 12 },
  tableGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  tableCard: { width: '47%', padding: 12, alignItems: 'center' },
  tableArabic: { fontFamily: 'serif', fontSize: 22, marginBottom: 2 },
  tableName: { fontSize: 14, fontWeight: '800' },
  tableTotal: { fontSize: 10, fontWeight: '700', letterSpacing: 1, marginBottom: 8 },
  tableRows: { gap: 4, width: '100%' },
  tableRow: { borderRadius: 8, borderWidth: 1, paddingHorizontal: 8, paddingVertical: 4, alignItems: 'center' },
  tableRowText: { fontSize: 11 },
  posGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  posCard: { width: '47%', alignItems: 'center', padding: 12 },
  figBox: { width: '100%', height: 150, borderRadius: 14, borderWidth: 1, padding: 6, marginBottom: 8, alignItems: 'center', justifyContent: 'flex-end', overflow: 'hidden' },
  prayerFigure: { width: '100%', height: '100%' },
  posLabel: { fontSize: 13, fontWeight: '700', marginBottom: 4, textAlign: 'center' },
  posDesc: { fontSize: 10, lineHeight: 15, textAlign: 'center' },
  stepList: { gap: 6 },
  stepCard: { borderRadius: 18, borderWidth: 1, overflow: 'hidden' },
  stepHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 14 },
  stepNum: { width: 32, height: 32, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  stepNumText: { fontSize: 12, fontWeight: '700' },
  stepTitle: { flex: 1, fontSize: 13, fontWeight: '600' },
  stepDetail: { borderTopWidth: 1, paddingHorizontal: 14, paddingVertical: 12 },
  stepDetailText: { fontSize: 13, lineHeight: 21 },
  noteRow: { flexDirection: 'row', gap: 10, alignItems: 'flex-start' },
  noteText: { flex: 1, fontSize: 11, lineHeight: 17 },
});
