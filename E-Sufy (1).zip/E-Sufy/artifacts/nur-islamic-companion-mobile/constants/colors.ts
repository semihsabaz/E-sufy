/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#F5F1DF',
    tint: '#D4AF37',

    // Core surfaces
    background: '#2E3B2B',
    foreground: '#F5F1DF',

    // Cards / elevated surfaces
    card: '#243223',
    cardForeground: '#F5F1DF',

    // Primary action color (buttons, links, active states)
    primary: '#D4AF37',
    primaryForeground: '#2E3B2B',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#344633',
    secondaryForeground: '#E8E1C9',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#3D4C38',
    mutedForeground: '#AAA890',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#75633A',
    accentForeground: '#F5F1DF',

    // Destructive actions (delete, error states)
    destructive: '#B65D48',
    destructiveForeground: '#FFF8E7',

    // Borders and input outlines
    border: '#4B583B',
    input: '#3D4C38',
  },

  dark: {
    text: '#F5F1DF',
    tint: '#D4AF37',
    background: '#2E3B2B',
    foreground: '#F5F1DF',
    card: '#243223',
    cardForeground: '#F5F1DF',
    primary: '#D4AF37',
    primaryForeground: '#2E3B2B',
    secondary: '#344633',
    secondaryForeground: '#E8E1C9',
    muted: '#3D4C38',
    mutedForeground: '#AAA890',
    accent: '#75633A',
    accentForeground: '#F5F1DF',
    destructive: '#B65D48',
    destructiveForeground: '#FFF8E7',
    border: '#4B583B',
    input: '#3D4C38',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 20,
};

export default colors;
