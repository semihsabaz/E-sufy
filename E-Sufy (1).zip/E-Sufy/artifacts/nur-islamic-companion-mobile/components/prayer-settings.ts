import AsyncStorage from '@react-native-async-storage/async-storage';
import { createAudioPlayer, setAudioModeAsync } from 'expo-audio';
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import { parsePrayerSettings, PRAYER_SOUNDS, type PrayerSettings, type SoundId } from '@workspace/prayer-alerts';
export { PRAYER_SOUNDS, type PrayerSettings, type SoundId };
export const soundSources = {
  bell: require('../assets/sounds/bell.wav'), soft: require('../assets/sounds/soft.wav'), adhan: require('../assets/sounds/adhan.wav'),
};
export const settingsListeners = new Set<(settings: PrayerSettings) => void>();
export async function readPrayerSettings() { return parsePrayerSettings(await AsyncStorage.getItem('prayer-alert-settings')); }
export async function savePrayerSettings(settings: PrayerSettings) {
  await AsyncStorage.setItem('prayer-alert-settings', JSON.stringify(settings));
  settingsListeners.forEach((listener) => listener(settings));
}
let player: ReturnType<typeof createAudioPlayer> | undefined;
export function stopPrayerSound() { player?.pause(); }
export async function previewPrayerSound(sound: SoundId) {
  await setAudioModeAsync({ playsInSilentMode: true });
  if (!player) player = createAudioPlayer(soundSources[sound]);
  else player.replace(soundSources[sound]);
  player.play();
}
export async function requestPrayerPermissions() {
  if (Platform.OS === 'web') { await previewPrayerSound('bell'); return; }
  if (Platform.OS === 'android') {
    for (const sound of PRAYER_SOUNDS) await Notifications.setNotificationChannelAsync(`prayer-${sound.id}`, {
      name: `Namaz: ${sound.label}`, importance: Notifications.AndroidImportance.HIGH,
      sound: `${sound.id}.wav`, vibrationPattern: [0, 250, 150, 250],
    });
  }
  const result = await Notifications.requestPermissionsAsync();
  if (!result.granted) throw new Error('Bildirim izni verilmedi. Telefon ayarlarından E-Sufy bildirimlerini açın.');
}
export type PrayerAlertStatus = { error: string | null; city: string; scheduledUntil: string | null };
let status: PrayerAlertStatus = { error: null, city: 'Kayseri', scheduledUntil: null };
export const statusListeners = new Set<(status: PrayerAlertStatus) => void>();
export function getPrayerAlertStatus() { return status; }
export function reportPrayerAlertStatus(value: PrayerAlertStatus) {
  status = value; statusListeners.forEach((listener) => listener(status));
}
