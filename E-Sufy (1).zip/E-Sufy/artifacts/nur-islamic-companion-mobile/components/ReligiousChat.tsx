import { Ionicons } from '@expo/vector-icons';
import { useReligiousChat } from '@workspace/api-client-react';
import { useRef, useState } from 'react';
import { ActivityIndicator, FlatList, Modal, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { KeyboardAvoidingView } from 'react-native-keyboard-controller';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

type Msg = { id: string; role: 'user' | 'assistant'; content: string; refused?: boolean };
let counter = 0;
const nid = () => `m${Date.now()}-${counter++}`;

export function ReligiousChat() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [text, setText] = useState('');
  const [failed, setFailed] = useState<string | null>(null);
  const messagesRef = useRef<Msg[]>([]);
  const chat = useReligiousChat();
  const pending = chat.isPending;
  const set = (next: Msg[]) => { messagesRef.current = next; setMessages(next); };

  const ask = async (question: string, base: Msg[]) => {
    setFailed(null);
    const history = base.filter((m) => !m.refused).slice(-10).map(({ role, content }) => ({ role, content: content.slice(0, 4000) }));
    try {
      const res = await chat.mutateAsync({ data: { question, history } });
      set([...messagesRef.current, { id: nid(), role: 'assistant', content: res.answer, refused: !res.allowed }]);
    } catch { setFailed(question); }
  };
  const submit = () => {
    const q = text.trim();
    if (!q || pending) return;
    const base = messagesRef.current;
    set([...base, { id: nid(), role: 'user', content: q }]);
    setText('');
    void ask(q, base);
  };
  const retry = () => { if (failed && !pending) void ask(failed, messagesRef.current.slice(0, -1)); };
  const clear = () => { if (pending) return; set([]); setFailed(null); setText(''); };
  const data = [...messages].reverse();

  return <>
    {!open && <Pressable testID="button-chat-open" accessibilityRole="button" accessibilityLabel="Dini soru asistanını aç" onPress={() => setOpen(true)}
      style={[styles.fab, { backgroundColor: colors.primary, bottom: insets.bottom + (Platform.OS === 'web' ? 100 : 76), right: 16 }]}>
      <Ionicons name="chatbubble-ellipses" size={25} color={colors.primaryForeground} />
    </Pressable>}
    <Modal visible={open} animationType="slide" transparent onRequestClose={() => setOpen(false)}>
      <View style={styles.backdrop}>
        <KeyboardAvoidingView behavior="padding" style={styles.kav}>
          <View style={[styles.panel, { backgroundColor: colors.background, borderColor: `${colors.primary}30`, paddingBottom: insets.bottom + 8, paddingTop: 12 }]}>
            <View style={styles.head}>
              <View style={{ flex: 1 }}><Text style={[styles.title, { color: colors.foreground }]}>Dini Soru Asistanı</Text><Text style={[styles.brand, { color: colors.primary }]}>E-SUFY</Text></View>
              <Pressable onPress={clear} disabled={pending || messages.length === 0} accessibilityLabel="Sohbeti temizle" testID="button-chat-clear" style={[styles.iconBtn, { opacity: pending || messages.length === 0 ? 0.35 : 1 }]}><Ionicons name="trash-outline" size={20} color={colors.primary} /></Pressable>
              <Pressable onPress={() => setOpen(false)} accessibilityLabel="Sohbeti kapat" testID="button-chat-close" style={styles.iconBtn}><Ionicons name="close" size={24} color={colors.primary} /></Pressable>
            </View>
            <View style={[styles.notice, { backgroundColor: `${colors.primary}14` }]}>
              <Text style={[styles.noticeText, { color: colors.mutedForeground }]}>Yalnızca İslam ve dini konulardaki sorulara yanıt verir.</Text>
              <Text style={[styles.noticeText, { color: colors.mutedForeground }]}>Yanıtlar eğitim amaçlıdır, fetva değildir; kesin hüküm için yetkili bir din görevlisine danışın.</Text>
            </View>
            <FlatList inverted style={styles.list} contentContainerStyle={{ padding: 14, gap: 10 }} data={data} keyExtractor={(m) => m.id}
              keyboardShouldPersistTaps="handled" keyboardDismissMode="interactive"
              ListHeaderComponent={<View style={{ gap: 10 }}>
                {pending ? <View style={styles.row}><ActivityIndicator color={colors.primary} /><Text style={[styles.small, { color: colors.mutedForeground }]}>Yanıt hazırlanıyor...</Text></View> : null}
                {failed && !pending ? <View accessibilityRole="alert" style={[styles.err, { borderColor: `${colors.destructive}60`, backgroundColor: `${colors.destructive}18` }]}>
                  <Text style={[styles.small, { color: colors.foreground }]}>Yanıt alınamadı. Bağlantınızı kontrol edip tekrar deneyin.</Text>
                  <Pressable onPress={retry} testID="button-chat-retry" style={styles.row}><Ionicons name="refresh" size={14} color={colors.primary} /><Text style={[styles.small, { color: colors.primary, fontWeight: '800' }]}>Tekrar dene</Text></Pressable></View> : null}
              </View>}
              ListEmptyComponent={<Text style={[styles.empty, { color: colors.mutedForeground, transform: [{ scaleY: -1 }] }]}>Örneğin: Teravih namazı kaç rekâttır?</Text>}
              renderItem={({ item }) => <View style={{ alignItems: item.role === 'user' ? 'flex-end' : 'flex-start' }}>
                <View style={[styles.bubble, item.role === 'user' ? { backgroundColor: colors.primary } : item.refused ? { backgroundColor: `${colors.destructive}20`, borderWidth: 1, borderColor: `${colors.destructive}70` } : { backgroundColor: colors.card }]}>
                  {item.refused ? <Text style={[styles.badge, { color: colors.destructive }]}>KAPSAM DIŞI</Text> : null}
                  <Text selectable style={{ fontSize: 14, lineHeight: 21, color: item.role === 'user' ? colors.primaryForeground : colors.foreground }}>{item.content}</Text>
                </View></View>} />
            <View style={styles.inputRow}>
              <TextInput value={text} onChangeText={setText} maxLength={2000} multiline placeholder="Dini bir soru sorun" placeholderTextColor={colors.mutedForeground} accessibilityLabel="Sorunuz" testID="input-chat"
                style={[styles.input, { color: colors.foreground, backgroundColor: colors.card, borderColor: `${colors.primary}30` }]} />
              <Pressable onPress={submit} disabled={pending || !text.trim()} accessibilityLabel="Gönder" testID="button-chat-send" style={[styles.send, { backgroundColor: colors.primary, opacity: pending || !text.trim() ? 0.4 : 1 }]}><Ionicons name="send" size={18} color={colors.primaryForeground} /></Pressable>
            </View>
          </View>
        </KeyboardAvoidingView>
      </View>
    </Modal>
  </>;
}

const styles = StyleSheet.create({
  fab: { position: 'absolute', width: 56, height: 56, borderRadius: 28, alignItems: 'center', justifyContent: 'center', elevation: 8, shadowColor: '#000', shadowOpacity: 0.3, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, zIndex: 50 },
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  kav: { maxHeight: '90%', width: '100%' },
  panel: { borderTopLeftRadius: 26, borderTopRightRadius: 26, borderWidth: 1, height: '100%', maxHeight: 640 },
  head: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingBottom: 8 },
  title: { fontSize: 16, fontWeight: '800' },
  brand: { fontSize: 10, letterSpacing: 2, fontWeight: '700' },
  iconBtn: { width: 44, height: 44, alignItems: 'center', justifyContent: 'center' },
  notice: { marginHorizontal: 14, padding: 10, borderRadius: 12, gap: 3 },
  noticeText: { fontSize: 11, lineHeight: 16 },
  list: { flex: 1 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  small: { fontSize: 12, lineHeight: 18 },
  err: { borderWidth: 1, borderRadius: 14, padding: 12, gap: 8 },
  empty: { textAlign: 'center', fontSize: 13, paddingVertical: 30 },
  bubble: { maxWidth: '88%', borderRadius: 16, paddingHorizontal: 13, paddingVertical: 9 },
  badge: { fontSize: 10, fontWeight: '800', letterSpacing: 1.4, marginBottom: 4 },
  inputRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 8, paddingHorizontal: 12, paddingTop: 6 },
  input: { flex: 1, maxHeight: 110, minHeight: 44, borderWidth: 1, borderRadius: 14, paddingHorizontal: 12, paddingVertical: 10, fontSize: 14 },
  send: { width: 44, height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
});
