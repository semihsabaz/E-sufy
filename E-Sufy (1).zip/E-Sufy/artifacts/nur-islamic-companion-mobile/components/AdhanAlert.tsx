import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';
import { useEffect, useRef, useState } from 'react';
import { AppState, Platform } from 'react-native';
import { buildPrayerEvents, duePrayerEvents, eventMessage, fetchPrayerCalendar, turkeyDate, type PrayerEvent, type PrayerSettings } from '@workspace/prayer-alerts';
import { readPrayerSettings, settingsListeners, reportPrayerAlertStatus, previewPrayerSound, stopPrayerSound } from './prayer-settings';
import { usePrayerCity } from './prayer-city';
export { notifyPrayerCityChanged } from './prayer-city';

if (Platform.OS !== 'web') Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldPlaySound: true, shouldSetBadge: false, shouldShowBanner: true, shouldShowList: true,
  }),
});

async function cancelPrayerNotifications() {
  const planned = await Notifications.getAllScheduledNotificationsAsync();
  await Promise.all(planned.filter((item) => item.identifier.startsWith('esufy-prayer:'))
    .map((item) => Notifications.cancelScheduledNotificationAsync(item.identifier)));
}
let schedulingQueue: Promise<unknown> = Promise.resolve();
export function AdhanAlert() {
  const city = usePrayerCity();
  const [settings, setSettings] = useState<PrayerSettings | null>(null);
  const [revision, setRevision] = useState(0);
  const generation = useRef(0);
  const lastDay = useRef(turkeyDate());
  const webEvents = useRef<PrayerEvent[]>([]);
  const delivered = useRef(new Set<string>());
  useEffect(() => {
    let alive = true, changed = false;
    const update = (value: PrayerSettings) => { changed = true; setSettings(value); };
    settingsListeners.add(update);
    void readPrayerSettings().then((value) => { if (alive && !changed) setSettings(value); });
    if (Platform.OS === 'web') void AsyncStorage.getItem('prayer-delivered-events').then((raw) => {
      try { if (raw) delivered.current = new Set(JSON.parse(raw)); } catch { /* Historical ID cache only. */ }
    });
    const subscription = AppState.addEventListener('change', (state) => {
      if (state === 'active') setRevision((value) => value + 1);
    });
    const timer = setInterval(() => {
      const day = turkeyDate();
      if (lastDay.current !== day) { lastDay.current = day; setRevision((value) => value + 1); }
    }, 30000);
    return () => { alive = false; settingsListeners.delete(update); subscription.remove(); clearInterval(timer); };
  }, []);
  useEffect(() => {
    if (!settings) return;
    const version = ++generation.current;
    webEvents.current = [];
    stopPrayerSound();
    const current = () => generation.current === version;
    const plan = async () => {
      if (!current()) return;
      reportPrayerAlertStatus({ city, error: null, scheduledUntil: null });
      if (Platform.OS !== 'web') await cancelPrayerNotifications();
      if (!current() || !settings.enabled) return;
      if (Platform.OS !== 'web') {
        const permission = await Notifications.getPermissionsAsync();
        if (!permission.granted) throw new Error('Bildirim izni kapalı. Telefon ayarlarından izin verin.');
      }
      const days = await fetchPrayerCalendar(city, Platform.OS === 'web' ? 2 : 6);
      if (!current()) return;
      const events = buildPrayerEvents(city, days, settings);
      if (Platform.OS === 'web') webEvents.current = events;
      else {
        for (const event of events.filter((item) => item.timestamp > Date.now()).slice(0, 60)) {
          if (!current()) return;
          const identifier = await Notifications.scheduleNotificationAsync({
            identifier: event.id,
            content: {
              title: event.kind === 'reminder' ? 'Namaz vaktine 10 dakika' : 'Namaz vakti geldi',
              body: eventMessage(event), sound: `${event.tone}.wav`,
              data: { city, prayer: event.prayer, kind: event.kind },
            },
            trigger: { type: Notifications.SchedulableTriggerInputTypes.DATE, date: new Date(event.timestamp), channelId: `prayer-${event.tone}` },
          });
          if (!current()) { await Notifications.cancelScheduledNotificationAsync(identifier); return; }
        }
      }
      if (current()) reportPrayerAlertStatus({ city, error: null, scheduledUntil: days.at(-1)!.date });
    };
    // Serialize replanning so old requests cannot overwrite a newer city's plan.
    schedulingQueue = schedulingQueue.catch(() => {}).then(plan).catch((err: unknown) => {
      if (current()) reportPrayerAlertStatus({
        city, scheduledUntil: null,
        error: err instanceof Error ? err.message : 'Bildirim planlanamadı. Bağlantınızı ve izinleri kontrol edin.',
      });
    });
    return () => { generation.current++; webEvents.current = []; };
  }, [city, settings, revision]);
  useEffect(() => {
    if (Platform.OS !== 'web') return;
    const timer = setInterval(() => {
      for (const event of duePrayerEvents(webEvents.current, Date.now(), delivered.current)) {
        delivered.current.add(event.id);
        void AsyncStorage.setItem('prayer-delivered-events', JSON.stringify([...delivered.current].slice(-120)));
        void previewPrayerSound(event.tone).catch(() => reportPrayerAlertStatus({
          city: event.city, scheduledUntil: null, error: 'Tarayıcı sesi engelledi. Ayarlar’dan melodiyi deneyerek sesi etkinleştirin.',
        }));
      }
    }, 1000);
    return () => clearInterval(timer);
  }, []);
  return null;
}
