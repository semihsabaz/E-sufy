import AsyncStorage from '@react-native-async-storage/async-storage';
import { useEffect, useRef, useState } from 'react';
const listeners = new Set<(city: string) => void>();
export function notifyPrayerCityChanged(city: string) { listeners.forEach((listener) => listener(city)); }
export function usePrayerCity() {
  const [city, setCity] = useState('Kayseri');
  const revision = useRef(0);
  useEffect(() => {
    let alive = true;
    const handle = (value: string) => { revision.current++; setCity(value); };
    listeners.add(handle);
    const initialRevision = revision.current;
    void AsyncStorage.getItem('prayer-city').then((value) => {
      if (alive && revision.current === initialRevision && value) setCity(value);
    });
    return () => { alive = false; listeners.delete(handle); };
  }, []);
  return city;
}
