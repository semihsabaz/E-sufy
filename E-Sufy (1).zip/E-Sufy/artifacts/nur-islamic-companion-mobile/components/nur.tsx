import { Feather, Ionicons } from '@expo/vector-icons';
import { useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { turkeyDate } from '@workspace/prayer-alerts';
import {
  ActivityIndicator,
  Image,
  Linking,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

export type Prayer = { key: string; label: string; arabic: string; time: string };

export const prayerMeta: Prayer[] = [
  { key: 'Fajr', label: 'İmsak', arabic: 'الفجر', time: '05:31' },
  { key: 'Sunrise', label: 'Güneş', arabic: 'الشروق', time: '07:02' },
  { key: 'Dhuhr', label: 'Öğle', arabic: 'الظهر', time: '13:08' },
  { key: 'Asr', label: 'İkindi', arabic: 'العصر', time: '16:27' },
  { key: 'Maghrib', label: 'Akşam', arabic: 'المغرب', time: '19:02' },
  { key: 'Isha', label: 'Yatsı', arabic: 'العشاء', time: '20:29' },
];

export const cities = [
  'Adana', 'Adıyaman', 'Afyonkarahisar', 'Ağrı', 'Aksaray', 'Amasya', 'Ankara', 'Antalya', 'Ardahan', 'Artvin',
  'Aydın', 'Balıkesir', 'Bartın', 'Batman', 'Bayburt', 'Bilecik', 'Bingöl', 'Bitlis', 'Bolu', 'Burdur',
  'Bursa', 'Çanakkale', 'Çankırı', 'Çorum', 'Denizli', 'Diyarbakır', 'Düzce', 'Edirne', 'Elazığ', 'Erzincan',
  'Erzurum', 'Eskişehir', 'Gaziantep', 'Giresun', 'Gümüşhane', 'Hakkâri', 'Hatay', 'Iğdır', 'Isparta', 'İstanbul',
  'İzmir', 'Kahramanmaraş', 'Karabük', 'Karaman', 'Kars', 'Kastamonu', 'Kayseri', 'Kırıkkale', 'Kırklareli', 'Kırşehir',
  'Kilis', 'Kocaeli', 'Konya', 'Kütahya', 'Malatya', 'Manisa', 'Mardin', 'Mersin', 'Muğla', 'Muş',
  'Nevşehir', 'Niğde', 'Ordu', 'Osmaniye', 'Rize', 'Sakarya', 'Samsun', 'Siirt', 'Sinop', 'Sivas',
  'Şanlıurfa', 'Şırnak', 'Tekirdağ', 'Tokat', 'Trabzon', 'Tunceli', 'Uşak', 'Van', 'Yalova', 'Yozgat', 'Zonguldak',
];

const hadiths = [
  { text: 'Ameller niyetlere göredir. Herkese niyet ettiği şey vardır.', source: 'Buhârî, Bed’ü’l-vahy 1', narrator: 'Hz. Ömer (r.a.)' },
  { text: 'Sizin en hayırlınız, Kur’an’ı öğrenen ve öğreteninizdir.', source: 'Buhârî, Fedâilü’l-Kur’ân 21', narrator: 'Hz. Osman (r.a.)' },
  { text: 'Güzel söz sadakadır.', source: 'Buhârî, Edeb 34', narrator: 'Ebû Hüreyre (r.a.)' },
  { text: 'Kolaylaştırınız, zorlaştırmayınız; müjdeleyiniz, nefret ettirmeyiniz.', source: 'Buhârî, İlim 11', narrator: 'Enes b. Mâlik (r.a.)' },
];

type PrayerResponse = { data?: { timings?: Record<string, string>; date?: { readable?: string } } };

export function usePrayerTimes(city: string) {
  const [prayers, setPrayers] = useState<Prayer[]>(prayerMeta);
  const [date, setDate] = useState('Bugün');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const [day, setDay] = useState(turkeyDate);
  const [revision, setRevision] = useState(0);
  const request = useRef(0);
  useEffect(() => {
    const timer = setInterval(() => setDay(turkeyDate()), 30000);
    return () => clearInterval(timer);
  }, []);
  useEffect(() => {
    const version = ++request.current;
    let alive = true;
    setLoading(true);
    setError(false);
    fetch(`https://api.aladhan.com/v1/timingsByCity?city=${encodeURIComponent(city)}&country=Turkey&method=13`)
      .then((res) => { if (!res.ok) throw new Error('Prayer service'); return res.json() as Promise<PrayerResponse>; })
      .then((json) => {
        if (!alive || version !== request.current) return;
        const timings = json.data?.timings;
        if (!timings || prayerMeta.some((item) => !/^\d{2}:\d{2}/.test(timings[item.key] ?? ''))) throw new Error('Invalid prayer times');
        setPrayers(prayerMeta.map((item) => ({ ...item, time: timings[item.key]!.slice(0, 5) })));
        setDate(json.data?.date?.readable ?? 'Bugün');
      })
      .catch(() => alive && version === request.current && setError(true))
      .finally(() => alive && version === request.current && setLoading(false));
    return () => { alive = false; };
  }, [city, day, revision]);
  return { prayers, date, loading, error, retry: () => setRevision((value) => value + 1) };
}

export function getNextPrayer(prayers: Prayer[]) {
  const now = new Date();
  const current = now.getHours() * 60 + now.getMinutes();
  const future = prayers.map((p) => ({ ...p, minutes: Number(p.time.slice(0, 2)) * 60 + Number(p.time.slice(3)) })).find((p) => p.minutes > current);
  return future ?? { ...prayers[0], minutes: Number(prayers[0].time.slice(0, 2)) * 60 + Number(prayers[0].time.slice(3)) + 1440 };
}

export function useCountdown(prayer: Prayer) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const timer = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(timer); }, []);
  const target = new Date(now);
  target.setHours(Number(prayer.time.slice(0, 2)), Number(prayer.time.slice(3)), 0, 0);
  if (target.getTime() <= now) target.setDate(target.getDate() + 1);
  const diff = Math.max(0, target.getTime() - now);
  const hours = Math.floor(diff / 3600000).toString().padStart(2, '0');
  const minutes = Math.floor(diff / 60000 % 60).toString().padStart(2, '0');
  const seconds = Math.floor(diff / 1000 % 60).toString().padStart(2, '0');
  return { label: `${hours}:${minutes}:${seconds}`, date: new Date(now) };
}

export function useHadith() {
  const [index, setIndex] = useState(() => new Date().getDate() % hadiths.length);
  return { hadith: hadiths[index], index, next: () => setIndex((value) => (value + 1) % hadiths.length), random: () => setIndex(Math.floor(Math.random() * hadiths.length)) };
}

export function Screen({ children, scroll = true }: { children: ReactNode; scroll?: boolean }) {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const topPadding = Platform.OS === 'ios'
    ? Math.max(insets.top + 10, 64)
    : insets.top + 10;
  const content = <View style={[styles.content, { paddingTop: topPadding, paddingBottom: insets.bottom + 92 }]}>{children}</View>;
  return <View style={[styles.screen, { backgroundColor: colors.background }]}><Text pointerEvents="none" style={[styles.watermark, { color: colors.primary }]}>الله</Text>{scroll ? <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ flexGrow: 1 }}>{content}</ScrollView> : content}</View>;
}

export function Header({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  const colors = useColors();
  return <View style={styles.header}><View><Text style={[styles.brand, { color: colors.primary }]}>E-Sufy</Text><Text style={[styles.title, { color: colors.foreground }]}>{title}</Text>{subtitle ? <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>{subtitle}</Text> : null}</View>{action ?? <View style={[styles.headerMark, { backgroundColor: `${colors.primary}18` }]}><Ionicons name="moon" size={19} color={colors.primary} /></View>}</View>;
}

export function SectionLabel({ children }: { children: ReactNode }) {
  const colors = useColors();
  return <Text style={[styles.sectionLabel, { color: colors.primary }]}>{children}</Text>;
}

export function Card({ children, style }: { children: ReactNode; style?: object }) {
  const colors = useColors();
  return <View style={[styles.card, { backgroundColor: colors.card, borderColor: `${colors.primary}22` }, style]}>{children}</View>;
}

export function CityPicker({ city, onChange }: { city: string; onChange: (value: string) => void }) {
  const colors = useColors();
  const [open, setOpen] = useState(false);
  return <>
    <Pressable onPress={() => setOpen(true)} style={[styles.cityPicker, { borderColor: `${colors.primary}25`, backgroundColor: colors.card }]}>
      <Ionicons name="location-outline" size={18} color={colors.primary} />
      <View style={styles.cityPickerCopy}><Text style={[styles.cityPickerLabel, { color: colors.mutedForeground }]}>Konum</Text><Text style={[styles.cityPickerValue, { color: colors.foreground }]}>{city}</Text></View>
      <Ionicons name="chevron-down" size={18} color={colors.mutedForeground} />
    </Pressable>
    <Modal visible={open} transparent animationType="fade" onRequestClose={() => setOpen(false)}>
      <View style={styles.cityModalBackdrop}>
        <View style={[styles.cityModalCard, { borderColor: `${colors.primary}30`, backgroundColor: colors.card }]}>
          <View style={styles.cityModalHeader}><View><Text style={[styles.cityModalTitle, { color: colors.foreground }]}>İl seçin</Text><Text style={[styles.cityModalSubtitle, { color: colors.mutedForeground }]}>Türkiye · 81 il</Text></View><Pressable onPress={() => setOpen(false)} accessibilityLabel="İl seçimini kapat"><Ionicons name="close" size={21} color={colors.mutedForeground} /></Pressable></View>
          <ScrollView showsVerticalScrollIndicator contentContainerStyle={styles.cityModalList}>{cities.map((item) => <Pressable key={item} onPress={() => { onChange(item); setOpen(false); }} style={[styles.cityOption, { borderColor: `${colors.primary}18`, backgroundColor: item === city ? `${colors.primary}18` : colors.background }]}><Text style={[styles.cityOptionText, { color: item === city ? colors.primary : colors.foreground }]}>{item}</Text>{item === city ? <Ionicons name="checkmark" size={17} color={colors.primary} /> : null}</Pressable>)}</ScrollView>
        </View>
      </View>
    </Modal>
  </>;
}

export function PrayerStrip({ prayers, loading, error }: { prayers: Prayer[]; loading: boolean; error: boolean }) {
  const colors = useColors();
  const next = getNextPrayer(prayers);
  return <View style={styles.prayerGrid}>{prayers.map((prayer) => <View key={prayer.key} style={[styles.prayerCard, { backgroundColor: colors.card, borderColor: prayer.key === next.key ? `${colors.primary}80` : `${colors.primary}18` }]}><View style={styles.prayerTop}><Text style={[styles.smallText, { color: colors.mutedForeground }]}>{prayer.label}</Text><Text style={[styles.arabicSmall, { color: colors.mutedForeground }]}>{prayer.arabic}</Text></View><Text style={[styles.prayerTime, { color: prayer.key === next.key ? colors.primary : colors.foreground }]}>{loading ? '--:--' : prayer.time}</Text>{prayer.key === next.key ? <Text style={[styles.nextText, { color: colors.primary }]}>Sıradaki</Text> : null}</View>)}</View>;
}

export function Hero() {
  const colors = useColors();
  return <View style={styles.hero}><Image source={{ uri: 'https://commons.wikimedia.org/wiki/Special:FilePath/Kaaba.jpg?width=1200' }} style={StyleSheet.absoluteFillObject} resizeMode="cover" /><LinearGradient colors={['#1B2719E8', '#1B2719B8', '#1B271926']} start={{ x: 0, y: 0.4 }} end={{ x: 1, y: 0.5 }} style={StyleSheet.absoluteFillObject} /><View style={styles.heroCopy}><Text style={[styles.kicker, { color: colors.primary }]}>SELAMÜN ALEYKÜM</Text><Text style={[styles.heroTitle, { color: colors.foreground }]}>Gününüz{'\n'}<Text style={{ color: colors.primary }}>bereketli</Text> olsun.</Text><Text style={[styles.heroBody, { color: '#E1DBC8' }]}>Kalbinize iyi gelecek küçük hatırlatmalar, her gün yanınızda.</Text></View></View>;
}

export function OpenLive({ url }: { url: string }) {
  const colors = useColors();
  return <Pressable onPress={() => Linking.openURL(url)} style={({ pressed }) => [styles.liveButton, { backgroundColor: colors.primary, opacity: pressed ? 0.75 : 1 }]}><Feather name="external-link" size={15} color={colors.primaryForeground} /><Text style={[styles.liveButtonText, { color: colors.primaryForeground }]}>YouTube’da aç</Text></Pressable>;
}

export function LoadingState({ label = 'Hazırlanıyor' }: { label?: string }) {
  const colors = useColors();
  return <View style={styles.loading}><ActivityIndicator color={colors.primary} /><Text style={[styles.smallText, { color: colors.mutedForeground }]}>{label}</Text></View>;
}

export function formatDate(date: Date) {
  return new Intl.DateTimeFormat('tr-TR', { day: 'numeric', month: 'long' }).format(date);
}

export function getHadiths() { return hadiths; }

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 18, gap: 20 },
  watermark: { position: 'absolute', top: '33%', alignSelf: 'center', opacity: 0.045, fontSize: 220, fontFamily: 'serif', zIndex: 0 },
  header: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 14 },
  brand: { fontSize: 11, fontWeight: '700', letterSpacing: 3 },
  title: { marginTop: 7, fontSize: 28, fontWeight: '800', letterSpacing: -0.8 },
  subtitle: { marginTop: 6, fontSize: 14, lineHeight: 20 },
  headerMark: { width: 42, height: 42, borderRadius: 15, alignItems: 'center', justifyContent: 'center' },
  sectionLabel: { fontSize: 10, fontWeight: '700', letterSpacing: 2.2, textTransform: 'uppercase' },
  card: { borderRadius: 22, borderWidth: 1, padding: 17 },
  cityPicker: { minHeight: 58, flexDirection: 'row', alignItems: 'center', borderRadius: 17, borderWidth: 1, paddingHorizontal: 14 },
  cityPickerCopy: { flex: 1, marginLeft: 10 },
  cityPickerLabel: { fontSize: 10, letterSpacing: 1.2, textTransform: 'uppercase' },
  cityPickerValue: { marginTop: 3, fontSize: 15, fontWeight: '700' },
  cityModalBackdrop: { flex: 1, justifyContent: 'center', padding: 20, backgroundColor: '#00000088' },
  cityModalCard: { maxHeight: '82%', borderRadius: 24, borderWidth: 1, padding: 18 },
  cityModalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 14 },
  cityModalTitle: { fontSize: 20, fontWeight: '800' },
  cityModalSubtitle: { marginTop: 3, fontSize: 11 },
  cityModalList: { gap: 8, paddingBottom: 4 },
  cityOption: { minHeight: 44, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderRadius: 13, borderWidth: 1, paddingHorizontal: 13 },
  cityOptionText: { fontSize: 13, fontWeight: '600' },
  prayerGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  prayerCard: { width: '31.5%', minHeight: 88, borderRadius: 17, borderWidth: 1, padding: 11 },
  prayerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  smallText: { fontSize: 11 },
  arabicSmall: { fontFamily: 'serif', fontSize: 14 },
  prayerTime: { marginTop: 12, fontSize: 22, fontWeight: '800', letterSpacing: -0.5 },
  nextText: { marginTop: 3, fontSize: 9, fontWeight: '700' },
  hero: { height: 260, overflow: 'hidden', borderRadius: 26, borderWidth: 1, borderColor: '#D4AF3738' },
  heroCopy: { flex: 1, justifyContent: 'center', padding: 22, maxWidth: 340 },
  kicker: { fontSize: 10, letterSpacing: 2.2, fontWeight: '700', marginBottom: 14 },
  heroTitle: { fontSize: 35, lineHeight: 37, fontWeight: '800', letterSpacing: -1.4 },
  heroBody: { marginTop: 13, fontSize: 13, lineHeight: 19 },
  liveButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 7, borderRadius: 13, paddingHorizontal: 13, paddingVertical: 11 },
  liveButtonText: { fontSize: 11, fontWeight: '700' },
  loading: { minHeight: 130, alignItems: 'center', justifyContent: 'center', gap: 10 },
});