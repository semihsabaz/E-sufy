import { createHash } from 'node:crypto';
import { and, asc, count, desc, eq, lte, sql } from 'drizzle-orm';
import { db, storiesTable } from '@workspace/db';
import { openai } from '@workspace/integrations-openai-ai-server';
import { batchProcess } from '@workspace/integrations-openai-ai-server/batch';
import { z } from 'zod';
import { logger } from './logger';
import { storySources } from './story-sources';
import { initialStoryArchive } from './story-archive';

export const PUBLICATION_TIMEZONE = 'Europe/Istanbul';
export const PAGE_SIZE = 9;
export function publicationDay(now = new Date()) {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: PUBLICATION_TIMEZONE, year: 'numeric', month: '2-digit', day: '2-digit',
  }).format(now);
}
export function addDays(day: string, days: number) {
  const date = new Date(`${day}T12:00:00Z`);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}
export function nextPublicationAt(now = new Date()) {
  return `${addDays(publicationDay(now), 1)}T00:00:00+03:00`;
}
function fingerprint(content: string) {
  return createHash('sha256').update(content.toLocaleLowerCase('tr-TR').replace(/\s+/g, ' ').trim()).digest('hex');
}
const generatedEdition = z.object({
  stories: z.array(z.object({
    sourceId: z.string(),
    title: z.string().min(4).max(120),
    theme: z.string().min(3).max(80),
    summary: z.string().min(40).max(450),
    content: z.string().min(180).max(3500),
    lesson: z.string().min(20).max(500),
  })).length(PAGE_SIZE),
});

async function seedArchive() {
  await db.transaction(async (tx) => {
    await tx.execute(sql`SELECT pg_advisory_xact_lock(71423901)`);
    const existing = await tx.select({ id: storiesTable.id }).from(storiesTable).where(eq(storiesTable.archive, true)).limit(1);
    if (existing.length) return;
    await tx.insert(storiesTable).values(initialStoryArchive.map((item, position) => ({
      ...item, publicationDate: publicationDay(), archive: true, position,
      fingerprint: fingerprint(item.content),
    })));
  });
}

export async function ensureEdition(day: string) {
  await db.transaction(async (tx) => {
    // A transaction and a cross-process lock prevent duplicate calls/partial editions.
    await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtext(${`daily-stories:${day}`}))`);
    const existing = await tx.select({ value: count() }).from(storiesTable)
      .where(and(eq(storiesTable.publicationDate, day), eq(storiesTable.archive, false)));
    if (existing[0]?.value === PAGE_SIZE) return;
    if (existing[0]?.value) throw new Error('Incomplete story edition; manual review required');

    const dayNumber = Math.floor(Date.parse(`${day}T00:00:00Z`) / 86400000);
    const sources = Array.from({ length: PAGE_SIZE }, (_, i) => storySources[(dayNumber * PAGE_SIZE + i) % storySources.length]!);
    const prior = await tx.select({ title: storiesTable.title, content: storiesTable.content })
      .from(storiesTable).orderBy(desc(storiesTable.publicationDate)).limit(27);
    const [edition] = await batchProcess([day], async () => {
      const completion = await openai.chat.completions.create({
        model: 'gpt-5.6-terra',
        max_completion_tokens: 8192,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: 'Türkçe bir İslami kıssa editörüsün. Sana verilen DOKUZ kaynaktan, her kaynak için tam bir yeni okuma metni oluştur. Sadece facts alanındaki olumlu bilgileri yeniden anlat; "yer almaz/söylemez" uyarılarında geçen ayrıntıları gerçek diye yazma. Yeni olay, kişi adı, konuşma, mucize, yer veya kesin dini hüküm ekleme. Ayet veya hadis tırnak içinde uydurma. Metinler Kur’an kaynaklı yorumlu özetlerdir, meal veya hadis değildir. Tekrarlanan konuları farklı bir ders odağıyla ama olguları değiştirmeden anlat. Her content 2-3 kısa paragraf, 100-180 Türkçe sözcük olsun. Özet 1-2 cümle, lesson tek kısa öğüt. JSON biçimi: {"stories":[{"sourceId":"verilen id","title":"başlık","theme":"tema","summary":"özet","content":"paragraflar","lesson":"öğüt"}]}. Tam9 farklı sourceId, belirtilen sırada. Önceki metinleri aynen tekrarlama.' },
          { role: 'user', content: JSON.stringify({ date: day, sources, previousReadings: prior }) },
        ],
      }, { timeout: 120000 });
      const text = completion.choices[0]?.message.content;
      if (!text || completion.choices[0]?.finish_reason !== 'stop') throw new Error('Incomplete AI edition');
      const parsed = generatedEdition.parse(JSON.parse(text));
      parsed.stories.forEach((item, index) => {
        if (item.sourceId !== sources[index]?.id) throw new Error('Unexpected source in daily edition');
      });
      const hashes = parsed.stories.map((item) => fingerprint(item.content));
      if (new Set(hashes).size !== PAGE_SIZE) throw new Error('Duplicate daily readings');
      const duplicated = await tx.select({ id: storiesTable.id }).from(storiesTable)
        .where(sql`${storiesTable.fingerprint} in (${sql.join(hashes.map((hash) => sql`${hash}`), sql`, `)})`).limit(1);
      if (duplicated.length) throw new Error('AI repeated an archived reading');
      return parsed;
    }, { concurrency: 1, retries: 2, minTimeout: 1500, maxTimeout: 10000 });
    if (!edition) throw new Error('Edition generation failed');
    await tx.insert(storiesTable).values(edition.stories.map(({ sourceId: _sourceId, ...item }, position) => ({
      ...item, publicationDate: day, position, archive: false,
      source: sources[position]!.source, fingerprint: fingerprint(item.content),
    })));
    logger.info({ day, count: PAGE_SIZE }, 'Daily story edition prepared');
  });
}

let maintenance: Promise<void> | undefined;
export function maintainPublicationWindow() {
  if (maintenance) return maintenance;
  maintenance = (async () => {
    await seedArchive();
    const today = publicationDay();
    const latest = await db.select({ day: storiesTable.publicationDate }).from(storiesTable)
      .where(eq(storiesTable.archive, false)).orderBy(desc(storiesTable.publicationDate)).limit(1);
    // Catch up days missed while the service was offline without deleting old readings.
    let day = latest[0]?.day && latest[0].day < today ? addDays(latest[0].day, 1) : today;
    while (day <= today) {
      await ensureEdition(day);
      day = addDays(day, 1);
    }
    // Tomorrow is persisted but excluded from every public query until midnight.
    await ensureEdition(addDays(today, 1));
  })().finally(() => { maintenance = undefined; });
  return maintenance;
}

export function startStoryPublisher() {
  const run = () => { void maintainPublicationWindow().catch((err) => logger.error({ err }, 'Story publication failed; will retry')); };
  run();
  const timer = setInterval(run, 15 * 60 * 1000);
  timer.unref();
}

export async function listPublishedStories(page: number, now = new Date()) {
  const today = publicationDay(now);
  const ready = await db.select({ value: count() }).from(storiesTable)
    .where(and(eq(storiesTable.publicationDate, today), eq(storiesTable.archive, false)));
  if (ready[0]?.value !== PAGE_SIZE) await maintainPublicationWindow();
  const visible = lte(storiesTable.publicationDate, today);
  const totals = await db.select({ value: count() }).from(storiesTable).where(visible);
  const total = totals[0]?.value ?? 0;
  const items = await db.select().from(storiesTable).where(visible)
    .orderBy(asc(storiesTable.archive), desc(storiesTable.publicationDate), asc(storiesTable.position))
    .limit(PAGE_SIZE).offset((page - 1) * PAGE_SIZE);
  return {
    items: items.map(({ id, title, theme, summary, content, lesson, source, publicationDate, archive }) => ({
      id, title, theme, summary, content, lesson, source, publicationDate,
      editionLabel: archive ? 'Başlangıç arşivi' : 'Günün kıssaları',
    })),
    page, pageSize: PAGE_SIZE, total, totalPages: Math.ceil(total / PAGE_SIZE),
    nextPublicationAt: nextPublicationAt(now), publicationTimezone: PUBLICATION_TIMEZONE,
  };
}
