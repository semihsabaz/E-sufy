import { storySources } from './story-sources';

// Preserve the five readings that existed before daily publishing.
export const initialStoryArchive = [
  {
    title: 'Ashab-ı Kehf', theme: 'Mağara Arkadaşları',
    summary: 'İnançları uğruna zalim bir hükümdardan kaçıp mağaraya sığınan ve yüzlerce yıl uyuyan gençlerin öyküsü.',
    content: 'Kur’an-ı Kerim’de Kehf Suresi’nde anlatılan Ashab-ı Kehf, putperest bir topluma ve zalim bir krala karşı tevhid inancını savunan birkaç gençten oluşur. Şehirlerinden kaçarak bir mağaraya sığınırlar. Yanlarında Kıtmir adında bir köpekleri de vardır. Allah onları mağarada derin bir uykuya daldırır. Uyandıklarında sadece bir gün uyuduklarını sanırlar. İçlerinden biri yiyecek almak için şehre indiğinde, taşıdığı eski paralar yüzünden gerçek ortaya çıkar; tam 309 yıl uyumuşlardır. Bu olay, öldükten sonra dirilmenin (haşr) bir delili olarak tüm şehre gösterilmiştir.',
    lesson: 'İnancını korumak ve Allah’a güvenmek.',
    source: 'Önceki uygulama arşivi. Kur’an: Kehf 18:9–26. Köpeğin “Kıtmir” adı gibi ayrıntılar Kur’an’da yer almaz; anlatım ayetlerin birebir metni değildir.',
  },
  {
    title: 'Hz. İbrahim ve Ateş', theme: 'Ateşin Serin Olması',
    summary: 'Putları kırdığı için Nemrut tarafından devasa bir ateşe atılan Hz. İbrahim’in gül bahçesine düşüşü.',
    content: 'Hz. İbrahim, halkının ve hükümdar Nemrut’un taptığı putların anlamsızlığını göstermek için bir bayram günü puthanedeki tüm putları kırıp baltayı en büyük putun boynuna asar. Döndüklerinde bunu kimin yaptığını soran halkına, “Şu büyük puta sorun, belki o yapmıştır” diyerek putların konuşamayacağını ve acizliğini gösterir. Öfkelenen Nemrut, onu büyük bir ateşe attırır. Ancak Allah ateşe, “Ey ateş! İbrahim’e karşı serin ve selamet ol” emrini verir. Ateş Hz. İbrahim’i yakmaz, onun için bir gül bahçesine dönüşür.',
    lesson: 'Baskı karşısında hakikate bağlı kalmak.',
    source: 'Önceki uygulama arşivi. Kur’an: Enbiyâ 21:51–70. “Gül bahçesi”, balta ve hükümdarın adı gibi ayrıntılar bu ayetlerde bulunmaz; geleneksel anlatımla ayet metni birbirinden ayrılmalıdır.',
  },
  {
    title: 'Hz. Yunus ve Balık', theme: 'Karanlıklar İçindeki Yakarı',
    summary: 'Kavminin isyanı üzerine şehri terk eden Hz. Yunus’un dev bir balık tarafından yutulması ve tövbesi.',
    content: 'Hz. Yunus, Ninova halkına peygamber olarak gönderilir ancak halkı ona uzun süre inanmaz. Ümidini yitiren Hz. Yunus, Allah’ın iznini beklemeden şehri terk eder ve bir gemiye biner. Çıkan fırtınada kura sonucu denize atılır ve dev bir balık onu yutar. Karanlıklar içinde, “Senden başka ilah yoktur. Seni tenzih ederim, muhakkak ki ben zalimlerden oldum” (Enbiya, 87) duasını okur. Allah duasını kabul eder ve balık onu sağ salim sahile bırakır. Geri döndüğünde halkının tövbe edip iman ettiğini görür.',
    lesson: 'Samimi tövbe ile umudu korumak.',
    source: 'Önceki uygulama arşivi. Kur’an: Enbiyâ 21:87–88; Sâffât 37:139–148. Şehir adı ve bazı olay ayrıntıları geleneksel anlatımdır.',
  },
  {
    title: 'Hz. Süleyman ve Karınca', theme: 'En Küçüğün Sesi',
    summary: 'Hz. Süleyman’ın ordusuyla ilerlerken, ezilmekten korkan bir karıncanın sesini duyması ve tebessümü.',
    content: 'Hz. Süleyman’a hayvanların dilini anlama mucizesi verilmişti. Bir gün devasa ordusuyla Karınca Vadisi’nden geçerken, bir karınca diğerlerine, “Ey karıncalar, yuvalarınıza girin, Süleyman ve ordusu farkında olmadan sizi ezmesin” der. Hz. Süleyman karıncanın bu sözünü duyar ve gülümser. Ordusunu durdurarak karıncaların güvenle yuvalarına girmesini bekler. Allah’ın kendisine verdiği bu nimetlere şükreder ve hiçbir canlıyı incitmemenin, adaletin önemini ordusuna gösterir.',
    lesson: 'Küçük canlılara duyarlı olmak ve şükretmek.',
    source: 'Önceki uygulama arşivi. Kur’an: Neml 27:17–19. Ordunun durdurulduğu ayrıntısı ayetlerde yer almaz; anlatım ayetlerin birebir metni değildir.',
  },
  {
    title: 'Hz. Ömer’in Adaleti', theme: 'Sırtında Un Taşıyan Halife',
    summary: 'Halife Hz. Ömer’in gece devriyesinde açlıktan ağlayan çocukları görüp sırtında un taşıması.',
    content: 'Hz. Ömer, hilafeti döneminde sık sık gece kılık değiştirerek Medine sokaklarını gezerdi. Bir gece, boş tencerede su kaynatarak çocuklarını avutmaya çalışan bir anne gördü. Kadın, Halife’nin durumlarından habersiz olmasından yakınıyordu. Hz. Ömer hemen erzak deposuna gidip bir çuval un ve yağ aldı. Yardımcısı yükü taşımak isteyince, “Kıyamet gününde benim günahımı sen mi yükleneceksin?” diyerek kendi sırtında taşıdı. Kadının yanına dönüp bizzat ateşi yaktı, yemeği pişirdi ve çocuklar doyana kadar başlarında bekledi.',
    lesson: 'Yöneticiliği bir sorumluluk olarak görmek.',
    source: 'Önceki uygulama arşivindeki tarihî anlatı. Ayrıntılı kaynak ve rivayet derecesi belirtilmemiştir; hadis-i şerif olarak sunulmaz.',
  },
  ...storySources.slice(4, 8).map((item) => ({
    title: item.title, theme: item.theme, summary: item.facts.split('. ')[0] + '.',
    content: item.facts, lesson: item.lesson, source: item.source,
  })),
];
