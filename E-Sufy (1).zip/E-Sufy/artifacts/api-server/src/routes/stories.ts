import { Router, type IRouter } from 'express';
import { ListStoriesQueryParams, ListStoriesResponse } from '@workspace/api-zod';
import { listPublishedStories } from '../lib/daily-stories';

const router: IRouter = Router();
router.get('/stories', async (req, res): Promise<void> => {
  const parsed = ListStoriesQueryParams.safeParse(req.query);
  if (!parsed.success || !Number.isInteger(parsed.data.page)) {
    res.status(400).json({ error: 'Sayfa numarası geçersiz.' });
    return;
  }
  try {
    const data = await listPublishedStories(parsed.data.page);
    res.setHeader('Cache-Control', 'no-store');
    res.json(ListStoriesResponse.parse(data));
  } catch (err) {
    req.log.error({ err }, 'Failed to load published stories');
    res.status(503).json({ error: 'Günlük kıssalar şu anda hazırlanamadı. Lütfen tekrar deneyin.' });
  }
});
export default router;
