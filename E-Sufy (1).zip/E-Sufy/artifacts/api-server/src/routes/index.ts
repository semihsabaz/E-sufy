import { Router, type IRouter } from "express";
import healthRouter from "./health";
import storiesRouter from "./stories";
import religiousChatRouter from "./religious-chat";

const router: IRouter = Router();

router.use(healthRouter);
router.use(storiesRouter);
router.use(religiousChatRouter);

export default router;
