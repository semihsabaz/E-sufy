export type SoundId = 'bell' | 'soft' | 'adhan';
export type PrayerSettings = {
  enabled: boolean; preAlert: boolean; atPrayer: boolean;
  reminderTone: SoundId; prayerTone: SoundId;
};
export const PRAYER_SOUNDS: { id: SoundId; label: string }[] = [
  { id: 'bell', label: 'Çan melodisi' }, { id: 'soft', label: 'Yumuşak melodi' }, { id: 'adhan', label: 'Ezan (15 saniye)' },
];
export const DEFAULT_SETTINGS: PrayerSettings = {
  enabled: false, preAlert: true, atPrayer: true, reminderTone: 'bell', prayerTone: 'adhan',
};
export function parsePrayerSettings(raw: string | null): PrayerSettings {
  try {
    const value = JSON.parse(raw ?? '{}');
    const validTone = (tone: unknown, fallback: SoundId): SoundId =>
      PRAYER_SOUNDS.some((item) => item.id === tone) ? tone as SoundId : fallback;
    const bool = (key: keyof PrayerSettings) => typeof value?.[key] === 'boolean' ? value[key] as boolean : DEFAULT_SETTINGS[key] as boolean;
    return { enabled: bool('enabled'), preAlert: bool('preAlert'), atPrayer: bool('atPrayer'),
      reminderTone: validTone(value?.reminderTone, 'bell'), prayerTone: validTone(value?.prayerTone, 'adhan') };
  } catch { return { ...DEFAULT_SETTINGS }; }
}
export type PrayerDay = { date: string; timings: Record<string, string> };
export type PrayerEvent = {
  id: string; city: string; prayer: string; timestamp: number; kind: 'reminder' | 'prayer'; tone: SoundId;
};
export function turkeyDate(now = new Date()) {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'Europe/Istanbul', year: 'numeric', month: '2-digit', day: '2-digit' }).format(now);
}
export function offsetDate(date: string, offset: number) {
  const value = new Date(`${date}T12:00:00Z`);
  value.setUTCDate(value.getUTCDate() + offset);
  return value.toISOString().slice(0, 10);
}
const prayers = [
  ['Fajr', 'İmsak'], ['Dhuhr', 'Öğle'], ['Asr', 'İkindi'], ['Maghrib', 'Akşam'], ['Isha', 'Yatsı'],
] as const;
export function buildPrayerEvents(city: string, days: PrayerDay[], settings: PrayerSettings): PrayerEvent[] {
  if (!settings.enabled) return [];
  const result: PrayerEvent[] = [];
  for (const day of days) for (const [key, label] of prayers) {
    const time = day.timings[key]?.slice(0, 5);
    if (!time || !/^([01]\d|2[0-3]):[0-5]\d$/.test(time)) throw new Error('Namaz vakti verisi geçersiz.');
    const timestamp = Date.parse(`${day.date}T${time}:00+03:00`);
    if (!Number.isFinite(timestamp)) throw new Error('Namaz tarihi geçersiz.');
    if (settings.preAlert) result.push({
      id: `esufy-prayer:${city}:${day.date}:${key}:reminder`, city, prayer: label,
      timestamp: timestamp - 10 * 60 * 1000, kind: 'reminder', tone: settings.reminderTone,
    });
    if (settings.atPrayer) result.push({
      id: `esufy-prayer:${city}:${day.date}:${key}:prayer`, city, prayer: label,
      timestamp, kind: 'prayer', tone: settings.prayerTone,
    });
  }
  return result.sort((a, b) => a.timestamp - b.timestamp);
}
export async function fetchPrayerCalendar(city: string, numberOfDays = 6): Promise<PrayerDay[]> {
  const today = turkeyDate();
  const dates = Array.from({ length: numberOfDays }, (_, i) => offsetDate(today, i));
  const months = [...new Set(dates.map((date) => date.slice(0, 7)))];
  const allDays: PrayerDay[] = [];
  for (const month of months) {
    const [year, monthNumber] = month.split('-');
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20000);
    let response: Response;
    try {
      response = await fetch(
        `https://api.aladhan.com/v1/calendarByCity/${year}/${Number(monthNumber)}?city=${encodeURIComponent(city)}&country=Turkey&method=13`,
        { signal: controller.signal },
      );
    } finally { clearTimeout(timeout); }
    if (!response.ok) throw new Error('Namaz vakti servisine ulaşılamadı.');
    const json = await response.json();
    if (json.code !== 200 || !Array.isArray(json.data)) throw new Error('Namaz vakti servisi geçersiz yanıt verdi.');
    for (const item of json.data) {
      const date = item.date?.gregorian?.date?.split('-').reverse().join('-');
      if (dates.includes(date)) allDays.push({ date, timings: item.timings });
    }
  }
  if (allDays.length !== dates.length) throw new Error('Bütün günlerin namaz vakitleri alınamadı.');
  return allDays.sort((a, b) => a.date.localeCompare(b.date));
}
export function eventMessage(event: PrayerEvent) {
  return event.kind === 'reminder' ? `${event.city}: ${event.prayer} vaktine 10 dakika kaldı.` : `${event.city}: ${event.prayer} vakti geldi.`;
}
export function duePrayerEvents(events: PrayerEvent[], now: number, delivered: Set<string>) {
  return events.filter((event) => !delivered.has(event.id) && now >= event.timestamp && now - event.timestamp < 60000);
}
