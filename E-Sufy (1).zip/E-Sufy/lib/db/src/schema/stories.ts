import { boolean, date, integer, pgTable, serial, text, timestamp, uniqueIndex } from 'drizzle-orm/pg-core';
import { createInsertSchema } from 'drizzle-zod';

export const storiesTable = pgTable('published_stories', {
  id: serial('id').primaryKey(),
  publicationDate: date('publication_date').notNull(),
  archive: boolean('archive').notNull().default(false),
  position: integer('position').notNull(),
  title: text('title').notNull(),
  theme: text('theme').notNull(),
  summary: text('summary').notNull(),
  content: text('content').notNull(),
  lesson: text('lesson').notNull(),
  source: text('source').notNull(),
  fingerprint: text('fingerprint').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).defaultNow().notNull(),
}, (table) => [
  uniqueIndex('story_day_position').on(table.publicationDate, table.archive, table.position),
  uniqueIndex('story_fingerprint').on(table.fingerprint),
]);
export const insertStorySchema = createInsertSchema(storiesTable).omit({ id: true, createdAt: true });
export type PublishedStoryRecord = typeof storiesTable.$inferSelect;
