declare function imageSize(input: string | Uint8Array | ArrayBuffer): {
  width: number;
  height: number;
  type: string;
};

declare namespace imageSize {
  const types: string[];
}

export = imageSize;