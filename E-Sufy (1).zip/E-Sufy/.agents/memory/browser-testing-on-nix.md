---
name: Browser testing on Nix
description: Running downloaded Playwright Chromium without Debian dependency installers.
---

Downloaded Playwright Chromium needs a Nix library search path that includes **libgbm**, not just mesa.

**Why:** Chromium launches failed first on GLib and then on GBM. Evaluating the existing Nix packages' library paths fixed launch without installing Debian packages. Broad searches of the entire Nix store were too slow.

**How to apply:** Use the repository's browser-test wrapper when available; otherwise obtain a bounded library path with Nix evaluation. Do not repeatedly scan the whole Nix store.
