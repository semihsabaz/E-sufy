---
name: Daily story publication policy
description: Confirmed content type and the reasoning behind scheduled source-based readings.
---

The daily Kıssalar publication is for **dini kıssalar ve hikâyeler**, not hadiths. The user explicitly chose stories when asked to distinguish the two.

**Why:** The request used both words; treating generated stories as hadith would misrepresent religious material.

**How to apply:** Keep this stream separate from the Hadis section. Publish nine readings per day, retain past readings, and use nine items per archive page.

Publication follows Europe/Istanbul midnight across all clients, not each visitor’s device timezone. Tomorrow’s readings are prepared ahead of publication and must remain private until their publication date.

**Why:** One shared archive should not differ between web and mobile or reveal future content. Preparing ahead avoids making publication depend on an AI request finishing at midnight.

**How to apply:** Treat publication date as the visibility boundary, and label AI paraphrases as summaries, not literal scripture. Reusing a scriptural topic is allowed; copied reading text is not.
