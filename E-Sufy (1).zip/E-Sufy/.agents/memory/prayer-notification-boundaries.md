---
name: Prayer notification delivery boundaries
description: Native scheduling capacity and browser audio constraints that must remain visible to users.
---

Schedule real dated prayer times, not repeating alarms based on today's hours. Keep ten-minute reminders and prayer-time notifications independently configurable.

**Why:** Prayer times change daily; the user explicitly asked for both alerts and selectable sounds.

**How to apply:** Replan when the city or settings change. Never use display fallback times for alarms when the timing service fails.

The native plan covers six days and renews on application activation. Bundled custom notification sounds require a compiled native application; Expo Go may play the system sound instead.

**Why:** Five prayers times two alerts times six days gives sixty pending notifications, below iOS's usual sixty-four-notification limit. Remote audio URLs cannot replace a bundled native notification sound.

**How to apply:** Keep the duration and rebuild requirement visible in settings. Do not claim indefinite reminders while the app remains unopened or that Expo Go demonstrates custom background sound delivery.

Browser audio requires an explicit user gesture and an open, active page. Native OS silent/DND/exact-alarm policies must not be bypassed or presented as guaranteed delivery.

**Why:** Browser and OS restrictions are outside application control.

**How to apply:** Show blocked-audio/permission errors and preserve an explicit enable/preview action.
