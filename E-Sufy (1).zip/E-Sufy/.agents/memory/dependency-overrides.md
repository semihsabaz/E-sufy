---
name: Dependency security override compatibility
description: Avoid crossing a major version when security minimums are applied to js-yaml.
---

Security overrides for js-yaml must remain on a patched 4.x release when consumed by Orval versions that expect its default export.

**Why:** An unbounded minimum constraint unexpectedly selected 5.x, which removed the expected default export and broke API generation after a package installation.

**How to apply:** Use a compatible patched 4.x pin or a bounded 4.x range. Revisit the bound only when the generator supports the new major version.

For the decoder used by Expo's older query-string consumers, preserve the CommonJS function export when upgrading to the patched ES-module release. A module-format-only pnpm patch is preferable to an Expo or navigation major upgrade for a transitive security fix; leave the upstream decoding algorithm untouched.

**Why:** The first safe decoder release is ES-module-only, while query-string 7 expects `require()` to return a callable function, not a module namespace.

**How to apply:** Verify both the CommonJS consumer and Metro bundling when changing or removing this compatibility patch. Remove it once all consumers support the upstream module format.

In this workspace, configure API generation with explicit target versions for
React Query and Zod rather than relying on generator auto-detection.

**Why:** pnpm catalog entries do not always let the generator infer installed
versions. A newer generator selected incompatible Zod output and older React
Query types despite the runtime packages already being installed.

**How to apply:** Keep the generator's explicit target versions aligned with
the actual runtime libraries whenever updating the generator or those libraries.
