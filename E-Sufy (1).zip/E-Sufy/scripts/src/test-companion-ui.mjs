import { chromium, expect } from '@playwright/test';
import assert from 'node:assert/strict';

const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
try {
  if (!process.argv.includes('--mobile-only')) {
  const context = await browser.newContext({ permissions: ['notifications'], timezoneId: 'Europe/Istanbul' });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (error) => errors.push(error.message));
  await page.addInitScript(() => {
    window.__played = [];
    const original = HTMLMediaElement.prototype.play;
    HTMLMediaElement.prototype.play = function (...args) {
      return original.apply(this, args).then(() => { window.__played.push(this.src); });
    };
  });
  await page.clock.install({ time: new Date('2026-10-13T07:49:58+03:00') });
  await page.clock.pauseAt(new Date('2026-10-13T07:49:58+03:00'));
  await page.route('**/calendarByCity/**', (route) => route.fulfill({
    json: { code: 200, data: Array.from({ length: 6 }, (_, i) => ({
      date: { gregorian: { date: `${13 + i}-10-2026` } },
      timings: { Fajr: '08:00', Sunrise: '08:50', Dhuhr: '12:30', Asr: '15:30', Maghrib: '18:00', Isha: '19:30' },
    })) },
  }));
  await page.goto('http://localhost:80/settings');
  await page.getByTestId('switch-prayer-enabled').click();
  await expect(page.getByTestId('switch-prayer-enabled')).toHaveAttribute('aria-checked', 'true');
  await expect(page.getByTestId('text-prayer-status')).toContainText('2026-10-14');
  await page.clock.fastForward(2000);
  await expect.poll(() => page.evaluate(() => localStorage.getItem('prayer-delivered-events'))).toContain('reminder');
  await page.clock.fastForward(600000);
  await expect.poll(() => page.evaluate(() => localStorage.getItem('prayer-delivered-events'))).toContain(':prayer');
  await expect.poll(() => page.evaluate(() => window.__played.at(-1))).toContain('adhan.wav');
  await page.getByTestId('button-stop-adhan').click();
  await page.getByTestId('radio-prayer-soft').click();
  const saved = await page.evaluate(() => JSON.parse(localStorage.getItem('prayer-alert-settings')));
  assert.equal(saved.prayerTone, 'soft');
  await page.getByTestId('switch-pre-alert').click();
  assert.equal(await page.getByTestId('switch-pre-alert').getAttribute('aria-checked'), 'false');
  await page.evaluate(() => {
    localStorage.setItem('prayer-city', 'İzmir');
    window.dispatchEvent(new Event('prayer-city-change'));
  });
  await expect(page.getByTestId('text-prayer-status')).toContainText('İzmir');
  await page.getByTestId('switch-prayer-enabled').click();
  await page.clock.resume();
  await page.setViewportSize({ width: 390, height: 844 });
  assert.ok(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth));
  await page.getByTestId('button-chat-open').click();
  await expect(page.getByTestId('panel-chat')).toBeVisible();
  await page.getByTestId('input-chat').fill('Futbol maçının skoru nedir?');
  await page.getByTestId('button-chat-send').click();
  await expect(page.getByText('Kapsam dışı', { exact: true })).toBeVisible({ timeout: 90000 });
  await page.getByTestId('button-chat-clear').click();
  await expect(page.getByText('Kapsam dışı', { exact: true })).toHaveCount(0);
  await page.getByTestId('button-chat-close').click();
  await expect(page.getByTestId('button-chat-open')).toBeVisible();
  assert.deepEqual(errors, []);
  console.log('PASS web: enabled permission flow, audible 10-minute and exact-time alarms, chosen melody persistence, disable toggles, city replanning, no narrow-screen overflow, real AI refusal, clear/close');
  await context.close();
  }

  const mobile = await browser.newContext({ viewport: { width: 402, height: 874 } });
  const nativePage = await mobile.newPage();
  const nativeErrors = [];
  nativePage.on('pageerror', (error) => nativeErrors.push(error.message));
  await nativePage.goto(`https://${process.env.REPLIT_EXPO_DEV_DOMAIN}/settings`);
  await expect(nativePage.getByText('Namaz hatırlatmaları', { exact: true })).toBeVisible({ timeout: 45000 });
  await nativePage.getByTestId('button-chat-open').click();
  await expect(nativePage.getByTestId('input-chat')).toBeVisible();
  await nativePage.getByTestId('input-chat').fill('Dua ederken nelere dikkat edilir?');
  let rejected = false;
  await nativePage.route('**/api/openai/religious-chat', (route) => {
    if (rejected) return route.continue();
    rejected = true;
    return route.fulfill({ status: 503, json: { message: 'Temporary test outage' } });
  });
  await nativePage.getByTestId('button-chat-send').click();
  await expect(nativePage.getByTestId('button-chat-retry')).toBeVisible();
  const [response] = await Promise.all([
    nativePage.waitForResponse((res) => res.url().includes('/api/openai/religious-chat') && res.status() === 200, { timeout: 120000 }),
    nativePage.getByTestId('button-chat-retry').click(),
  ]);
  const answer = await response.json();
  assert.equal(answer.allowed, true);
  assert.ok(answer.answer.length > 50);
  await expect(nativePage.getByText(answer.answer, { exact: true })).toBeVisible();
  await expect(nativePage.getByText('Yanıt alınamadı.', { exact: false })).toHaveCount(0);
  await nativePage.getByTestId('button-chat-close').click();
  await expect(nativePage.getByTestId('button-chat-open')).toBeVisible();
  assert.deepEqual(nativeErrors, []);
  console.log('PASS mobile browser: settings screen, chat modal, temporary failure and retry, real religious answer rendered, close and return. Native OS notification delivery is not covered by a web browser.');
  await mobile.close();
} finally {
  await browser.close();
}
