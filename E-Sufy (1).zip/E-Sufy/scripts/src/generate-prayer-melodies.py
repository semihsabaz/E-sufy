"""Create small, original PCM notification melodies for both client bundles."""
import math
import struct
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
RATE = 16000
MELODIES = {"bell": [659.25, 783.99, 987.77], "soft": [523.25, 659.25, 783.99, 659.25]}
for name, notes in MELODIES.items():
    samples = []
    for i in range(RATE * 3):
        t = i / RATE
        duration = 3 / len(notes)
        index = min(int(t / duration), len(notes) - 1)
        within = t - index * duration
        envelope = min(within / 0.03, 1) * math.exp(-within * (4 if name == "bell" else 2))
        frequency = notes[index]
        value = math.sin(2 * math.pi * frequency * t) + 0.2 * math.sin(4 * math.pi * frequency * t)
        samples.append(struct.pack("<h", int(9000 * envelope * value)))
    for folder in ["artifacts/nur-islamic-companion/public/sounds", "artifacts/nur-islamic-companion-mobile/assets/sounds"]:
        path = ROOT / folder / f"{name}.wav"
        path.parent.mkdir(parents=True, exist_ok=True)
        with wave.open(str(path), "wb") as output:
            output.setnchannels(1)
            output.setsampwidth(2)
            output.setframerate(RATE)
            output.writeframes(b"".join(samples))
