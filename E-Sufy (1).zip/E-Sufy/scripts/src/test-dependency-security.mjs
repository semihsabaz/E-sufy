import assert from "node:assert/strict";
import { createRequire } from "node:module";
import { spawnSync } from "node:child_process";
import test from "node:test";

const mobile = createRequire(new URL("../../artifacts/nur-islamic-companion-mobile/package.json", import.meta.url));
const api = createRequire(new URL("../../artifacts/api-server/package.json", import.meta.url));
const router = createRequire(mobile.resolve("expo-router"));
const queryString = router("query-string");
const queryRequire = createRequire(router.resolve("query-string"));
const qs = createRequire(api.resolve("express"))("qs");

test("Expo's CommonJS query-string consumer uses the patched decoder", () => {
  const decoder = queryRequire("decode-uri-component");
  assert.equal(typeof decoder, "function");
  assert.equal(decoder("%C3%A5%20%F0%9F%8C%99"), "å 🌙");
  assert.equal(decoder("%E0%A4%A"), "%E0%A4%A");
  assert.throws(() => decoder(null), TypeError);
  assert.deepEqual({ ...queryString.parse("name=%C3%A5&space=hello+world") }, {
    name: "å",
    space: "hello world",
  });
  assert.equal(queryString.stringify({ name: "å" }), "name=%C3%A5");
});

test("malformed percent-encoded input cannot exhaust the decoder", () => {
  // Run separately so a regression cannot hang the test runner.
  const result = spawnSync(process.execPath, [
    "-e",
    `const decode = require(${JSON.stringify(queryRequire.resolve("decode-uri-component"))});
     const input = '%FF'.repeat(100000);
     if (decode(input) !== input) process.exit(1);`,
  ], { timeout: 5000, encoding: "utf8" });
  assert.ifError(result.error);
  assert.equal(result.status, 0, result.stderr);
});

test("qs safely round-trips attacker-controlled constructor.isBuffer", () => {
  for (const options of [{ plainObjects: true }, { allowPrototypes: true }]) {
    const parsed = qs.parse("x[constructor][isBuffer]=y", options);
    assert.doesNotThrow(() => qs.stringify(parsed));
  }
});

test("qs enforces array limits for bracket-key comma parsing", () => {
  assert.throws(
    () => qs.parse("a[]=1,2,3,4", { comma: true, arrayLimit: 3, throwOnLimitExceeded: true }),
    RangeError,
  );
});

test("both Expo plist consumers reject injected XML entity names", () => {
  const expo = createRequire(mobile.resolve("expo"));
  const plugins = createRequire(expo.resolve("@expo/config-plugins"));
  const expoPlist = createRequire(plugins.resolve("@expo/plist"));
  const xcode = createRequire(plugins.resolve("xcode"));
  const simplePlist = createRequire(xcode.resolve("simple-plist"));
  const plist = createRequire(simplePlist.resolve("plist"));
  for (const consumer of [expoPlist, plist]) {
    const { DOMImplementation, XMLSerializer } = consumer("@xmldom/xmldom");
    const doc = new DOMImplementation().createDocument(null, "root", null);
    assert.throws(() => doc.createEntityReference("safe; <injected/> &x"));
    assert.equal(new XMLSerializer().serializeToString(doc.createEntityReference("valid")), "&valid;");
  }
});
