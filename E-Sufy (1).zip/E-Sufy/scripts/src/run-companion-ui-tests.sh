#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../.."
# Use existing Nix libraries rather than Debian's playwright install-deps command.
libs="$(nix-instantiate --eval --strict --expr 'with import <nixpkgs> {}; lib.makeLibraryPath [ glib nss nspr atk at-spi2-atk dbus xorg.libX11 xorg.libXcomposite xorg.libXdamage xorg.libXext xorg.libXfixes xorg.libXrandr libgbm xorg.libxcb libxkbcommon alsa-lib at-spi2-core ]' | tr -d '"')"
export LD_LIBRARY_PATH="$libs:${LD_LIBRARY_PATH:-}"
exec node scripts/src/test-companion-ui.mjs "$@"
