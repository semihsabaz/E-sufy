import assert from "node:assert/strict";
import { generateKeyPairSync } from "node:crypto";
import { mkdtemp, writeFile, rm, readFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { tmpdir } from "node:os";
import path from "node:path";
import test from "node:test";

const mobile = createRequire(new URL("../../artifacts/nur-islamic-companion-mobile/package.json", import.meta.url));
const cli = createRequire(mobile.resolve("@expo/cli/package.json"));
const api = createRequire(new URL("../../artifacts/api-server/package.json", import.meta.url));
const sandbox = createRequire(new URL("../../artifacts/mockup-sandbox/package.json", import.meta.url));
const micromatch = createRequire(createRequire(sandbox.resolve("fast-glob")).resolve("micromatch"));
const braces = micromatch("braces");
const forge = cli("node-forge");

test("RSA verification rejects extra DigestAlgorithm elements and malformed NULL parameters", () => {
  const { privateKey } = generateKeyPairSync("rsa", { modulusLength: 1024, publicExponent: 3 });
  const key = forge.pki.privateKeyFromPem(privateKey.export({ type: "pkcs1", format: "pem" }).toString());
  const publicKey = forge.pki.setRsaPublicKey(key.n, key.e);
  const digest = forge.md.sha256.create().update("signature security regression").digest().getBytes();
  const { asn1 } = forge;
  const sequence = (values) => asn1.create(asn1.Class.UNIVERSAL, asn1.Type.SEQUENCE, true, values);
  const nullParameter = (value = "") => asn1.create(asn1.Class.UNIVERSAL, asn1.Type.NULL, false, value);
  const sign = (parameters) => {
    const algorithm = sequence([
      asn1.create(asn1.Class.UNIVERSAL, asn1.Type.OID, false, asn1.oidToDer(forge.oids.sha256).getBytes()),
      ...parameters,
    ]);
    const info = sequence([algorithm, asn1.create(asn1.Class.UNIVERSAL, asn1.Type.OCTETSTRING, false, digest)]);
    return key.sign(asn1.toDer(info).getBytes(), "NONE");
  };
  for (const parameters of [[], [nullParameter()]]) {
    assert.equal(publicKey.verify(digest, sign(parameters)), true);
  }
  for (const parameters of [
    [nullParameter(), nullParameter()],
    [nullParameter(), asn1.create(asn1.Class.UNIVERSAL, asn1.Type.OCTETSTRING, false, "garbage")],
    [nullParameter("garbage")],
  ]) {
    assert.throws(() => publicKey.verify(digest, sign(parameters)), /valid RSASSA-PKCS1-v1_5 DigestInfo/);
  }
});

test("braces rejects deeply nested strings before recursive AST processing", () => {
  for (const pattern of [
    "{".repeat(4000) + "a,b" + "}".repeat(4000),
    "(".repeat(4000) + "a" + ")".repeat(4000),
    "{".repeat(4000) + "a",
  ]) {
    for (const method of ["parse", "compile", "expand", "stringify"]) {
      assert.throws(() => braces[method](pattern), { name: "SyntaxError", message: /maximum nesting depth/ });
    }
  }
  assert.deepEqual(braces.expand("file-{a,b}-{1..3}"), [
    "file-a-1", "file-a-2", "file-a-3", "file-b-1", "file-b-2", "file-b-3",
  ]);
  assert.equal(braces.compile("file-{a,b}"), "file-(a|b)");
  assert.equal(braces.stringify(braces.parse("file-{a,b}")), "file-{a,b}");
});

test("all recursive braces walkers bound caller-supplied AST depth", () => {
  for (const method of ["compile", "expand", "stringify"]) {
    let ast = { type: "text", value: "a" };
    for (let depth = 0; depth < 3000; depth++) {
      ast = { type: "root", nodes: [ast] };
    }
    assert.throws(() => braces[method](ast), { name: "SyntaxError", message: /maximum nesting depth/ });
  }
});

test("Istanbul loads YAML through js-yaml 4 without legacy sprintf-js", async () => {
  const reactNative = createRequire(mobile.resolve("react-native/package.json"));
  const babelJest = createRequire(reactNative.resolve("babel-jest"));
  const istanbulPlugin = createRequire(babelJest.resolve("babel-plugin-istanbul"));
  const nyc = createRequire(istanbulPlugin.resolve("@istanbuljs/load-nyc-config"));
  assert.equal(nyc("js-yaml/package.json").version, "4.3.2");
  const directory = await mkdtemp(path.join(tmpdir(), "nyc-yaml-security-"));
  try {
    await writeFile(path.join(directory, ".nycrc.yaml"), "all: true\ninclude:\n  - src/**/*.js\n");
    const config = await istanbulPlugin("@istanbuljs/load-nyc-config").loadNycConfig({ cwd: directory });
    assert.equal(config.all, true);
    assert.deepEqual(config.include, ["src/**/*.js"]);
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
});

test("proxy-addr does not trust arbitrary IPv4 addresses for an IPv6 subnet", () => {
  const proxyaddr = createRequire(api.resolve("express"))("proxy-addr");
  assert.equal(proxyaddr.compile("::ffff:10.0.0.0/8")("203.0.113.1"), false);
  assert.equal(proxyaddr.compile("::/1")("203.0.113.1"), false);
  assert.equal(proxyaddr.compile("10.0.0.0/8")("10.1.2.3"), true);
  assert.equal(proxyaddr.compile("::ffff:10.0.0.0/104")("10.1.2.3"), true);
});

test("shell-quote blocks command injection following a comment token", () => {
  const shellQuote = cli("shell-quote");
  assert.throws(() => shellQuote.quote(["echo", "ok", { comment: "x" }, "a\nid;#"]), TypeError);
});

test("lockfile excludes vulnerable releases and persists both security patches", async () => {
  const lock = await readFile(new URL("../../pnpm-lock.yaml", import.meta.url), "utf8");
  for (const dependency of [
    "orval@8.20.0", "proxy-addr@2.0.7", "js-yaml@3.15.1", "js-yaml@4.3.1",
    "source-map-js@1.2.1", "brace-expansion@1.1.18", "brace-expansion@2.1.4",
    "brace-expansion@5.0.9", "http-cache-semantics@4.2.0", "shell-quote@1.10.0",
    "undici@6.28.0", "compression@1.8.1", "markdown-it@14.3.0",
    "sprintf-js@", "fast-copy@4.0.3", "postcss-selector-parser@6.0.10",
  ]) {
    assert.equal(lock.includes(`\n  ${dependency}`), false, `${dependency} remains in the lockfile`);
  }
  for (const dependency of ["braces@3.0.3", "node-forge@1.4.0"]) {
    assert.match(lock, new RegExp(`${dependency.replaceAll(".", "\\.")}:\\n    hash: [a-f0-9]+\\n    path: patches/`));
  }
});
