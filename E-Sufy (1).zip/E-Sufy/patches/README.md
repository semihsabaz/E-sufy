# Dependency security patches

Install with `pnpm install --frozen-lockfile`. pnpm applies the registered patches
and verifies their content hashes. Do not edit installed `node_modules` files or
remove patch registrations without replacing their protection.

Run `pnpm --filter @workspace/scripts run test:dependency-security` to check the
patched behavior and upstream dependency upgrades.

## node-forge 1.4.0 — GHSA-86w9-cpqp-85rv

No fixed upstream release was available when this patch was written. RSA
PKCS#1 v1.5 verification now requires the nested DigestAlgorithm sequence to
contain exactly the OID and, optionally, an empty primitive ASN.1 NULL. Extra
elements, non-NULL parameters, and nonempty NULL values are rejected.

Regression tests verify legitimate SHA-256 signatures both with and without
NULL parameters, plus signatures containing extra algorithm elements and
malformed NULL parameters, using an RSA key with exponent 3.

## braces 3.0.3 — GHSA-vfj7-8cjw-p6xm

No fixed upstream release was available when this patch was written. Parsing
limits the nesting stack to 128 entries. Compile, expand, and stringify also
bound recursive traversal to depth 128, including caller-supplied ASTs.
Overly nested input throws an explicit SyntaxError before native stack
exhaustion. Normal pattern expansion and compilation are unchanged.

Regression tests exercise nested braces, parentheses, unclosed input, and
direct AST inputs, as well as ordinary brace patterns.

## Audit visibility

These patches deliberately retain upstream package names and versions.
`pnpm audit` and Replit's dependency audit still report the two advisories above
because their advisory records match package versions, not patched source.
Neither finding is hidden, ignored, or represented by a fabricated version.
Replace each patch with a verified upstream fixed release when one is available,
then rerun the regression tests, API generation, type checks, and builds.

## decode-uri-component 0.5.0

The existing patch preserves the CommonJS function export expected by Expo's
query-string consumers. It does not change the upstream decoding algorithm.
